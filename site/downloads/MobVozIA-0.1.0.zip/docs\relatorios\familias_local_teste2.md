# Juiz de IA por família de assunto (conversas ambiente)

2026-10-31 19:42; 5 famílias, 20 cenas, juiz `llama3.2:latest`, 13 s. Média geral **3.40**; famílias abaixo de 4.0: **4**.

| Família | cenas | nota |
|---|---|---|
| zumbi_carne | 4 | 2.25  REVER |
| gato | 4 | 3.25  REVER |
| cercado | 4 | 3.75  REVER |
| jogador_dono | 4 | 3.75  REVER |
| vaca | 4 | 4.00 |

## Problemas apontados (famílias abaixo do mínimo primeiro)

### zumbi_carne (2.25)  _um zumbi e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Grrr... tem gente por perto. / 1: Eu também sinto o cheiro. / 0: Quase... quase...
- nota 2: 0: Humano... cheiro de carne. / 1: Carne... carne... / 0: Hmmm...
- nota 2: 0: Grrr... tem gente por perto. / 1: Carne... carne... / 0: Hmmm...
  - ⚠ Grrr... tem gente por perto.
- nota 2: 0: Humano... cheiro de carne. / 1: Carne... carne... / 0: Quase... quase...
  - ⚠ 0: Quase... quase...

### gato (3.25)  _um gato e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 2: 0: Sol quente e silêncio é tudo que eu peço. / 1: Cochilo bom não precisa de mais nada. / 0: Miau, agora vou dormir de novo.
- nota 3: 0: Sol quente e silêncio é tudo que eu peço. / 1: Sol é o melhor travesseiro. / 0: Miau, agora vou dormir de novo.

### cercado (3.75)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 3: 0: Tem bastante gente aqui no cercado hoje. / 1: Gosto de ter companhia por perto. / 0: Aqui dentro a gente se sente em casa.

### jogador_dono (3.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre foi domado e agora pertence ao jogador (fato verificado)_
- nota 3: 0: Agora eu sou do humano, e isso me faz bem. / 1: Ele te trata bem? / 0: Estou feliz, sim, de verdade.
