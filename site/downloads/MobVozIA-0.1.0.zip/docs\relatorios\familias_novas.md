# Juiz de IA por família de assunto (conversas ambiente)

2026-10-31 19:16; 139 famílias, 1112 cenas, juiz `deepseek-v4-pro`, 296 s. Média geral **4.48**; famílias abaixo de 4.0: **12**.

| Família | cenas | nota |
|---|---|---|
| cercado | 8 | 3.00  REVER |
| jogador_nome_conta | 8 | 3.38  REVER |
| jogador_dono | 8 | 3.50  REVER |
| gato | 8 | 3.62  REVER |
| golem_flor | 8 | 3.62  REVER |
| bicho_jogador_noite | 8 | 3.75  REVER |
| jogador_apresenta | 8 | 3.75  REVER |
| bicho_filhotes_cuidado | 8 | 3.88  REVER |
| clerigo | 8 | 3.88  REVER |
| curiosidade_quadrado | 8 | 3.88  REVER |
| jogador_nome_ambos | 8 | 3.88  REVER |
| warden_sculk | 8 | 3.88  REVER |
| bicho_armadura | 8 | 4.00 |
| bicho_jogador_chuva | 8 | 4.00 |
| bicho_jogador_fome | 8 | 4.00 |
| bruxa_pocao | 8 | 4.00 |
| creeper_zumbi | 8 | 4.00 |
| jogador_ameacou | 8 | 4.00 |
| jogador_conhecido | 8 | 4.00 |
| medo_lobo | 8 | 4.00 |
| zumbi_esqueleto | 8 | 4.00 |
| aranha_zumbi | 8 | 4.12 |
| bicho_barulho_estranho | 8 | 4.12 |
| bicho_item | 8 | 4.12 |
| ceu_estrelas | 8 | 4.12 |
| chuva | 8 | 4.12 |
| curiosidade_portal | 8 | 4.12 |
| enderman_bloco | 8 | 4.12 |
| jogador_passando | 8 | 4.12 |
| jogador_sem_nome | 8 | 4.12 |
| bicho_abelha | 8 | 4.25 |
| bicho_barulho | 8 | 4.25 |
| bicho_jogador_conhecido | 8 | 4.25 |
| curiosidade_enderman | 8 | 4.25 |
| enderman_olhar | 8 | 4.25 |
| fome_bicho | 8 | 4.25 |
| jogador_fome | 8 | 4.25 |
| jogador_monstros_visto | 8 | 4.25 |
| vila_gato | 8 | 4.25 |
| acougueiro | 8 | 4.38 |
| aranha_presa | 8 | 4.38 |
| armeiro | 8 | 4.38 |
| bicho_jogador_ferido | 8 | 4.38 |
| bicho_noite_lua | 8 | 4.38 |
| bicho_quer_comida | 8 | 4.38 |
| bruxa_cogumelo | 8 | 4.38 |
| esqueleto_sombra | 8 | 4.38 |
| ferreiro_armas | 8 | 4.38 |
| galinha | 8 | 4.38 |
| jogador_presente | 8 | 4.38 |
| jogador_traiu | 8 | 4.38 |
| monstros_armadura | 8 | 4.38 |
| monstros_chuva | 8 | 4.38 |
| monstros_item | 8 | 4.38 |
| noite | 8 | 4.38 |
| pastor | 8 | 4.38 |
| sol | 8 | 4.38 |
| vila_pilhadores | 8 | 4.38 |
| vila_pao | 8 | 4.43 |
| vila_porta_noite | 8 | 4.43 |
| bicho_hora_comer | 8 | 4.50 |
| bicho_vento | 8 | 4.50 |
| cartografo | 8 | 4.50 |
| colheita | 8 | 4.50 |
| curiosidade_creeper | 8 | 4.50 |
| esqueleto_flechas | 8 | 4.50 |
| flecheiro | 8 | 4.50 |
| jogador_troca | 8 | 4.50 |
| jogador_voltou | 8 | 4.50 |
| monstros_ferido | 8 | 4.50 |
| pasto | 8 | 4.50 |
| porco | 8 | 4.50 |
| vaca | 8 | 4.50 |
| vila_armadura | 8 | 4.50 |
| vila_comerciante | 8 | 4.50 |
| zumbi_carne | 8 | 4.50 |
| zumbi_sol | 8 | 4.50 |
| afazeres | 8 | 4.62 |
| aranha_teia | 8 | 4.62 |
| bicho_agua | 8 | 4.62 |
| bicho_sombra | 8 | 4.62 |
| cavalo | 8 | 4.62 |
| creeper_silencio | 8 | 4.62 |
| curiosidade_fundo | 8 | 4.62 |
| esqueleto_armadura | 8 | 4.62 |
| esqueleto_creeper | 8 | 4.62 |
| golem_quer_flor | 8 | 4.62 |
| golem_ronda | 8 | 4.62 |
| jogador_chuva | 8 | 4.62 |
| lobo | 8 | 4.62 |
| noite_frio | 8 | 4.62 |
| zumbi_armadura | 8 | 4.62 |
| zumbi_jogador | 8 | 4.62 |
| bibliotecario | 8 | 4.75 |
| bicho_cheiro | 8 | 4.75 |
| entardecer | 8 | 4.75 |
| golem_guarda | 8 | 4.75 |
| golem_orgulho | 8 | 4.75 |
| jogador_honesto | 8 | 4.75 |
| trovoada | 8 | 4.75 |
| vila_sino | 8 | 4.75 |
| zumbi_porta | 8 | 4.75 |
| amanhecer | 8 | 4.88 |
| aranha_caverna | 8 | 4.88 |
| bicho_cochilo | 8 | 4.88 |
| bruxa_pocao2 | 8 | 4.88 |
| camas | 8 | 4.88 |
| creeper_chiado | 8 | 4.88 |
| curiosidade_abelha | 8 | 4.88 |
| curtidor | 8 | 4.88 |
| enderman_agua | 8 | 4.88 |
| fofoca_vila | 8 | 4.88 |
| jogador_item | 8 | 4.88 |
| madrugada | 8 | 4.88 |
| monstros_lua | 8 | 4.88 |
| monstros_noite | 8 | 4.88 |
| ovelha | 8 | 4.88 |
| vila_manha | 8 | 4.88 |
| vila_passando_troca | 8 | 4.88 |
| warden_vibracao | 8 | 4.88 |
| bicho_lama | 8 | 5.00 |
| bicho_manha | 8 | 5.00 |
| ceu_nuvens | 8 | 5.00 |
| creeper_gato | 8 | 5.00 |
| esqueleto_mira | 8 | 5.00 |
| fazendeiro | 8 | 5.00 |
| ferreiro | 8 | 5.00 |
| jogador_acalmou | 8 | 5.00 |
| jogador_bateu | 8 | 5.00 |
| jogador_ferido | 8 | 5.00 |
| jogador_noite | 8 | 5.00 |
| monstros_dia | 8 | 5.00 |
| pedreiro | 8 | 5.00 |
| pescador | 8 | 5.00 |
| trocas_vila | 8 | 5.00 |
| vila_esmeralda | 8 | 5.00 |
| vila_fome | 8 | 5.00 |
| vila_tempestade | 8 | 5.00 |
| zumbis_na_vila | 8 | 5.00 |

## Problemas apontados (famílias abaixo do mínimo primeiro)

### cercado (3.00)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 4: 0: O cercado está cheio hoje. / 1: Aqui dentro nada nos incomoda. / 0: Aqui pelo menos tem comida.
  - ⚠ A fala 'Aqui dentro nada nos incomoda' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
  - ⚠ A resposta 'Aqui pelo menos tem comida' não conecta diretamente com 'nada nos incomoda', mas fecha de forma coerente.
- nota 3: 0: A cerca é alta, mas aqui dentro é seguro. / 1: À noite a cerca faz companhia. / 0: Aqui pelo menos tem comida.
  - ⚠ Fala 1 'À noite a cerca faz companhia' é vaga e não responde diretamente à fala 0 sobre segurança.
  - ⚠ Fala 0 final 'Aqui pelo menos tem comida' muda o tópico sem fechar a conversa de forma natural.
- nota 2: 0: A cerca é alta, mas aqui dentro é seguro. / 1: À noite a cerca faz companhia. / 0: Perto de vocês eu me sinto bem.
  - ⚠ Fala 1 'À noite a cerca faz companhia.' é vaga e não responde diretamente à fala 0 sobre segurança.
  - ⚠ Fala 0 final 'Perto de vocês eu me sinto bem.' muda o foco da cerca para os outros animais, quebrando a continuidade.
- nota 4: 0: A cerca é alta, mas aqui dentro é seguro. / 1: Aqui dentro nada nos incomoda. / 0: Aqui pelo menos tem comida.
  - ⚠ Fala 1 'Aqui dentro nada nos incomoda' é um pouco genérica e não responde diretamente à fala 0 sobre a cerca ser alta, mas ainda é plausível.
  - ⚠ Fala 0 final 'Aqui pelo menos tem comida' não fecha a conversa de forma conclusiva, apenas adiciona outro tópico.
- nota 2: 0: O cercado está cheio hoje. / 1: À noite a cerca faz companhia. / 0: Perto de vocês eu me sinto bem.
  - ⚠ Fala 1 'À noite a cerca faz companhia' é vaga e não responde diretamente à observação sobre o cercado cheio.
  - ⚠ Fala 0 final 'Perto de vocês eu me sinto bem' não fecha a conversa de forma natural, soa deslocada.

### jogador_nome_conta (3.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre sabe o nome do jogador_
- nota 3: 0: Sabia que essa pessoa se chama Bia? / 1: Que nome bonito, Bia. / 0: Aqui a gente se trata pelo nome.
  - ⚠ Fala 0: 'Sabia que essa pessoa se chama Bia?' soa estranho para criaturas calmas, pois não é comum que animais ou aldeões saibam o nome do jogador sem contexto.
  - ⚠ Fala 1: 'Que nome bonito, Bia.' parece uma reação humana, não típica de criaturas do jogo.
- nota 3: 0: Me contou pessoalmente: é Bia. / 1: Que nome bonito, Bia. / 0: Nome é a primeira coisa que a gente deveria saber.
  - ⚠ Fala 0: 'Me contou pessoalmente: é Bia.' soa um pouco formal demais para criaturas calmas como aldeões ou animais de fazenda, que tenderiam a falar de forma mais simples.
  - ⚠ Fala 0: 'Nome é a primeira coisa que a gente deveria saber.' parece filosófica demais para a maioria das criaturas do jogo, exceto talvez aldeões, mas ainda assim é um pouco rebuscada.
- nota 3: 0: O nome daquele humano é Bia, ele me disse. / 1: Que nome bonito, Bia. / 0: Nome é a primeira coisa que a gente deveria saber.
  - ⚠ Fala 0: 'O nome daquele humano é Bia, ele me disse.' - 'ele' é ambíguo, pois o humano pode ser de qualquer gênero e o pronome não combina com 'Bia'.
  - ⚠ Fala 0: 'Nome é a primeira coisa que a gente deveria saber.' - soa filosófica demais para criaturas calmas como animais de fazenda ou aldeões simples.
- nota 3: 0: O nome daquele humano é Bia, ele me disse. / 1: Bia? Não sabia, vou guardar. / 0: Aqui a gente se trata pelo nome.
  - ⚠ Fala 0: 'Aqui a gente se trata pelo nome' soa como uma regra social humana, não algo que criaturas calmas diriam naturalmente.
  - ⚠ Fala 1: 'Bia? Não sabia, vou guardar.' é vaga e não combina com a curiosidade esperada de criaturas da mesma espécie.
- nota 3: 0: O nome daquele humano é Bia, ele me disse. / 1: Boa, agora posso chamar pelo nome. / 0: Nome é a primeira coisa que a gente deveria saber.
  - ⚠ Fala 0: 'O nome daquele humano é Bia, ele me disse.' - 'ele' é ambíguo, pois o humano é Bia, então deveria ser 'ela'.
  - ⚠ Fala 0: 'Nome é a primeira coisa que a gente deveria saber.' - soa filosófico demais para criaturas calmas como animais de fazenda ou aldeões simples.

### jogador_dono (3.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre foi domado e agora pertence ao jogador (fato verificado)_
- nota 3: 0: Tenho dono agora: o humano. / 1: Que sorte a sua. / 0: Cuida sim.
  - ⚠ Fala 0 'Cuida sim.' não responde diretamente a 'Que sorte a sua.' e soa desconexa.
  - ⚠ Fala 1 'Que sorte a sua.' é genérica e não reflete a perspectiva de uma criatura da mesma espécie sobre domesticação.
- nota 3: 0: Tenho dono agora: o humano. / 1: Sempre quis ter alguém assim. / 0: Estou bem melhor.
  - ⚠ Fala 0 'Tenho dono agora: o humano.' soa estranha para criaturas calmas como vacas ou ovelhas, que não expressariam posse dessa forma.
  - ⚠ Fala 1 'Sempre quis ter alguém assim.' é vaga e não combina com o mundo simples de animais de fazenda.
- nota 3: 0: Tenho dono agora: o humano. / 1: Sempre quis ter alguém assim. / 0: Cuida sim.
  - ⚠ Fala 0 'Tenho dono agora: o humano.' soa estranha para criaturas calmas como vacas ou ovelhas, que não expressariam posse dessa forma.
  - ⚠ Fala 1 'Sempre quis ter alguém assim.' é vaga e não combina com o comportamento típico de animais de fazenda.
- nota 3: 0: Agora eu sou de o humano, e isso me faz bem. / 1: Que sorte a sua. / 0: Estou bem melhor.
  - ⚠ Fala 0 'Agora eu sou de o humano' soa estranho; o natural seria 'do humano'.
  - ⚠ Fala 1 'Que sorte a sua' é vaga e não aprofunda a conversa, mas é aceitável.
- nota 3: 0: Agora eu sou de o humano, e isso me faz bem. / 1: Sempre quis ter alguém assim. / 0: Cuida sim.
  - ⚠ Fala 1: 'Sempre quis ter alguém assim.' soa vago e não combina com a fala anterior sobre pertencer ao humano.
  - ⚠ Fala 0 (fecho): 'Cuida sim.' não fecha a conversa de forma natural; parece uma resposta a algo não dito.

### gato (3.62)  _um gato e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Creeper nenhum chega perto de mim. / 1: Cochilo é uma arte. / 0: Miau, agora vou dormir de novo.
  - ⚠ Fala 0 'Creeper nenhum chega perto de mim' não combina com gato, que não tem relação especial com creepers.
  - ⚠ Fala 1 'Cochilo é uma arte' é uma filosofia que não combina com gato, que não filosofa.
- nota 3: 0: Creeper nenhum chega perto de mim. / 1: Sol é o melhor travesseiro. / 0: Ninguém me acorda hoje.
  - ⚠ Fala 0 'Creeper nenhum chega perto de mim' não combina com gato, que não tem relação especial com creepers.
  - ⚠ Fala 1 'Sol é o melhor travesseiro' é uma metáfora incomum para um gato, que normalmente apenas dorme no sol.
- nota 2: 0: Dormi no sol a tarde toda. / 1: Eles têm medo de gato, é verdade. / 0: Miau, agora vou dormir de novo.
  - ⚠ A fala 'Eles têm medo de gato, é verdade.' não responde à fala anterior sobre dormir no sol.
  - ⚠ O fecho 'Miau, agora vou dormir de novo.' não fecha a conversa de forma coerente com a resposta anterior.
- nota 1: 0: Creeper nenhum chega perto de mim. / 1: Cochilo é uma arte. / 0: Ninguém me acorda hoje.
  - ⚠ Fala 0 'Creeper nenhum chega perto de mim' não combina com gato, que não tem relação especial com creepers.
  - ⚠ Fala 1 'Cochilo é uma arte' é filosófica demais para um gato, que não filosofa.

### golem_flor (3.62)  _um golem de ferro e dois aldeões; é de dia_
- nota 4: 0: Gosto de levar uma flor a quem trata bem os moradores. / 1: Flor combina com você, mesmo sendo de ferro. / 0: É o meu jeito de agradecer.
  - ⚠ A fala 'Flor combina com você, mesmo sendo de ferro.' soa um pouco estranha para um aldeão, pois aldeões não costumam fazer elogios poéticos; mas é aceitável.
  - ⚠ A conversa é curta e o fecho 'É o meu jeito de agradecer.' é um pouco vago, mas fecha a conversa.
- nota 3: 0: Já tem muito tempo que não vejo ninguém sorrir por aqui. / 1: Que gesto bonito. / 0: É o meu jeito de agradecer.
  - ⚠ Fala 0 'Já tem muito tempo que não vejo ninguém sorrir por aqui' soa melancólica demais para um golem de ferro, que é protetor e não costuma expressar emoções complexas.
  - ⚠ Fala 1 'Que gesto bonito' é vaga e não responde diretamente à fala anterior, que não menciona gesto algum.
- nota 3: 0: Hoje encontrei uma flor perto do caminho. / 1: Isso alegra a vila toda. / 0: Cuidar também é isso.
  - ⚠ Golem de ferro falando sobre flor e cuidado é muito poético para um golem, que normalmente é protetor e direto.
  - ⚠ A resposta do aldeão 'Isso alegra a vila toda' é genérica e não combina com a fala específica do golem.
- nota 3: 0: Hoje encontrei uma flor perto do caminho. / 1: Que gesto bonito. / 0: É o meu jeito de agradecer.
  - ⚠ Golem de ferro não fala sobre flores ou gestos bonitos; sua fala é muito poética para um golem.
  - ⚠ Aldeão responde 'Que gesto bonito' sem contexto claro de gesto, pois a fala anterior só menciona encontrar uma flor.
- nota 3: 0: Já tem muito tempo que não vejo ninguém sorrir por aqui. / 1: Flor combina com você, mesmo sendo de ferro. / 0: É o meu jeito de agradecer.
  - ⚠ Golem de ferro não costuma falar de forma sentimental ou poética; sua fala 'Já tem muito tempo que não vejo ninguém sorrir por aqui' soa filosófica demais.
  - ⚠ A resposta do aldeão 'Flor combina com você, mesmo sendo de ferro' é estranha, pois aldeões não têm costume de elogiar golems dessa forma.

### bicho_jogador_noite (3.75)  _dois animais da fazenda; é noite_
- nota 4: 0: Tem alguém andando no escuro. / 1: Eu fico quieto. / 0: Eu não sairia.
  - ⚠ Fala 1 'Eu fico quieto.' é um pouco vaga, mas aceitável para um animal assustado.
  - ⚠ Fala 0 'Eu não sairia.' soa como conselho humano, mas ainda plausível para um animal cauteloso.
- nota 4: 0: Olha lá, o humano no escuro. / 1: Eu fico quieto. / 0: Eu não sairia.
  - ⚠ Fala 1 'Eu fico quieto.' não responde diretamente à observação sobre o humano no escuro, mas é plausível como reação de medo.
  - ⚠ Fala 0 final 'Eu não sairia.' é um fecho aceitável, mas poderia ser mais conectado à fala anterior.
- nota 3: 0: Tem alguém andando no escuro. / 1: Cada um com o seu jeito. / 0: Eu não sairia.
  - ⚠ Fala 1 'Cada um com o seu jeito.' não responde diretamente à observação sobre alguém andando no escuro.
  - ⚠ Fala 0 final 'Eu não sairia.' não fecha a conversa de forma conclusiva, deixando o diálogo sem um encerramento natural.
- nota 4: 0: O humano caminha de noite. / 1: Ele não tem medo? / 0: É um bicho corajoso, esse aí.
  - ⚠ Fala 0: 'O humano caminha de noite.' soa como observação neutra, mas não especifica qual animal fala; para animais de fazenda, poderia ser mais natural algo como 'O humano anda à noite.'
  - ⚠ Fala 1: 'Ele não tem medo?' é plausível, mas poderia ser mais específico do medo noturno (ex.: 'Ele não tem medo do escuro?').
- nota 4: 0: O humano caminha de noite. / 1: Ele não tem medo? / 0: Eu não sairia.
  - ⚠ Fala 0 'O humano caminha de noite.' é uma observação neutra, mas não especifica qual animal fala; poderia ser mais característica.
  - ⚠ Fala 1 'Ele não tem medo?' é plausível, mas genérica; não reflete medo específico de mob noturno.

### jogador_apresenta (3.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador; NÃO: quem responde já conhece o jogador_
- nota 4: 0: O humano ali já esteve comigo antes. / 1: Então é bom saber quem é. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Então é bom saber quem é.' soa um pouco vaga e não responde diretamente à afirmação anterior, mas ainda é aceitável.
- nota 3: 0: O humano eu já conheço de outros dias. / 1: Nunca falei com ele. / 0: Ele é de boa conversa.
  - ⚠ A fala 'Nunca falei com ele.' não combina com a situação, pois quem responde não conhece o jogador, mas a fala sugere que já teve oportunidade de falar.
  - ⚠ A fala 'Ele é de boa conversa.' soa estranha para criaturas calmas como animais de fazenda, que normalmente não avaliam a qualidade da conversa de humanos.
- nota 4: 0: O humano eu já conheço de outros dias. / 1: Eu ainda não conhecia. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Eu ainda não conhecia.' soa um pouco ambígua, pois não fica claro se se refere ao humano ou a outra coisa, mas é aceitável no contexto.
- nota 4: 0: O humano ali já esteve comigo antes. / 1: Nunca falei com ele. / 0: Ele é de boa conversa.
  - ⚠ A fala 'Nunca falei com ele.' soa um pouco seca e não desenvolve a conversa, mas é plausível.
- nota 3: 0: Está vendo quem passou? É o humano, eu já conheço. / 1: Então é bom saber quem é. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Então é bom saber quem é.' soa vaga e não responde diretamente ao comentário anterior.
  - ⚠ O fecho 'Vale a pena conhecer.' não conclui claramente a conversa, deixando a troca sem um encerramento natural.

### bicho_filhotes_cuidado (3.88)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 3: 0: Os mais novos aprendem rápido. / 1: Eu também fico de olho neles. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Os mais novos aprendem rápido.' é genérica e não específica de animais da fazenda.
  - ⚠ Fala 1 'Eu também fico de olho neles.' soa mais humana do que animal.
- nota 4: 0: Os pequenos sempre querem brincar. / 1: Eu também fico de olho neles. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Os pequenos sempre querem brincar.' é genérica e não especifica o tipo de animal, mas ainda faz sentido para animais de fazenda.
  - ⚠ Fala 1 'Eu também fico de olho neles.' é uma resposta coerente, mas poderia ser mais específica do comportamento animal.
- nota 3: 0: Os mais novos aprendem rápido. / 1: Mas vale a pena cada dia. / 0: Que cresçam fortes.
  - ⚠ Fala 0 'Os mais novos aprendem rápido.' é genérica demais para animais de fazenda, sem referência ao mundo deles.
  - ⚠ Fala 1 'Mas vale a pena cada dia.' não responde diretamente à fala anterior, soando desconexa.
- nota 3: 0: Os pequenos sempre querem brincar. / 1: Mas vale a pena cada dia. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Os pequenos sempre querem brincar.' é genérica demais para animais da fazenda; não remete a filhotes específicos como bezerros ou pintinhos.
  - ⚠ Fala 1 'Mas vale a pena cada dia.' soa como reflexão humana sobre criação de filhos, não como fala natural de um animal.
- nota 4: 0: Cuidar dos pequenos dá trabalho. / 1: Daqui a pouco já estão grandes. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Cuidar dos pequenos dá trabalho.' é genérica e não especifica o tipo de animal, mas ainda faz sentido para animais de fazenda.
  - ⚠ Fala 1 'Daqui a pouco já estão grandes.' é plausível, mas poderia ser mais específica do animal.

### clerigo (3.88)  _villager:cleric e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dizem que meu laboratório cheira esquisito. / 1: Se alguém ficar doente, você dá um jeito. / 0: Poção boa tem de tudo um pouco.
  - ⚠ A fala 'Poção boa tem de tudo um pouco' é um pouco vaga e não fecha claramente a conversa sobre o cheiro do laboratório.
- nota 4: 0: Tem coisa estranha misturada no meu caldeirão, e funciona. / 1: Cheira mesmo, mas a gente se acostuma. / 0: É tudo ciência, juro.
  - ⚠ Fala 1 'Cheira mesmo, mas a gente se acostuma.' não responde diretamente à fala 0 sobre 'coisa estranha misturada no caldeirão'.
  - ⚠ Fala 0 final 'É tudo ciência, juro.' não fecha a conversa de forma natural, soa como uma justificativa solta.
- nota 4: 0: Dizem que meu laboratório cheira esquisito. / 1: Se alguém ficar doente, você dá um jeito. / 0: É tudo ciência, juro.
  - ⚠ A fala 'É tudo ciência, juro.' soa um pouco moderna para um aldeão clérigo, mas é aceitável.
- nota 4: 0: As poções de hoje ficaram bonitas. / 1: Se alguém ficar doente, você dá um jeito. / 0: Poção boa tem de tudo um pouco.
  - ⚠ A fala 'Poção boa tem de tudo um pouco' é um pouco vaga e não fecha claramente a conversa, mas ainda é plausível para um clérigo.
- nota 4: 0: Dizem que meu laboratório cheira esquisito. / 1: Prefiro não provar nada daí. / 0: Poção boa tem de tudo um pouco.
  - ⚠ A fala 'Poção boa tem de tudo um pouco' soa um pouco vaga e não fecha claramente a conversa sobre o cheiro do laboratório.

### curiosidade_quadrado (3.88)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Já notou que o sol nasce sempre do mesmo lado? / 1: Já! E ninguém sabe responder. / 0: Pelo menos é um mundo bonito.
  - ⚠ A fala 'Já! E ninguém sabe responder.' soa um pouco vaga e não desenvolve a conversa, mas é aceitável para aldeões.
- nota 3: 0: Você já parou para pensar por que tudo aqui é quadrado? / 1: Nunca tinha reparado, agora vou pensar nisso o dia todo. / 0: Pelo menos é um mundo bonito.
  - ⚠ A fala 'Você já parou para pensar por que tudo aqui é quadrado?' soa filosófica demais para um aldeão, que normalmente fala de trocas e trabalho.
  - ⚠ A resposta 'Nunca tinha reparado, agora vou pensar nisso o dia todo.' é plausível, mas o fecho 'Pelo menos é um mundo bonito.' não fecha a conversa de forma natural, parece um comentário solto.
- nota 4: 0: Já notou que o sol nasce sempre do mesmo lado? / 1: Já! E ninguém sabe responder. / 0: Melhor nem pensar muito nisso.
  - ⚠ A fala 'E ninguém sabe responder' soa um pouco vaga e não aprofunda a conversa, mas é aceitável para aldeões.
- nota 3: 0: Sonhei que o mundo era redondo. / 1: Já! E ninguém sabe responder. / 0: Melhor nem pensar muito nisso.
  - ⚠ A fala 'Já! E ninguém sabe responder.' não responde diretamente ao sonho do primeiro aldeão, soando desconexa.
  - ⚠ O fecho 'Melhor nem pensar muito nisso.' é vago e não conclui a conversa de forma natural.
- nota 4: 0: Já notou que o sol nasce sempre do mesmo lado? / 1: Que ideia estranha. / 0: Melhor nem pensar muito nisso.
  - ⚠ A fala 'Que ideia estranha.' soa um pouco seca e não desenvolve a conversa, mas é plausível para um aldeão.
  - ⚠ O fecho 'Melhor nem pensar muito nisso.' é um pouco vago, mas aceitável.

### jogador_nome_ambos (3.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre sabe o nome do jogador_
- nota 2: 0: Bia anda ocupado hoje. / 1: Eu também fico contente. / 0: Vou dar um oi.
  - ⚠ A fala 'Eu também fico contente.' não responde à observação 'Bia anda ocupado hoje.'
  - ⚠ O fecho 'Vou dar um oi.' não conclui a conversa de forma coerente com as falas anteriores.
- nota 4: 0: Bia voltou! Que bom ver essa pessoa. / 1: Eu também fico contente. / 0: Bom ter gente conhecida.
  - ⚠ Fala 0 'Bom ter gente conhecida.' soa um pouco artificial; 'É bom ter gente conhecida por perto.' seria mais natural.
- nota 4: 0: Bia anda ocupado hoje. / 1: É sempre bom ver Bia por aqui. / 0: Vou dar um oi.
  - ⚠ Fala 0 'Bia anda ocupado hoje.' usa 'ocupado' no masculino, mas 'Bia' é tipicamente um nome feminino; deveria ser 'ocupada'.
  - ⚠ Fala 0 'Vou dar um oi.' é um fecho um pouco abrupto, mas aceitável.
- nota 3: 0: Bia voltou! Que bom ver essa pessoa. / 1: Será que veio conversar? / 0: Vou dar um oi.
  - ⚠ Fala 0 'Bia voltou! Que bom ver essa pessoa.' soa estranho para criaturas calmas como aldeões ou animais, pois 'essa pessoa' é formal demais para uma conversa casual.
  - ⚠ Fala 1 'Será que veio conversar?' não combina com animais de fazenda, que não teriam esse tipo de pensamento.
- nota 3: 0: Olha quem está aí, Bia. / 1: Eu também fico contente. / 0: Bom ter gente conhecida.
  - ⚠ A fala 'Eu também fico contente.' não responde diretamente à primeira fala, que apenas aponta a presença de Bia.
  - ⚠ A fala 'Bom ter gente conhecida.' não fecha claramente a conversa, pois não retoma o que foi dito antes.

### warden_sculk (3.88)  _um Warden e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: O sculk sente tudo ao meu redor. / 1: O silêncio é o meu aliado. / 0: Escuta.
  - ⚠ A fala 'Escuta.' como fecho é muito vaga e não encerra a conversa de forma clara.
- nota 4: 0: Eu escuto o coração dos intrusos. / 1: Eu não preciso de olhos. / 0: Escuta.
  - ⚠ A fala 'Eu não preciso de olhos.' não responde diretamente à fala anterior sobre escutar corações, mas ainda é coerente com o Warden.
  - ⚠ O fecho 'Escuta.' é muito abrupto e não conclui claramente a conversa.
- nota 4: 0: Cada passo faz o chão vibrar. / 1: Quem corre faz mais barulho. / 0: Escuta.
  - ⚠ A fala 'Quem corre faz mais barulho.' soa um pouco genérica, mas ainda se encaixa no contexto sensorial do Warden.
  - ⚠ O fecho 'Escuta.' é muito abrupto e não conclui claramente a conversa.
- nota 4: 0: Cada passo faz o chão vibrar. / 1: Eu não preciso de olhos. / 0: Escuta.
  - ⚠ A fala 'Eu não preciso de olhos.' parece uma resposta desconexa à primeira fala, que fala sobre vibração do chão.
  - ⚠ A fala 'Escuta.' é muito vaga e não fecha claramente a conversa.
- nota 4: 0: O sculk sente tudo ao meu redor. / 1: Quem corre faz mais barulho. / 0: Quieto.
  - ⚠ A fala 'Quem corre faz mais barulho.' parece uma observação genérica, mas ainda se encaixa no contexto sensorial do Warden.
  - ⚠ O fecho 'Quieto.' é muito abrupto e pode soar como uma ordem, mas é plausível para um Warden.

### bicho_armadura (4.00)  _dois animais da fazenda; o jogador veste armadura_
- nota 4: 0: O humano veste uma armadura de ferro. Brilha até de longe. / 1: Parece pesado. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' é um pouco abstrata para animais de fazenda, mas ainda aceitável.
- nota 4: 0: O humano veste uma armadura de ferro. Brilha até de longe. / 1: Deve fazer barulho para andar. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: O humano está todo coberto de metal. / 1: Deve fazer barulho para andar. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: O que será aquilo que o humano está vestindo? / 1: Deve fazer barulho para andar. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Deve fazer barulho para andar.' é uma suposição plausível, mas não responde diretamente à pergunta 'O que será aquilo que o humano está vestindo?', deixando a conversa um pouco desconexa.
- nota 4: 0: O humano veste uma armadura de ferro. Brilha até de longe. / 1: Será que protege de lobo? / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Será que protege de lobo?' é um pouco vaga, pois não especifica se o lobo é uma ameaça real para esses animais na situação, mas ainda é plausível.

### bicho_jogador_chuva (4.00)  _dois animais da fazenda; está chovendo_
- nota 4: 0: O humano está na chuva. / 1: Fica molhado, coitado. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Cada um com o seu gosto' soa um pouco estranha para animais de fazenda, pois é uma expressão mais humana e reflexiva.
- nota 4: 0: O humano está na chuva. / 1: Eu prefiro um canto seco. / 0: Eu só queria sombra.
  - ⚠ A fala 'Eu só queria sombra' não fecha a conversa de forma clara, pois não responde diretamente à preferência por um canto seco.
- nota 4: 0: O humano está na chuva. / 1: Ele não se importa? / 0: Cada um com o seu gosto.
  - ⚠ Fala 0: 'O humano está na chuva.' é um pouco vaga, mas aceitável para animais observando.
  - ⚠ Fala 1: 'Ele não se importa?' é uma pergunta natural, mas poderia ser mais específica.
- nota 4: 0: O humano está na chuva. / 1: Eu prefiro um canto seco. / 0: Cada um com o seu gosto.
  - ⚠ Fala 0 'O humano está na chuva.' é um pouco observacional demais para um animal de fazenda, mas aceitável.
  - ⚠ Fala 1 'Eu prefiro um canto seco.' soa mais como um animal doméstico do que de fazenda, mas ainda plausível.
- nota 4: 0: Olha o humano debaixo da chuva. / 1: Fica molhado, coitado. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Cada um com o seu gosto' não se encaixa bem como fecho, pois não responde diretamente à observação anterior sobre o humano molhado.

### bicho_jogador_fome (4.00)  _dois animais da fazenda; o jogador está com fome_
- nota 4: 0: O humano deve estar faminto. / 1: A fome deixa todo mundo de mau humor. / 0: Eu entendo bem essa fome.
  - ⚠ Fala 0 'Eu entendo bem essa fome.' é um pouco vaga, mas aceitável para animais de fazenda.
- nota 4: 0: O humano deve estar faminto. / 1: A fome deixa todo mundo de mau humor. / 0: Que ache comida logo.
  - ⚠ Fala 0 'Que ache comida logo.' soa um pouco abrupta e poderia ser mais natural como 'Tomara que ele ache comida logo.'
- nota 4: 0: O humano deve estar faminto. / 1: Aqui só tem capim, mas é bom. / 0: Eu entendo bem essa fome.
  - ⚠ A fala 'Aqui só tem capim, mas é bom.' soa estranha para um animal da fazenda, pois capim é alimento natural para eles, não algo que ofereceriam a um humano faminto.
  - ⚠ A fala 'Eu entendo bem essa fome.' é vaga e não fecha a conversa de forma conclusiva.
- nota 4: 0: O humano deve estar faminto. / 1: Aqui só tem capim, mas é bom. / 0: Que ache comida logo.
  - ⚠ A fala 'Aqui só tem capim, mas é bom.' soa estranha para um animal da fazenda, pois capim é comida típica de herbívoros, mas a expressão 'mas é bom' pode soar como se o animal estivesse recomendando c
- nota 4: 0: O humano está com cara de fome. / 1: A fome deixa todo mundo de mau humor. / 0: Que ache comida logo.
  - ⚠ A fala 'Que ache comida logo.' soa um pouco abrupta e poderia ser mais natural, como 'Tomara que ele ache comida logo.'

### bruxa_pocao (4.00)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Hehe, tenho uma poção nova para testar. / 1: Hehe, a minha é ainda melhor. / 0: Hehe, a noite vai ser divertida.
  - ⚠ Fala 1: 'a minha é ainda melhor' é competitiva demais para bruxas, que costumam ser mais misteriosas e menos diretas.
  - ⚠ Fala 0 (fecho): 'a noite vai ser divertida' é vaga e não fecha claramente a conversa sobre poções.
- nota 4: 0: O caldeirão está borbulhando. / 1: Hehe, a minha é ainda melhor. / 0: Hehe, a noite vai ser divertida.
  - ⚠ Fala 1: 'Hehe, a minha é ainda melhor.' é vaga; não fica claro se 'a minha' se refere a um caldeirão ou a uma poção, o que pode confundir o ouvinte.
  - ⚠ Fala 2: 'Hehe, a noite vai ser divertida.' é um fecho aceitável, mas poderia ser mais conectado à fala anterior para fechar melhor a conversa.
- nota 4: 0: O caldeirão está borbulhando. / 1: Hehe, a minha é ainda melhor. / 0: Já sei qual receita usar.
  - ⚠ A fala 'Hehe, a minha é ainda melhor.' é um pouco vaga, mas aceitável para bruxas.
- nota 4: 0: Esse humano parece um bom voluntário. / 1: Mistura com cogumelo, dá um efeito curioso. / 0: Já sei qual receita usar.
  - ⚠ A fala 'Mistura com cogumelo, dá um efeito curioso.' é um pouco vaga, mas aceitável para bruxas.
  - ⚠ A conversa é curta e direta, mas poderia ter um fecho mais natural.
- nota 4: 0: Hehe, tenho uma poção nova para testar. / 1: Mistura com cogumelo, dá um efeito curioso. / 0: Já sei qual receita usar.
  - ⚠ A fala 'Já sei qual receita usar' não fecha claramente a conversa, pois não responde diretamente à sugestão da outra bruxa.

### creeper_zumbi (4.00)  _um creeper e um zumbi; uma situação qualquer do dia a dia_
- nota 4: 0: Ssss... não chegue perto de gato. / 1: Grrr... explode longe de mim. / 0: Ssss... silêncio.
  - ⚠ A fala 'Ssss... silêncio.' é um fecho um pouco abrupto, mas aceitável para um creeper.
- nota 4: 0: Ssss... hoje eu exploro. / 1: Grrr... explode longe de mim. / 0: Ssss...
  - ⚠ A fala do creeper 'Ssss... hoje eu exploro' é ambígua, pois 'exploro' pode ser confundido com 'explodir', mas não é um erro grave.
  - ⚠ A resposta do zumbi 'Grrr... explode longe de mim' é coerente, mas poderia ser mais natural se fosse 'explode longe de mim, não perto'.
- nota 4: 0: Ssss... não chegue perto de gato. / 1: Grrr... gato é bicho ruim. / 0: Ssss... silêncio.
  - ⚠ Fala 1 'Grrr... gato é bicho ruim.' soa infantil e não combina com o tom ameaçador de um zumbi.
  - ⚠ Fala 0 'Ssss... silêncio.' é um fecho abrupto e não responde diretamente à fala anterior.
- nota 3: 0: Ssss... hoje eu exploro. / 1: Grrr... gato é bicho ruim. / 0: Ssss...
  - ⚠ Fala 0 'Ssss... hoje eu exploro.' soa estranha para um creeper, pois creepers não 'exploram' no sentido de passear; eles se aproximam e explodem.
  - ⚠ Fala 1 'Grrr... gato é bicho ruim.' é uma resposta que não se conecta com a fala anterior sobre explorar.
- nota 3: 0: Ssss... hoje eu exploro. / 1: Grrr... gato é bicho ruim. / 0: Ssss... silêncio.
  - ⚠ Fala 0 'Ssss... hoje eu exploro.' não combina com creeper, que não explora, apenas vagueia e explode.
  - ⚠ Fala 1 'Grrr... gato é bicho ruim.' é uma resposta desconexa da fala anterior.

### jogador_ameacou (4.00)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já ameaçou quem abre com palavras (fato verificado)_
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Tem quem fale sem pensar. / 0: Vou dar uma chance.
  - ⚠ A fala 'Tem quem fale sem pensar.' é um pouco vaga e não responde diretamente à ameaça mencionada, mas ainda é plausível como comentário geral.
- nota 4: 0: Eu me assustei com as palavras de o humano outro dia. / 1: Tem quem fale sem pensar. / 0: Pode ser.
  - ⚠ Fala 0: 'Eu me assustei com as palavras de o humano outro dia.' soa estranho: 'de o humano' deveria ser 'do humano'.
  - ⚠ Fala 1: 'Tem quem fale sem pensar.' é um pouco vaga, mas aceitável.
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Ameaça de boca pesa, né? / 0: Pode ser.
  - ⚠ A fala 'Ameaça de boca pesa, né?' soa um pouco estranha para criaturas calmas, mas é aceitável como expressão coloquial.
- nota 4: 0: Eu me assustei com as palavras de o humano outro dia. / 1: Espero que tenha sido um mal-entendido. / 0: Vou dar uma chance.
  - ⚠ A fala 'Vou dar uma chance' é um pouco vaga, mas aceitável como fecho.
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Espero que tenha sido um mal-entendido. / 0: Vou dar uma chance.
  - ⚠ A fala 'Vou dar uma chance' é um pouco vaga e não fecha claramente a conversa, mas é aceitável.

### jogador_conhecido (4.00)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador_
- nota 4: 0: O humano e eu já conversamos um pouco. / 1: Me conta, o que foi que disse? / 0: Foi tranquilo, achei simpático.
  - ⚠ Fala 1 'Me conta, o que foi que disse?' soa um pouco formal para uma conversa casual entre criaturas da mesma espécie, mas é aceitável.
- nota 3: 0: Já cruzei com o humano por aqui antes. / 1: Me conta, o que foi que disse? / 0: Cada conversa é diferente.
  - ⚠ A fala 'Me conta, o que foi que disse?' soa como se a criatura esperasse que o humano tivesse dito algo específico, mas a primeira fala não menciona diálogo.
  - ⚠ O fecho 'Cada conversa é diferente.' é vago e não responde diretamente à pergunta, deixando a conversa sem conclusão clara.
- nota 3: 0: Eu já conversei com o humano, sabia? / 1: Me conta, o que foi que disse? / 0: Cada conversa é diferente.
  - ⚠ Fala 0 'Cada conversa é diferente.' não responde diretamente à pergunta 'o que foi que disse?', deixando a conversa sem fechamento claro.
  - ⚠ A fala 1 'Me conta, o que foi que disse?' soa um pouco formal para criaturas calmas, mas é aceitável.
- nota 4: 0: Eu já conversei com o humano, sabia? / 1: Que interessante. / 0: Dá para conversar numa boa.
  - ⚠ A fala 'Que interessante.' soa um pouco seca e genérica, mas é aceitável para uma criatura calma.
  - ⚠ A fala 'Dá para conversar numa boa.' é um fecho um pouco abrupto, mas ainda fecha a conversa.
- nota 4: 0: O humano e eu já conversamos um pouco. / 1: Me conta, o que foi que disse? / 0: Dá para conversar numa boa.
  - ⚠ A fala 'Dá para conversar numa boa.' não responde diretamente à pergunta 'o que foi que disse?', deixando a conversa um pouco vaga.

### medo_lobo (4.00)  _dois animais da fazenda; é noite_
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Lobo não gosta de rebanho junto. / 0: Vamos ficar de olho.
  - ⚠ A fala 'Lobo não gosta de rebanho junto.' é um pouco vaga e não responde diretamente à pergunta sobre ter ouvido um uivo.
- nota 4: 0: À noite o campo me assusta. / 1: Lobo não gosta de rebanho junto. / 0: Se vier, a gente corre.
  - ⚠ Fala 1: 'Lobo não gosta de rebanho junto' soa como um fato dito por um animal, mas é aceitável; poderia ser mais natural como 'Lobo não chega perto se a gente fica junto'.
  - ⚠ Fala 0 (fecho): 'Se vier, a gente corre' é uma resposta plausível, mas não fecha totalmente a conversa; falta um encerramento mais conclusivo.
- nota 4: 0: Escutei um rosnado lá longe. / 1: Lobo não gosta de rebanho junto. / 0: Se vier, a gente corre.
  - ⚠ A fala 'Lobo não gosta de rebanho junto.' soa um pouco estranha, pois lobos geralmente atacam rebanhos, não apenas 'não gostam' deles.
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Chega pertinho de mim, que é mais seguro. / 0: Vamos ficar de olho.
  - ⚠ A fala 'Chega pertinho de mim, que é mais seguro.' soa um pouco protetora demais para animais de fazenda, mas é aceitável.
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Lobo não gosta de rebanho junto. / 0: Se vier, a gente corre.
  - ⚠ A fala 'Lobo não gosta de rebanho junto.' soa um pouco estranha, pois lobos geralmente atacam rebanhos, então a frase pode ser interpretada como 'lobo não gosta de rebanho junto' no sentido de evitar,
  - ⚠ A fala 'Se vier, a gente corre.' é um fecho aceitável, mas poderia ser mais natural, como 'Se vier, a gente foge.'

### zumbi_esqueleto (4.00)  _um zumbi e um esqueleto; uma situação qualquer do dia a dia_
- nota 4: 0: Dá para parar de me acertar com flecha? / 1: Foi sem querer. Quase. / 0: Grrr... vamos caçar juntos.
  - ⚠ Zumbi diz 'Grrr... vamos caçar juntos' após reclamar da flechada, o que soa amigável demais para um zumbi, que normalmente é hostil e não coopera.
- nota 4: 0: Seus ossos fazem barulho demais. / 1: Foi sem querer. Quase. / 0: Hmm... tá bom.
  - ⚠ A fala 'Foi sem querer. Quase.' é um pouco vaga, mas aceitável para um esqueleto.
  - ⚠ O fecho 'Hmm... tá bom.' é curto e fecha, mas poderia ser mais característico de um zumbi.
- nota 4: 0: Dá para parar de me acertar com flecha? / 1: De perto você só arrasta o pé. / 0: Grrr... vamos caçar juntos.
  - ⚠ A fala 'De perto você só arrasta o pé.' é um pouco estranha para um esqueleto, pois não é uma resposta direta à pergunta do zumbi, mas pode ser interpretada como uma provocação.
  - ⚠ O fecho 'Grrr... vamos caçar juntos.' é aceitável, mas a transição de irritação para cooperação é abrupta.
- nota 4: 0: Você só sabe atirar de longe. / 1: De perto você só arrasta o pé. / 0: Hmm... tá bom.
  - ⚠ A fala 'Hmm... tá bom.' soa um pouco vaga e não fecha a conversa de forma clara, mas é aceitável para um zumbi.
- nota 4: 0: Dá para parar de me acertar com flecha? / 1: Seus gemidos avisam a presa. / 0: Hmm... tá bom.
  - ⚠ A fala do esqueleto 'Seus gemidos avisam a presa' é um pouco longa e formal para uma conversa casual entre mobs, mas ainda faz sentido.
  - ⚠ O fecho 'Hmm... tá bom.' é aceitável, mas poderia ser mais natural, como 'Tá bom.'

### aranha_zumbi (4.12)  _uma aranha e um zumbi; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... a sua fome é barulhenta. / 1: Grrr... teia gruda. / 0: Sss... uma corrida, então.
  - ⚠ A fala 'Grrr... teia gruda.' é um pouco vaga e não responde diretamente à provocação da aranha, mas ainda faz sentido como um comentário sobre a teia.
  - ⚠ A fala 'Sss... uma corrida, então.' é um fecho aceitável, mas poderia ser mais natural se houvesse uma conexão mais clara com a resposta do zumbi.
- nota 4: 0: Sss... a sua fome é barulhenta. / 1: Grrr... quem pegar o humano primeiro. / 0: Sss... uma corrida, então.
  - ⚠ A fala do zumbi 'Grrr... quem pegar o humano primeiro.' soa incompleta, como se faltasse um verbo ou uma conclusão, mas é aceitável como fala truncada de zumbi.
- nota 4: 0: Sss... eu fico no teto, você no chão. / 1: Grrr... teia gruda. / 0: Sss... paciência.
  - ⚠ A fala 'Grrr... teia gruda.' é um pouco vaga, mas aceitável para um zumbi.
  - ⚠ A fala 'Sss... paciência.' soa levemente filosófica para uma aranha, mas ainda dentro do personagem.
- nota 4: 0: Sss... eu fico no teto, você no chão. / 1: Grrr... quem pegar o humano primeiro. / 0: Sss... paciência.
  - ⚠ A fala 'Grrr... quem pegar o humano primeiro.' soa como um desafio, mas falta um verbo ou contexto para completar a ideia, tornando-a um pouco truncada.
- nota 4: 0: Sss... a sua fome é barulhenta. / 1: Grrr... quem pegar o humano primeiro. / 0: Sss... paciência.
  - ⚠ A fala do zumbi 'Grrr... quem pegar o humano primeiro.' soa como uma pergunta incompleta, mas pode ser interpretada como uma disputa, o que é aceitável.

### bicho_barulho_estranho (4.12)  _dois animais da fazenda; é noite_
- nota 4: 0: Escutei alguma coisa arrastando os pés. / 1: Eu me encolho quando ouço isso. / 0: Eu fico atento.
  - ⚠ Fala 1 'Eu me encolho quando ouço isso' é um pouco vaga e não especifica o que a criatura faz, mas ainda é plausível para um animal assustado.
- nota 4: 0: Tem algo gemendo no escuro. / 1: Eu me encolho quando ouço isso. / 0: Se chegar perto, a gente foge junto.
  - ⚠ Fala 0 'Tem algo gemendo no escuro' é um pouco vaga para animais de fazenda, mas aceitável.
  - ⚠ Fala 1 'Eu me encolho quando ouço isso' soa levemente humano, mas ainda plausível para um animal assustado.
- nota 4: 0: Escutei alguma coisa arrastando os pés. / 1: Eu me encolho quando ouço isso. / 0: Se chegar perto, a gente foge junto.
  - ⚠ Fala 1: 'Eu me encolho quando ouço isso' soa um pouco formal para uma conversa curta entre animais, mas ainda é aceitável.
- nota 4: 0: Escutei alguma coisa arrastando os pés. / 1: Melhor ficar longe da cerca. / 0: Eu fico atento.
  - ⚠ Fala 1 'Melhor ficar longe da cerca' é um pouco vaga, mas plausível para animais noturnos.
- nota 4: 0: Tem algo gemendo no escuro. / 1: Parece coisa de zumbi. / 0: Se chegar perto, a gente foge junto.
  - ⚠ Fala 0 'Tem algo gemendo no escuro.' é um pouco genérica, mas aceitável para animais da fazenda.
  - ⚠ Fala 1 'Parece coisa de zumbi.' pode ser estranha se os animais não conhecem zumbis, mas no contexto do jogo é plausível.

### bicho_item (4.12)  _dois animais da fazenda; o jogador segura um item; NÃO: quem abre GOSTA do que o jogador segura_
- nota 4: 0: Aquela pessoa carrega trigo. Cheiro estranho. / 1: Isso não me interessa. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Isso não me interessa.' soa um pouco seca e não desenvolve a conversa, mas é plausível para um animal desinteressado.
- nota 4: 0: Olha só, trigo na mão de o humano. O que será isso? / 1: Eu prefiro capim. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Olha só, trigo na mão de o humano. O que será isso?' soa estranha: 'o humano' em vez de 'o humano' ou 'o jogador', e a pergunta retórica não combina com a observação simples.
- nota 4: 0: O humano está com trigo. Não é de comer, né? / 1: Não parece comida. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Cada um com o seu gosto.' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: Aquela pessoa carrega trigo. Cheiro estranho. / 1: Isso não me interessa. / 0: Por mim, pode ficar com ele.
  - ⚠ Fala 1 'Isso não me interessa.' soa um pouco seco e não desenvolve a conversa, mas é plausível para um animal desinteressado.
  - ⚠ Fala 0 final 'Por mim, pode ficar com ele.' é um fecho aceitável, mas poderia ser mais natural se referisse ao trigo ou ao cheiro.
- nota 4: 0: Aquela pessoa carrega trigo. Cheiro estranho. / 1: Gente carrega cada coisa esquisita. / 0: Por mim, pode ficar com ele.
  - ⚠ A fala 'Aquela pessoa carrega trigo. Cheiro estranho.' é um pouco vaga: não fica claro por que o trigo teria cheiro estranho para um animal de fazenda, já que trigo é comum e geralmente atrativo.
  - ⚠ A resposta 'Gente carrega cada coisa esquisita.' é genérica e não desenvolve a estranheza mencionada, mas ainda é plausível.

### ceu_estrelas (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite; o céu está limpo_
- nota 3: 0: A lua está bonita hoje. / 1: Nunca vi tantas juntas. / 0: Mas fica por perto.
  - ⚠ A resposta 'Nunca vi tantas juntas' não conecta bem com 'A lua está bonita hoje' — 'tantas juntas' fica ambíguo (estrelas? luas?)
  - ⚠ O fecho 'Mas fica por perto' soa desconexo do que foi dito antes, não fecha a conversa de forma clara
- nota 4: 0: A lua está bonita hoje. / 1: Cada uma parece uma luzinha. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' não fecha a conversa de forma natural, pois não responde diretamente à observação anterior sobre as luzinhas.
- nota 4: 0: O céu está cheio de estrelas. / 1: Cada uma parece uma luzinha. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' não fecha a conversa de forma natural, pois não se conecta claramente com as falas anteriores sobre estrelas.
- nota 4: 0: A lua está bonita hoje. / 1: A noite fica menos assustadora assim. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' soa um pouco vaga e não fecha a conversa de forma clara, embora seja plausível como um pedido de companhia.
- nota 4: 0: Dá para ver as estrelas hoje. / 1: Cada uma parece uma luzinha. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' não fecha a conversa de forma natural; parece um aviso sem contexto.

### chuva (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está chovendo_
- nota 4: 0: Quando chove assim, dá vontade de ficar sem se mexer. / 1: É, o céu está bem carregado. / 0: Verdade. Vamos ver quanto tempo dura.
  - ⚠ A fala 'Quando chove assim, dá vontade de ficar sem se mexer.' é um pouco filosófica para criaturas simples como animais de fazenda ou aldeões, mas ainda aceitável.
  - ⚠ A resposta 'É, o céu está bem carregado.' é um pouco observacional demais para uma criatura que não costuma analisar o clima, mas não quebra a imersão.
- nota 4: 0: Chuva boa essa, vai regar tudo. / 1: Pelo menos as plantas agradecem. / 0: Se trovejar eu me escondo.
  - ⚠ A fala 'Se trovejar eu me escondo' é um pouco genérica e não especifica o tipo de criatura, mas ainda é plausível para animais de fazenda ou aldeões.
- nota 4: 0: Chuva boa essa, vai regar tudo. / 1: É, o céu está bem carregado. / 0: Bom, fazer o quê.
  - ⚠ A fala 'Bom, fazer o quê.' soa um pouco vaga e não fecha a conversa de forma natural, podendo ser mais específica para a situação de chuva.
- nota 3: 0: Olha só, começou a chover. / 1: Também acho. / 0: Que dure só o suficiente.
  - ⚠ A resposta 'Também acho.' não combina com a fala anterior 'Olha só, começou a chover.', pois não há opinião para concordar.
  - ⚠ O fecho 'Que dure só o suficiente.' é vago e não fecha a conversa de forma natural.
- nota 3: 0: Olha só, começou a chover. / 1: Nem me fale. / 0: Verdade. Vamos ver quanto tempo dura.
  - ⚠ Fala 1 'Nem me fale.' soa desinteressada e não combina com a fala inicial neutra sobre a chuva.
  - ⚠ Fala 0 final 'Verdade. Vamos ver quanto tempo dura.' não fecha a conversa de forma natural, parece um comentário solto.

### curiosidade_portal (4.12)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: Dizem que existe um mundo de fogo do outro lado. / 1: Também acho. / 0: Eu fico por aqui mesmo.
  - ⚠ A fala 'Também acho.' não responde diretamente à afirmação sobre o mundo de fogo, soando vaga.
  - ⚠ O fecho 'Eu fico por aqui mesmo.' não conecta claramente com a conversa anterior, deixando a interação sem conclusão lógica.
- nota 4: 0: Dizem que existe um mundo de fogo do outro lado. / 1: Pois é. / 0: Eu fico por aqui mesmo.
  - ⚠ A fala 'Pois é.' é muito vaga e não desenvolve a conversa, mas é aceitável para aldeões.
  - ⚠ A fala 'Eu fico por aqui mesmo.' fecha bem, mas poderia ser mais natural como 'Prefiro ficar por aqui.'
- nota 4: 0: Já viu um portal roxo? / 1: Deve ser um lugar bem esquisito. / 0: Vai saber o que é verdade.
  - ⚠ A fala 'Vai saber o que é verdade.' não fecha claramente a conversa, soa um pouco vaga.
- nota 4: 0: Já viu um portal roxo? / 1: Ouvi histórias, mas não sei se são verdade. / 0: Eu fico por aqui mesmo.
  - ⚠ A fala 'Eu fico por aqui mesmo.' não fecha claramente a conversa sobre o portal roxo.
- nota 4: 0: Dizem que existe um mundo de fogo do outro lado. / 1: Pois é. / 0: Vai saber o que é verdade.
  - ⚠ A fala 'Pois é.' é muito vaga e não desenvolve a conversa, mas é aceitável para aldeões.
  - ⚠ A fala 'Vai saber o que é verdade.' soa um pouco filosófica demais para aldeões, que costumam ser mais simples.

### enderman_bloco (4.12)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Gosto de levar os blocos que me agradam. / 1: É só um capricho nosso. / 0: Ninguém precisa saber.
  - ⚠ A fala 'É só um capricho nosso' soa um pouco vaga e não responde diretamente à primeira fala, mas ainda é aceitável.
  - ⚠ A fala 'Ninguém precisa saber' fecha a conversa de forma um pouco abrupta, mas faz sentido no contexto de segredo.
- nota 3: 0: Achei um bloco bonito hoje. / 1: É só um capricho nosso. / 0: Ninguém precisa saber.
  - ⚠ Fala 1 'É só um capricho nosso.' não responde diretamente à fala 0 'Achei um bloco bonito hoje.'
  - ⚠ Fala 0 'Ninguém precisa saber.' não fecha a conversa de forma clara, deixando o diálogo sem conclusão.
- nota 4: 0: Achei um bloco bonito hoje. / 1: Ninguém entende o valor de um bloco. / 0: Ninguém precisa saber.
  - ⚠ A resposta 'Ninguém entende o valor de um bloco' é um pouco filosófica demais para um enderman, que costuma ser mais direto e enigmático
  - ⚠ O fecho 'Ninguém precisa saber' é bom, mas a fala 1 já antecipa a ideia de segredo, deixando o fecho um pouco redundante
- nota 4: 0: Achei um bloco bonito hoje. / 1: É só um capricho nosso. / 0: Cada um com o seu tesouro.
  - ⚠ A fala 'É só um capricho nosso.' soa um pouco vaga e não responde diretamente ao comentário sobre o bloco bonito.
  - ⚠ O fecho 'Cada um com o seu tesouro.' é aceitável, mas poderia ser mais conectado ao contexto do bloco.
- nota 4: 0: Gosto de levar os blocos que me agradam. / 1: Ninguém entende o valor de um bloco. / 0: Cada um com o seu tesouro.
  - ⚠ A fala 'Ninguém entende o valor de um bloco.' soa um pouco filosófica demais para um enderman, que normalmente emite sons curtos e não reflete sobre valores.
  - ⚠ A fala 'Cada um com o seu tesouro.' é um fecho aceitável, mas poderia ser mais direto, como 'Bloco é bloco.'

### jogador_passando (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é de dia_
- nota 4: 0: O humano parece apressado. / 1: Gosto quando tem movimento por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Gosto quando tem movimento por aqui.' soa um pouco genérica para criaturas calmas, mas ainda é plausível.
  - ⚠ A fala 'Que siga o caminho dele.' é um fecho aceitável, mas poderia ser mais natural como 'Que ele siga o caminho dele.'
- nota 4: 0: O humano anda por aí de novo. / 1: Ele passa sempre por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para uma conversa casual entre criaturas calmas, mas ainda é aceitável.
- nota 4: 0: Olha, é o humano outra vez. / 1: Ele passa sempre por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para uma conversa casual entre criaturas da fazenda.
- nota 4: 0: O humano parece apressado. / 1: Ele passa sempre por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para uma conversa casual entre criaturas calmas.
- nota 4: 0: Vi o humano passando agora há pouco. / 1: Gosto quando tem movimento por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para uma conversa casual entre criaturas calmas.

### jogador_sem_nome (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador; NÃO: quem abre sabe o nome do jogador_
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Alguém precisa perguntar. / 0: Quem sabe um dia ele conta.
  - ⚠ A fala 'Nunca perguntei o nome de o humano.' soa estranha em português; o correto seria 'do humano'.
  - ⚠ A conversa é um pouco vaga e não se conecta claramente com a situação de já conhecer o jogador.
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Eu também só o chamo de humano. / 0: Quem sabe um dia ele conta.
  - ⚠ Fala 0: 'Nunca perguntei o nome de o humano.' soa estranho; seria mais natural 'do humano' em vez de 'de o humano'.
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Eu também só o chamo de humano. / 0: Eu pergunto da próxima vez.
  - ⚠ Fala 0: 'Nunca perguntei o nome de o humano.' soa estranho; seria mais natural 'Nunca perguntei o nome do humano.'
  - ⚠ Fala 1: 'Eu também só o chamo de humano.' é aceitável, mas poderia ser mais natural como 'Eu também só chamo ele de humano.'
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Alguém precisa perguntar. / 0: Eu pergunto da próxima vez.
  - ⚠ A fala 'Nunca perguntei o nome de o humano.' soa estranha em português; o correto seria 'do humano'.
  - ⚠ A resposta 'Alguém precisa perguntar.' é vaga e não combina perfeitamente com a fala anterior, que é uma constatação pessoal.
- nota 4: 0: O humano deve ter um nome, mas eu não sei. / 1: Alguém precisa perguntar. / 0: Eu pergunto da próxima vez.
  - ⚠ A fala 'Alguém precisa perguntar.' é um pouco vaga, mas aceitável para criaturas calmas.

### bicho_abelha (4.25)  _dois animais da fazenda; é de dia; o céu está limpo_
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: Se ninguém mexer, elas não incomodam. / 0: Que continuem trabalhando.
  - ⚠ Fala 0 'O zumbido das abelhas me faz companhia.' é um pouco filosófica para animais de fazenda, mas aceitável.
  - ⚠ Fala 1 'Se ninguém mexer, elas não incomodam.' soa mais como conselho humano do que fala de animal de fazenda.
- nota 4: 0: Tem uma abelha zumbindo perto de mim. / 1: O zumbido até acalma. / 0: Melhor deixar elas em paz.
  - ⚠ A fala 'O zumbido até acalma.' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: As abelhas hoje estão agitadas. / 1: Elas só querem as flores. / 0: Que continuem trabalhando.
  - ⚠ A fala 'Elas só querem as flores.' é um pouco vaga e não responde diretamente à agitação das abelhas, mas é aceitável.
  - ⚠ A fala 'Que continuem trabalhando.' soa levemente formal para uma conversa casual entre animais, mas ainda é natural.
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: Elas só querem as flores. / 0: Melhor deixar elas em paz.
  - ⚠ A fala 'Elas só querem as flores.' soa um pouco seca e não desenvolve a conversa, mas ainda é plausível para animais da fazenda.
- nota 4: 0: Tem uma abelha zumbindo perto de mim. / 1: Elas só querem as flores. / 0: Que continuem trabalhando.
  - ⚠ A fala 'Que continuem trabalhando' soa um pouco formal para animais da fazenda, mas ainda é aceitável.

### bicho_barulho (4.25)  _dois animais da fazenda; é noite_
- nota 4: 0: Tem alguma coisa se mexendo ali. / 1: Ouvi. Melhor ficar quieto. / 0: Vou ficar de olho.
  - ⚠ Falta especificidade: 'dois animais da fazenda' não identifica quais animais, o que dificulta avaliar se as falas combinam com o mundo de cada um.
- nota 4: 0: Tem alguma coisa se mexendo ali. / 1: Ouvi. Melhor ficar quieto. / 0: Se vier, a gente foge junto.
  - ⚠ Fala 0: 'Tem alguma coisa se mexendo ali.' é genérica, mas aceitável para animais noturnos.
  - ⚠ Fala 1: 'Ouvi. Melhor ficar quieto.' soa um pouco humano, mas plausível para animais assustados.
- nota 4: 0: Ouviu aquele barulho lá longe? / 1: Fica perto de mim. / 0: Vou ficar de olho.
  - ⚠ Fala 1 'Fica perto de mim.' soa um pouco abrupta, mas aceitável para animais assustados à noite.
- nota 4: 0: Ouviu aquele barulho lá longe? / 1: Fica perto de mim. / 0: Se vier, a gente foge junto.
  - ⚠ A fala 'Fica perto de mim.' é um pouco vaga para a resposta, mas ainda faz sentido como reação de medo.
- nota 4: 0: Tem alguma coisa se mexendo ali. / 1: Deve ser o vento. / 0: Se vier, a gente foge junto.
  - ⚠ Fala 0 'Se vier, a gente foge junto.' soa um pouco vaga e genérica, mas ainda plausível para animais assustados.

### bicho_jogador_conhecido (4.25)  _dois animais da fazenda; quem abre já conhece o jogador_
- nota 4: 0: O humano já esteve aqui antes. / 1: Aqui ele é sempre bem-vindo. / 0: Boa gente.
  - ⚠ Fala 0 'Boa gente.' é muito curta e vaga, não fecha claramente a conversa.
- nota 4: 0: Esse humano eu já conheço. / 1: Ele parece de boa índole. / 0: Boa gente.
  - ⚠ Fala 1 'Ele parece de boa índole' soa formal demais para animais de fazenda em conversa casual.
- nota 4: 0: O humano já esteve aqui antes. / 1: Ele parece de boa índole. / 0: Boa gente.
  - ⚠ Fala 1 'Ele parece de boa índole' soa formal demais para animais de fazenda em conversa casual.
  - ⚠ Fala 0 'Boa gente' é uma expressão regional que pode não soar natural para todos os jogadores.
- nota 4: 0: O cheiro do humano me é familiar. / 1: Eu também me lembro dele. / 0: Vamos ver o que ele quer hoje.
  - ⚠ Fala 0 'O cheiro do humano me é familiar.' soa um pouco formal para animais da fazenda, mas é aceitável.
  - ⚠ Fala 1 'Eu também me lembro dele.' é vaga, mas funciona como resposta.
- nota 4: 0: O humano já esteve aqui antes. / 1: Ele parece de boa índole. / 0: Vamos ver o que ele quer hoje.
  - ⚠ Fala 1 'Ele parece de boa índole' soa formal demais para animais de fazenda, que tenderiam a uma linguagem mais simples.

### curiosidade_enderman (4.25)  _dois aldeões; é noite_
- nota 4: 0: Tem uns bichos altos que levam blocos embora. / 1: Melhor não encarar, dizem que ficam bravos. / 0: Cada um com seu jeito, né?
  - ⚠ A fala 'Cada um com seu jeito, né?' soa um pouco vaga e não fecha a conversa de forma clara.
- nota 4: 0: Já viu aqueles olhos roxos no escuro? / 1: Nunca falei com um, mas tenho vontade. / 0: Deve ser uma vida estranha.
  - ⚠ A fala 'Nunca falei com um, mas tenho vontade.' é um pouco estranha para um aldeão, pois eles normalmente temem os Endermen e não expressariam vontade de falar com um.
- nota 3: 0: Já viu aqueles olhos roxos no escuro? / 1: Nunca falei com um, mas tenho vontade. / 0: Cada um com seu jeito, né?
  - ⚠ A fala 'Nunca falei com um, mas tenho vontade.' sugere curiosidade sobre Endermen, mas aldeões normalmente os temem e evitam, não expressam vontade de interagir.
  - ⚠ O fecho 'Cada um com seu jeito, né?' soa muito casual e não reflete a tensão da situação noturna.
- nota 4: 0: Dizem que enderman odeia água. / 1: Nunca falei com um, mas tenho vontade. / 0: Deve ser uma vida estranha.
  - ⚠ A fala 'Nunca falei com um, mas tenho vontade.' soa um pouco estranha para um aldeão, pois eles normalmente não demonstram curiosidade em conversar com endermen, mas é aceitável.
- nota 4: 0: Dizem que enderman odeia água. / 1: Eles somem num piscar de olhos. / 0: Cada um com seu jeito, né?
  - ⚠ A fala 'Eles somem num piscar de olhos.' não responde diretamente à fala anterior sobre enderman odiar água, mas ainda é coerente com o tema enderman.
  - ⚠ A fala 'Cada um com seu jeito, né?' é um fecho aceitável, mas um pouco vago para a conversa.

### enderman_olhar (4.25)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: A água. Mantenha-se longe da água. / 1: Eu também odeio a chuva. / 0: Melhor sumir antes que ele olhe.
  - ⚠ A fala 'Melhor sumir antes que ele olhe.' é ambígua: 'ele' pode se referir ao jogador, mas não fica claro no contexto.
- nota 4: 0: Mais um humano. Que fique longe dos meus blocos. / 1: Eu também odeio a chuva. / 0: Melhor sumir antes que ele olhe.
  - ⚠ A fala 'Eu também odeio a chuva' não responde diretamente à primeira fala sobre humanos e blocos, mas é plausível como associação de incômodos.
  - ⚠ A última fala 'Melhor sumir antes que ele olhe' fecha a conversa, mas a transição da chuva para o humano é um pouco abrupta.
- nota 4: 0: A água. Mantenha-se longe da água. / 1: Eu sinto o olhar dele. / 0: Vamos para outro lugar.
  - ⚠ A fala 'Eu sinto o olhar dele' é ambígua e não responde diretamente ao aviso sobre a água, mas pode ser interpretada como referência ao jogador, o que é plausível para endermen.
  - ⚠ A fala 'Vamos para outro lugar' fecha a conversa de forma um pouco abrupta, mas é aceitável.
- nota 3: 0: Mais um humano. Que fique longe dos meus blocos. / 1: Eu também odeio a chuva. / 0: Vamos para outro lugar.
  - ⚠ A fala 'Eu também odeio a chuva' não responde diretamente à fala anterior sobre humanos e blocos, quebrando a coerência da conversa.
  - ⚠ A fala 'Vamos para outro lugar' não fecha claramente a conversa iniciada sobre humanos e blocos, parecendo uma mudança abrupta de assunto.
- nota 4: 0: Não olhe nos olhos. Ele nos vê. / 1: Eu também odeio a chuva. / 0: Vamos para outro lugar.
  - ⚠ A fala 'Eu também odeio a chuva.' não responde diretamente à fala anterior 'Não olhe nos olhos. Ele nos vê.', mas é plausível como associação de desconfortos.
  - ⚠ A fala 'Vamos para outro lugar.' fecha a conversa de forma um pouco abrupta, mas aceitável.

### fome_bicho (4.25)  _dois animais da fazenda; é de dia_
- nota 4: 0: Estou com uma fome danada. / 1: Eu também estou com o estômago vazio. / 0: Vamos esperar mais um pouco.
  - ⚠ A fala 'Vamos esperar mais um pouco.' não fecha claramente a conversa, deixando a situação em aberto.
- nota 4: 0: Já passou da hora de comer. / 1: Eu também estou com o estômago vazio. / 0: Quem chegar primeiro na comida, come.
  - ⚠ Fala 0 'Já passou da hora de comer.' é genérica e não especifica o tipo de animal, mas aceitável para animais de fazenda.
  - ⚠ Fala 1 'Eu também estou com o estômago vazio.' soa um pouco formal para animais, mas ainda natural.
- nota 4: 0: Já passou da hora de comer. / 1: Vou procurar uma touceira de grama. / 0: Vamos esperar mais um pouco.
  - ⚠ A fala 'Vamos esperar mais um pouco' não fecha a conversa de forma conclusiva, deixando a interação sem um desfecho claro.
- nota 4: 0: Fico de olho para ver se aparece comida. / 1: O cheiro de feno me deixa com mais fome. / 0: Vamos esperar mais um pouco.
  - ⚠ A fala 'O cheiro de feno me deixa com mais fome' é um pouco estranha, pois feno é o alimento, então o cheiro deveria saciar ou atrair, não aumentar a fome.
- nota 4: 0: Fico de olho para ver se aparece comida. / 1: Vou procurar uma touceira de grama. / 0: Quem chegar primeiro na comida, come.
  - ⚠ A fala 'Quem chegar primeiro na comida, come.' soa um pouco competitiva demais para animais de fazenda, que normalmente não disputam comida dessa forma.

### jogador_fome (4.25)  _dois aldeões; o jogador está com fome_
- nota 4: 0: O humano está com cara de fome. / 1: Dava para oferecer um pouco de pão. / 0: Que ache o que comer.
  - ⚠ A fala 'Que ache o que comer.' soa um pouco rude para um aldeão, que normalmente é prestativo, mas ainda é plausível.
- nota 4: 0: Acho que o humano não come há um tempo. / 1: Comida resolve metade dos problemas. / 0: Que ache o que comer.
  - ⚠ A fala 'Comida resolve metade dos problemas.' soa um pouco filosófica demais para um aldeão, que tende a ser mais prático e simples.
- nota 4: 0: Acho que o humano não come há um tempo. / 1: Comida resolve metade dos problemas. / 0: Se ele pedir, eu dou um jeito.
  - ⚠ A fala 'Comida resolve metade dos problemas.' soa um pouco filosófica demais para um aldeão, que tende a ser mais prático e simples.
- nota 4: 0: Acho que o humano não come há um tempo. / 1: Dava para oferecer um pouco de pão. / 0: Que ache o que comer.
  - ⚠ A fala 'Que ache o que comer.' soa um pouco seca e menos natural como fecho, mas ainda faz sentido para aldeões.
- nota 4: 0: O humano está com cara de fome. / 1: Comida resolve metade dos problemas. / 0: Que ache o que comer.
  - ⚠ A fala 'Comida resolve metade dos problemas' soa um pouco filosófica demais para um aldeão comum, mas ainda é plausível.

### jogador_monstros_visto (4.25)  _dois monstros hostis; uma situação qualquer do dia a dia_
- nota 4: 0: Aquele humano não está nos vendo. / 1: Eu chego pela esquerda. / 0: Eu avisei.
  - ⚠ Fala 1 'Eu chego pela esquerda.' é um pouco vaga, mas plausível para monstros coordenando um ataque.
- nota 4: 0: Tem um humano ali. / 1: Cuidado com o que ele carrega. / 0: Eu avisei.
  - ⚠ Fala 0 'Eu avisei.' é um fecho um pouco vago, mas aceitável para monstros hostis.
- nota 4: 0: Humano à vista. / 1: Cuidado com o que ele carrega. / 0: Eu avisei.
  - ⚠ Fala 0 'Eu avisei.' soa um pouco vaga como fecho, mas é aceitável.
- nota 4: 0: Aquele humano não está nos vendo. / 1: Silêncio, chega mais perto. / 0: Eu avisei.
  - ⚠ A fala 'Eu avisei.' não fecha claramente a conversa, pois não responde diretamente à ordem 'Silêncio, chega mais perto.'
- nota 4: 0: Aquele humano não está nos vendo. / 1: Eu chego pela esquerda. / 0: Agora não. Espera o momento certo.
  - ⚠ Fala 1 'Eu chego pela esquerda.' soa um pouco tática demais para monstros hostis genéricos, mas ainda plausível.

### vila_gato (4.25)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Um gato dormindo na porta dá sorte. / 1: Creeper nem chega perto de um gato. / 0: Cada um com o seu trabalho.
  - ⚠ A fala 'Cada um com o seu trabalho.' não fecha claramente a conversa, soa desconexa das anteriores.
- nota 4: 0: Um gato dormindo na porta dá sorte. / 1: Gato quieto é gato em guarda. / 0: Gato é bem-vindo em qualquer casa.
  - ⚠ A fala 'Gato quieto é gato em guarda' soa um pouco enigmática para um aldeão, mas ainda aceitável.
  - ⚠ A sequência de falas não se conecta perfeitamente: a primeira fala sobre sorte, a segunda sobre guarda, e a terceira volta para boas-vindas, sem um fecho claro.
- nota 4: 0: Um gato dormindo na porta dá sorte. / 1: Eu deixo leite para o gato da vila. / 0: Gato é bem-vindo em qualquer casa.
  - ⚠ A fala 'Eu deixo leite para o gato da vila.' é um pouco específica e pode soar estranha como resposta direta, mas ainda é plausível para um aldeão.
  - ⚠ A fala 'Gato é bem-vindo em qualquer casa.' é um fecho aceitável, mas poderia ser mais natural se conectasse melhor com a fala anterior.
- nota 4: 0: Gato na vila é bom para afastar creeper. / 1: Creeper nem chega perto de um gato. / 0: Cada um com o seu trabalho.
  - ⚠ A fala 'Cada um com o seu trabalho.' não fecha claramente a conversa sobre gatos e creepers.
- nota 4: 0: Gato na vila é bom para afastar creeper. / 1: Eu deixo leite para o gato da vila. / 0: Cada um com o seu trabalho.
  - ⚠ Fala 1 'Eu deixo leite para o gato da vila' é um pouco estranha, pois gatos não bebem leite no Minecraft e aldeões não têm esse costume.
  - ⚠ Fala 2 'Cada um com o seu trabalho' não fecha claramente a conversa, soa como um comentário solto.

### acougueiro (4.38)  _villager:butcher e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: A carne de hoje está bem fresca. / 1: Cada ofício tem a sua importância. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A resposta 'Cada ofício tem a sua importância.' não responde diretamente à fala sobre a carne fresca, soando um pouco deslocada.
  - ⚠ O fecho 'Passa aqui quando quiser levar um pedaço.' é coerente, mas a conversa como um todo parece genérica demais para a situação 'qualquer do dia a dia'.
- nota 4: 0: A carne de hoje está bem fresca. / 1: Sem você, a vila passaria fome. / 0: O fogo do defumador nunca apaga.
  - ⚠ A fala 'Sem você, a vila passaria fome.' soa um pouco formal demais para uma conversa casual entre aldeões, mas ainda é plausível.
- nota 4: 0: Cortar carne é um ofício que exige respeito. / 1: Sem você, a vila passaria fome. / 0: O fogo do defumador nunca apaga.
  - ⚠ A fala 'O fogo do defumador nunca apaga' soa um pouco poética demais para um aldeão açougueiro em conversa cotidiana, mas ainda é aceitável.
- nota 4: 0: Meu cutelo está afiado como nunca. / 1: Cada ofício tem a sua importância. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A fala 'Passa aqui quando quiser levar um pedaço' soa um pouco vaga, mas ainda faz sentido para um açougueiro oferecendo carne.
- nota 4: 0: Meu cutelo está afiado como nunca. / 1: Cheiro de carne assando chama todo mundo. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A fala 'Cheiro de carne assando chama todo mundo.' não responde diretamente à primeira fala sobre o cutelo afiado, mas ainda é plausível como comentário de um aldeão açougueiro.
  - ⚠ A fala final 'Passa aqui quando quiser levar um pedaço.' soa um pouco como convite comercial, mas é aceitável para um açougueiro.

### aranha_presa (4.38)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... o humano é muito barulhento. / 1: Sss... a teia faz o serviço sozinha. / 0: Sss... silêncio agora.
  - ⚠ A fala 'Sss... a teia faz o serviço sozinha.' não responde diretamente à observação sobre o humano barulhento, mas ainda é plausível como comentário paralelo.
  - ⚠ O fecho 'Sss... silêncio agora.' é abrupto, mas aceitável para aranhas que valorizam o silêncio.
- nota 4: 0: Sss... o que se mexe vira jantar. / 1: Sss... paciência é tudo. / 0: Sss... quase.
  - ⚠ A fala 'Sss... paciência é tudo.' soa filosófica demais para uma aranha, que normalmente tem falas instintivas e curtas.
  - ⚠ O fecho 'Sss... quase.' é vago e não encerra claramente a conversa.
- nota 4: 0: Sss... o que se mexe vira jantar. / 1: Sss... a teia faz o serviço sozinha. / 0: Sss... quase.
  - ⚠ A fala 'Sss... quase.' é vaga e não fecha claramente a conversa, deixando o sentido ambíguo.
- nota 4: 0: Sss... o humano é muito barulhento. / 1: Sss... paciência é tudo. / 0: Sss... quase.
  - ⚠ A fala 'Sss... quase.' é vaga e não fecha claramente a conversa.

### armeiro (4.38)  _villager:armorer e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Ferro bem forjado é meio caminho andado. / 1: Deve ser pesado trabalhar com tanto metal. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 'O fogo da forja não pode apagar.' não responde diretamente à observação 'Deve ser pesado trabalhar com tanto metal.', mas ainda assim fecha a conversa de forma coerente com o tema.
- nota 4: 0: A armadura sai melhor com o fogo forte. / 1: Quem usa uma peça sua fica mais seguro. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 'Quem usa uma peça sua fica mais seguro.' soa um pouco genérica e não responde diretamente ao comentário sobre o fogo forte.
  - ⚠ O fecho 'O fogo da forja não pode apagar.' é coerente, mas a conversa parece um pouco fragmentada, sem uma progressão clara.
- nota 4: 0: A armadura sai melhor com o fogo forte. / 1: O barulho da forja é música. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 1 'O barulho da forja é música' é um pouco poética/filosófica demais para um aldeão, mas ainda passável
  - ⚠ O fecho 'O fogo da forja não pode apagar' repete a ideia da fala 0 sem acrescentar nada, soa um pouco circular
- nota 4: 0: Ferro bem forjado é meio caminho andado. / 1: Quem usa uma peça sua fica mais seguro. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 'Quem usa uma peça sua fica mais seguro.' soa um pouco genérica e não responde diretamente à primeira fala sobre forjar ferro.
  - ⚠ O fecho 'O fogo da forja não pode apagar.' é um pouco abrupto e não conclui claramente a conversa.
- nota 4: 0: Cada peça de armadura conta uma história. / 1: Deve ser pesado trabalhar com tanto metal. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 'O fogo da forja não pode apagar.' não fecha diretamente a conversa, soa mais como um comentário solto.

### bicho_jogador_ferido (4.38)  _dois animais da fazenda; o jogador está ferido_
- nota 4: 0: Olha como o humano anda devagar. / 1: Dá pena ver. / 0: Que melhore logo.
  - ⚠ Fala 0 'Olha como o humano anda devagar.' é um pouco vaga para a situação de ferimento, mas ainda plausível.
  - ⚠ Fala 1 'Dá pena ver.' é curta e adequada, mas poderia ser mais específica sobre o ferimento.
- nota 4: 0: O humano parece sentir dor. / 1: Eu fico quieto para não incomodar. / 0: Que melhore logo.
  - ⚠ Fala 1: 'Eu fico quieto para não incomodar.' soa um pouco estranho para um animal de fazenda, pois sugere uma intenção consciente de não incomodar, o que é mais humano do que animal.
- nota 4: 0: Olha como o humano anda devagar. / 1: Eu fico quieto para não incomodar. / 0: Que melhore logo.
  - ⚠ Fala 1: 'Eu fico quieto para não incomodar' soa mais como um pensamento humano do que algo que um animal diria, mas é aceitável no contexto do jogo.
- nota 4: 0: Olha como o humano anda devagar. / 1: Ele devia descansar à sombra. / 0: Que melhore logo.
  - ⚠ Fala 0 'Olha como o humano anda devagar.' é um pouco vaga para a situação de ferimento, mas ainda plausível.
  - ⚠ Fala 1 'Ele devia descansar à sombra.' sugere descanso, mas não menciona ferimento, o que seria mais natural.
- nota 4: 0: O humano está machucado. / 1: Dá pena ver. / 0: Fico de olho nele.
  - ⚠ Fala 1 'Dá pena ver.' é um pouco vaga, mas aceitável para animais da fazenda.
  - ⚠ Fala 0 'Fico de olho nele.' soa levemente protetora demais para um animal, mas ainda plausível.

### bicho_noite_lua (4.38)  _dois animais da fazenda; é noite; o céu está limpo_
- nota 4: 0: A lua está grande hoje. / 1: Fica mais fácil de enxergar o perigo. / 0: Fica por perto.
  - ⚠ A fala 'Fica por perto.' é um pouco vaga, mas aceitável como fecho.
- nota 4: 0: A lua está grande hoje. / 1: Fica mais fácil de enxergar o perigo. / 0: Que a noite passe tranquila.
  - ⚠ A fala 'Fica mais fácil de enxergar o perigo.' soa um pouco genérica para animais de fazenda, que normalmente não falam de 'perigo' de forma abstrata, mas é aceitável no contexto do jogo.
- nota 4: 0: A noite está clara. / 1: A luz da lua acalma. / 0: Fica por perto.
  - ⚠ Fala 0 'Fica por perto.' é um pouco vaga para fechar a conversa, mas aceitável.
- nota 4: 0: A noite está clara. / 1: Fica mais fácil de enxergar o perigo. / 0: Fica por perto.
  - ⚠ Fala 1: 'Fica mais fácil de enxergar o perigo.' soa um pouco genérica para animais de fazenda, mas ainda plausível.
  - ⚠ Fala 0 (fecho): 'Fica por perto.' é um pouco vaga, mas aceitável como conselho entre animais.

### bicho_quer_comida (4.38)  _dois animais da fazenda; o jogador segura um item; quem abre GOSTA do que o jogador segura_
- nota 4: 0: Trigo! É o meu favorito. Será que ele divide? / 1: Ele nem olhou para nós, que pena. / 0: Quem sabe ele se compadece.
  - ⚠ A fala 'Ele nem olhou para nós, que pena.' soa mais como um lamento humano do que como algo que um animal de fazenda diria, mas ainda é aceitável.
- nota 4: 0: O humano está com trigo. Queria um pouco também. / 1: Eu também queria. / 0: Eu espero aqui, bem quieto.
  - ⚠ A fala 'Eu espero aqui, bem quieto.' não fecha claramente a conversa; parece mais uma continuação do que um fecho.
- nota 4: 0: Olha só, trigo na mão de o humano. Será que é para mim? / 1: Ele nem olhou para nós, que pena. / 0: Quem sabe ele se compadece.
  - ⚠ A fala 'Ele nem olhou para nós, que pena.' não responde diretamente à pergunta 'Será que é para mim?', mas ainda é plausível como comentário.
  - ⚠ A fala 'Quem sabe ele se compadece.' fecha a conversa de forma um pouco vaga, mas aceitável.
- nota 4: 0: O humano está com trigo. Queria um pouco também. / 1: Ele nem olhou para nós, que pena. / 0: Vou chegar de mansinho.
  - ⚠ A fala 'Vou chegar de mansinho' não deixa claro qual animal está falando, mas é aceitável para animais da fazenda.
- nota 4: 0: O humano está com trigo. Queria um pouco também. / 1: Ele nem olhou para nós, que pena. / 0: Quem sabe ele se compadece.
  - ⚠ A fala 'Quem sabe ele se compadece.' soa um pouco formal para animais da fazenda, mas ainda é aceitável.

### bruxa_cogumelo (4.38)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Pântano bom é o que tem cogumelo à vontade. / 1: Meu caldeirão está sempre fervendo. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à fala anterior sobre cogumelos, mas ainda é plausível como comentário de bruxa.
  - ⚠ A fala 'Já sei qual testar primeiro.' é um fecho um pouco vago, mas aceitável no contexto de poções.
- nota 4: 0: O cogumelo de hoje deu uma poção ótima. / 1: Meu caldeirão está sempre fervendo. / 0: Hehe, a receita é segredo.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à poção mencionada, mas é aceitável como comentário relacionado.
- nota 4: 0: O cogumelo de hoje deu uma poção ótima. / 1: Meu caldeirão está sempre fervendo. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à fala anterior sobre o cogumelo, mas é aceitável como comentário relacionado.
  - ⚠ A fala 'Já sei qual testar primeiro.' fecha a conversa de forma um pouco vaga, mas ainda faz sentido no contexto.
- nota 4: 0: Cada ingrediente tem a sua hora. / 1: Eu misturo de tudo um pouco. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Eu misturo de tudo um pouco' é um pouco vaga e não responde diretamente à primeira fala sobre o tempo dos ingredientes.
  - ⚠ O fecho 'Já sei qual testar primeiro' não conecta claramente com a resposta anterior, deixando a conversa um pouco solta.
- nota 4: 0: O cogumelo de hoje deu uma poção ótima. / 1: Eu misturo de tudo um pouco. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Eu misturo de tudo um pouco.' é um pouco vaga e não responde diretamente à primeira fala sobre o cogumelo ter dado uma poção ótima.

### esqueleto_sombra (4.38)  _um esqueleto e outra criatura da mesma espécie; é de dia_
- nota 4: 0: De dia eu me escondo. / 1: Dia é bom para ficar parado. / 0: Falta pouco para a minha hora.
  - ⚠ Fala 1: 'Dia é bom para ficar parado' soa estranho para esqueletos, que queimam à luz do dia; ficar parado não é uma vantagem, mas sim uma necessidade de se esconder.
  - ⚠ Fala 0 (fecho): 'Falta pouco para a minha hora' é ambíguo e pode sugerir morte iminente, o que não combina com a situação de apenas se esconder durante o dia.
- nota 4: 0: Fico sempre perto de uma sombra. / 1: Dia é bom para ficar parado. / 0: Falta pouco para a minha hora.
  - ⚠ A fala 'Falta pouco para a minha hora' é vaga e pode soar estranha para um esqueleto, que não tem um conceito claro de 'hora' ou morte iminente.
  - ⚠ A resposta 'Dia é bom para ficar parado' não conecta diretamente com a fala anterior sobre sombra, embora seja coerente com o comportamento de esqueletos.
- nota 4: 0: De dia eu me escondo. / 1: Dia é bom para ficar parado. / 0: Quando escurecer, eu atiro.
  - ⚠ Fala 1: 'Dia é bom para ficar parado' soa estranho para esqueletos, que normalmente evitam o dia e não o consideram bom.
- nota 4: 0: De dia eu me escondo. / 1: À noite a mira é melhor. / 0: Falta pouco para a minha hora.
  - ⚠ A resposta 'À noite a mira é melhor' não conecta bem com 'De dia eu me escondo' — fala de mira (arqueiro) mas o esqueleto não menciona arco
  - ⚠ O fecho 'Falta pouco para a minha hora' é vago; não fecha claramente a conversa sobre esconder-se de dia
- nota 4: 0: Fico sempre perto de uma sombra. / 1: Quem se queima não acerta nada. / 0: Falta pouco para a minha hora.
  - ⚠ A fala 'Falta pouco para a minha hora' é um pouco vaga, mas pode ser interpretada como a hora de queimar ao sol, o que faz sentido para um esqueleto.

### ferreiro_armas (4.38)  _villager:weaponsmith e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Afiar uma espada pede paciência. / 1: Isso é arte, não só ofício. / 0: Arma boa é a que não precisa sair da bainha.
  - ⚠ O fecho 'Arma boa é a que não precisa sair da bainha' soa mais a provérbio filosófico do que a fala curta de aldeão ferreiro, embora passe como sabedoria de ofício
- nota 4: 0: Afiar uma espada pede paciência. / 1: Isso é arte, não só ofício. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'Isso é arte, não só ofício.' soa um pouco filosófica demais para um aldeão comum, mas ainda aceitável.
  - ⚠ A última fala 'Mais um dia, mais uma lâmina.' é um fecho um pouco genérico, mas funciona.
- nota 4: 0: Hoje o machado ficou perfeito. / 1: Espero que nunca precisem usar. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'Mais um dia, mais uma lâmina.' soa um pouco filosófica demais para um aldeão armeiro, mas ainda é aceitável.
- nota 4: 0: Uma lâmina boa nunca precisa de pressa. / 1: Espero que nunca precisem usar. / 0: Arma boa é a que não precisa sair da bainha.
  - ⚠ A fala 'Arma boa é a que não precisa sair da bainha' é um provérbio que soa filosófico demais para um aldeão armeiro em conversa cotidiana.
- nota 4: 0: Afiar uma espada pede paciência. / 1: Espero que nunca precisem usar. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'Espero que nunca precisem usar.' é um pouco vaga, mas aceitável para um aldeão.
  - ⚠ O fecho 'Mais um dia, mais uma lâmina.' soa um pouco poético demais para um ferreiro aldeão, mas ainda plausível.

### galinha (4.38)  _uma galinha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Có có! Achei umas sementes no chão. / 1: Ovo novo é sempre uma alegria. / 0: Então vou ciscar mais um pouco.
  - ⚠ A resposta 'Ovo novo é sempre uma alegria.' não combina com a fala anterior sobre sementes.
  - ⚠ O fecho 'Então vou ciscar mais um pouco.' não fecha a conversa de forma coerente com a resposta.
- nota 3: 0: Có có! Achei umas sementes no chão. / 1: Ovo novo é sempre uma alegria. / 0: Có có, a vida é boa.
  - ⚠ A resposta 'Ovo novo é sempre uma alegria.' não combina diretamente com a fala anterior sobre sementes.
  - ⚠ O fecho 'Có có, a vida é boa.' é genérico e não encerra a conversa de forma natural.
- nota 4: 0: Botei um ovo e já cacarejei para todo mundo. / 1: Có, eu fico de olho no céu, por via das dúvidas. / 0: Có có, a vida é boa.
  - ⚠ A fala 'Có có, a vida é boa.' soa um pouco filosófica demais para uma galinha, mas ainda é aceitável.

### jogador_presente (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já deu um presente a quem abre (fato verificado)_
- nota 4: 0: O humano me deu um presente outro dia. Fiquei com o coração quentinho. / 1: Pelo visto é gente boa. / 0: Nunca esqueci.
  - ⚠ A fala 'Fiquei com o coração quentinho' soa um pouco sentimental demais para criaturas calmas como aldeões ou animais de fazenda, que tendem a expressões mais simples.
  - ⚠ A resposta 'Pelo visto é gente boa' é um pouco genérica e não desenvolve a conversa, mas é aceitável.
- nota 4: 0: Sabia que o humano já me presenteou? / 1: Pelo visto é gente boa. / 0: Foi um dia especial.
  - ⚠ A fala 'Foi um dia especial.' é um pouco vaga e não fecha claramente a conversa, mas é aceitável.
- nota 4: 0: Ninguém tinha me dado um presente antes de o humano. / 1: Pelo visto é gente boa. / 0: Nunca esqueci.
  - ⚠ A fala 'Nunca esqueci.' soa um pouco estranha como fecho, pois não responde diretamente à fala anterior e parece desconectada do contexto imediato.
- nota 4: 0: O humano me deu um presente outro dia. Fiquei com o coração quentinho. / 1: Que gesto bonito. / 0: Nunca esqueci.
  - ⚠ A fala 'Fiquei com o coração quentinho' é um pouco sentimental demais para criaturas como vacas ou aldeões, que tendem a expressões mais simples.
  - ⚠ A resposta 'Que gesto bonito' é genérica e poderia ser mais específica ao presente ou à relação entre as criaturas.
- nota 4: 0: Sabia que o humano já me presenteou? / 1: Poucos fazem isso. / 0: Foi um dia especial.
  - ⚠ A fala 'Foi um dia especial.' é um pouco vaga e não fecha a conversa de forma clara, deixando a interação sem um encerramento natural.

### jogador_traiu (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já quebrou um acordo com quem abre (fato verificado)_
- nota 4: 0: O humano quebrou a nossa palavra. Eu me lembro. / 1: Que pena, parecia uma pessoa correta. / 0: Quem sabe um dia melhore.
  - ⚠ A fala 'O humano quebrou a nossa palavra. Eu me lembro.' soa um pouco formal para criaturas calmas como aldeões ou animais, mas ainda é aceitável.
  - ⚠ A resposta 'Que pena, parecia uma pessoa correta.' é um pouco filosófica para animais, mas se forem aldeões, faz sentido.
- nota 4: 0: Fizemos um acordo, e o humano acabou com ele. / 1: Palavra quebrada é difícil de perdoar. / 0: Quem sabe um dia melhore.
  - ⚠ A fala 'Quem sabe um dia melhore.' soa um pouco vaga e não fecha a conversa de forma conclusiva, mas é aceitável.
- nota 4: 0: O humano quebrou a nossa palavra. Eu me lembro. / 1: Que pena, parecia uma pessoa correta. / 0: Pois é, dói.
  - ⚠ A fala 'O humano quebrou a nossa palavra. Eu me lembro.' soa um pouco formal para criaturas calmas como aldeões ou animais, mas é aceitável.
  - ⚠ A fala 'Que pena, parecia uma pessoa correta.' é um pouco longa para uma conversa curta, mas ainda natural.
- nota 4: 0: O humano quebrou a nossa palavra. Eu me lembro. / 1: Então não dá para confiar tanto. / 0: Pois é, dói.
  - ⚠ A fala 'O humano quebrou a nossa palavra. Eu me lembro.' soa um pouco formal para criaturas calmas, mas ainda aceitável.
  - ⚠ A fala 'Pois é, dói.' é muito vaga e não fecha claramente a conversa, deixando o fecho um pouco fraco.
- nota 4: 0: O humano quebrou a nossa palavra. Eu me lembro. / 1: Palavra quebrada é difícil de perdoar. / 0: Quem sabe um dia melhore.
  - ⚠ A fala 'O humano quebrou a nossa palavra. Eu me lembro.' soa um pouco formal para criaturas calmas, mas é aceitável.
  - ⚠ A fala 'Quem sabe um dia melhore.' é um fecho um pouco vago, mas fecha a conversa de forma natural.

### monstros_armadura (4.38)  _dois monstros hostis; o jogador veste armadura_
- nota 4: 0: Olha só, o humano trouxe uma armadura de ferro. / 1: A gente cansa ele primeiro. / 0: Paciência vence qualquer armadura.
  - ⚠ 'Paciência vence qualquer armadura' soa um pouco aforístico/filosófico para um monstro hostil, mas ainda passa como tática de combate
- nota 4: 0: O humano veste uma armadura de ferro. Vai dar trabalho. / 1: Todo metal cansa no fim. / 0: Cada brecha serve.
  - ⚠ A fala 'Todo metal cansa no fim.' soa filosófica demais para monstros hostis, que normalmente não refletem sobre desgaste de materiais.
- nota 4: 0: Olha só, o humano trouxe uma armadura de ferro. / 1: Todo metal cansa no fim. / 0: Cada brecha serve.
  - ⚠ A fala 'Todo metal cansa no fim.' soa filosófica demais para monstros hostis, que normalmente não refletem sobre desgaste de materiais.
- nota 4: 0: Aquele humano está com uma armadura de ferro. / 1: A gente cansa ele primeiro. / 0: Cada brecha serve.
  - ⚠ A fala 'A gente cansa ele primeiro.' soa um pouco vaga, mas é plausível para monstros hostis.
- nota 4: 0: Aquele humano está com uma armadura de ferro. / 1: Eu espero ele baixar a guarda. / 0: Paciência vence qualquer armadura.
  - ⚠ A fala 'Paciência vence qualquer armadura.' soa um pouco filosófica demais para monstros hostis, que normalmente são mais diretos e agressivos.

### monstros_chuva (4.38)  _dois monstros hostis; está chovendo_
- nota 4: 0: Chuva de novo, que droga. / 1: Pelo menos a escuridão fica melhor. / 0: Eu espero aqui no escuro.
  - ⚠ A fala 'Eu espero aqui no escuro.' não fecha claramente a conversa, soa como uma continuação.
- nota 4: 0: Chuva de novo, que droga. / 1: Os humanos ficam trancados, mas é irritante. / 0: Eu espero aqui no escuro.
  - ⚠ A fala 'Eu espero aqui no escuro.' não fecha claramente a conversa, soa como uma mudança de assunto.
- nota 4: 0: A água me deixa de mau humor. / 1: Os humanos ficam trancados, mas é irritante. / 0: Depois a caça recomeça.
  - ⚠ A fala 'Os humanos ficam trancados, mas é irritante.' é um pouco vaga: não fica claro se o irritante é a chuva ou os humanos trancados.
- nota 4: 0: Essa chuva apaga tudo que a gente rastreia. / 1: Os humanos ficam trancados, mas é irritante. / 0: Eu espero aqui no escuro.
  - ⚠ A fala 'Eu espero aqui no escuro.' não fecha claramente a conversa, soa como uma mudança abrupta de tópico.
- nota 4: 0: Essa chuva apaga tudo que a gente rastreia. / 1: Pelo menos a escuridão fica melhor. / 0: Eu espero aqui no escuro.
  - ⚠ A fala 'Eu espero aqui no escuro.' não fecha claramente a conversa, soa como uma continuação.

### monstros_item (4.38)  _dois monstros hostis; o jogador segura um item_
- nota 4: 0: O humano segura uma espada de ferro. / 1: Ele ainda não nos viu. / 0: Agora não.
  - ⚠ A fala 'Agora não.' é ambígua e não fecha claramente a conversa, podendo soar como uma ordem sem contexto.
- nota 4: 0: O humano carrega uma espada de ferro. Cuidado. / 1: Eu vou pela esquerda. / 0: Agora não.
  - ⚠ A fala 'Agora não.' é um fecho vago que não encerra claramente a conversa ou a ação.
- nota 4: 0: Aquele humano tem uma espada de ferro na mão. / 1: Eu vou pela esquerda. / 0: Agora não.
  - ⚠ O fecho 'Agora não.' é um pouco vago e não fecha claramente a conversa iniciada pela fala 1

### noite (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite_
- nota 4: 0: Já ouvi uns rosnados lá longe. / 1: Se ouvir um chiado, corre. / 0: Aguenta firme, o dia já vem.
  - ⚠ A fala 'Se ouvir um chiado, corre.' é um pouco vaga, mas faz sentido como aviso de perigo (creeper).
  - ⚠ A fala 'Aguenta firme, o dia já vem.' é um fecho adequado, mas poderia ser mais natural se fosse 'Aguenta firme, o dia já vem aí.'
- nota 4: 0: Quem está de pé a essa hora? / 1: Fica por perto, é mais seguro. / 0: Aguenta firme, o dia já vem.
  - ⚠ A fala 'Aguenta firme, o dia já vem.' soa um pouco filosófica demais para criaturas simples como animais de fazenda ou aldeões, mas ainda é aceitável.
- nota 4: 0: Quem está de pé a essa hora? / 1: De noite o mundo fica estranho. / 0: Qualquer barulho eu aviso.
  - ⚠ A fala 'Qualquer barulho eu aviso.' não fecha claramente a conversa, soa como uma continuação.
- nota 4: 0: A lua está bonita, mas não confio nessa escuridão. / 1: Se ouvir um chiado, corre. / 0: Qualquer barulho eu aviso.
  - ⚠ A fala 'Se ouvir um chiado, corre.' é genérica e não especifica a criatura, mas pode ser aceitável para aldeões ou animais.
  - ⚠ A fala 'Qualquer barulho eu aviso.' é um pouco vaga, mas fecha a conversa de forma coerente.
- nota 4: 0: Quem está de pé a essa hora? / 1: Se ouvir um chiado, corre. / 0: Qualquer barulho eu aviso.
  - ⚠ A fala 'Se ouvir um chiado, corre.' é um aviso sobre Creeper, mas não responde diretamente à pergunta 'Quem está de pé a essa hora?'.
  - ⚠ A fala 'Qualquer barulho eu aviso.' fecha a conversa, mas não se conecta claramente com o aviso anterior.

### pastor (4.38)  _villager:shepherd e dois aldeões; é de dia_
- nota 4: 0: Lã não falta nesta estação. / 1: Elas são teimosas mesmo. / 0: No fim, elas voltam sempre.
  - ⚠ A fala 'Elas são teimosas mesmo.' é um pouco vaga, mas pode se referir às ovelhas, o que faz sentido para um pastor.
- nota 3: 0: As ovelhas hoje estão agitadas. / 1: Quando precisar de ajuda, chama. / 0: No fim, elas voltam sempre.
  - ⚠ A fala 'Quando precisar de ajuda, chama.' não responde diretamente à observação sobre as ovelhas agitadas, soando desconexa.
  - ⚠ O fecho 'No fim, elas voltam sempre.' não conclui a conversa de forma natural, pois não retoma a fala anterior sobre ajuda.
- nota 3: 0: As ovelhas hoje estão agitadas. / 1: Quando precisar de ajuda, chama. / 0: Eu gosto delas.
  - ⚠ A fala 'Quando precisar de ajuda, chama.' não responde diretamente à observação sobre as ovelhas agitadas.
  - ⚠ O fecho 'Eu gosto delas.' não encerra a conversa de forma natural, pois não se conecta com a fala anterior.

### sol (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é de dia; o céu está limpo_
- nota 3: 0: Acordei de bom humor com esse sol. / 1: Também acho. / 0: Pena que a noite chega logo.
  - ⚠ A resposta 'Também acho.' não combina com a fala anterior, que expressa um estado pessoal ('Acordei de bom humor'), não uma opinião.
  - ⚠ O fecho 'Pena que a noite chega logo.' muda o tom da conversa de forma abrupta, sem conexão clara com o bom humor inicial.
- nota 3: 0: O céu está limpo, nem uma nuvem. / 1: Nem me fale. / 0: Pena que a noite chega logo.
  - ⚠ A fala 'Nem me fale.' soa como reclamação, mas não há contexto negativo anterior; a primeira fala é neutra/positiva.
  - ⚠ A fala 'Pena que a noite chega logo.' introduz um tom melancólico que não combina com a situação calma e diurna, e não é um fecho natural para a conversa.
- nota 4: 0: Que dia bonito hoje. / 1: Aproveita, que o tempo muda rápido. / 0: Hoje está tudo no lugar.
  - ⚠ A fala 'Hoje está tudo no lugar.' não fecha a conversa de forma natural, soa desconexa da resposta anterior.

### vila_pilhadores (4.38)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: Pilhador é a pior coisa que existe. / 1: O golem não deixa ninguém passar. / 0: A vila é forte quando está unida.
  - ⚠ A fala 'O golem não deixa ninguém passar' não responde diretamente à fala anterior sobre pilhadores, parecendo desconexa.
  - ⚠ O fecho 'A vila é forte quando está unida' é genérico e não amarra a conversa de forma natural.
- nota 4: 0: Pilhador é a pior coisa que existe. / 1: Eu fecho as portas mais cedo por via das dúvidas. / 0: A vila é forte quando está unida.
  - ⚠ A fala 'A vila é forte quando está unida.' soa um pouco filosófica demais para um aldeão em conversa casual, mas ainda é plausível.
- nota 4: 0: A ideia de pilhadores me tira o sono. / 1: O golem não deixa ninguém passar. / 0: A vila é forte quando está unida.
  - ⚠ A fala 'O golem não deixa ninguém passar' não responde diretamente à preocupação com pilhadores, mas é plausível como comentário sobre defesa.
- nota 4: 0: Dizem que pilhadores atacam vilas inteiras. / 1: O golem não deixa ninguém passar. / 0: A vila é forte quando está unida.
  - ⚠ A fala 'O golem não deixa ninguém passar' não responde diretamente à fala anterior sobre pilhadores, mas ainda é plausível como comentário sobre defesa da vila.

### vila_pao (4.43)  _dois aldeões; é de dia_
- nota 4: 0: Pão repartido rende mais. / 1: Trigo bom faz pão bom. / 0: Pão e conversa fazem a vila.
  - ⚠ O fecho 'Pão e conversa fazem a vila' soa um pouco aforístico demais para um aldeão, mas ainda aceitável
- nota 4: 0: Falta pão quando a colheita é fraca. / 1: Trigo bom faz pão bom. / 0: Pão e conversa fazem a vila.
  - ⚠ 'Pão e conversa fazem a vila' soa um pouco aforístico demais para um aldeão, mas é passável
- nota 0: 0: O pão fresco cheira a casa boa. / 1: Uma casa sem pão fica triste. / 0: Pão e conversa fazem a vila.
  - ⚠ avaliador falhou
- nota 4: 0: Pão repartido rende mais. / 1: Uma casa sem pão fica triste. / 0: Pão e conversa fazem a vila.
  - ⚠ 'Uma casa sem pão fica triste' é um pouco abstrato/poético para um aldeão, mas passável
- nota 4: 0: Pão repartido rende mais. / 1: Eu guardo um pouco para o dia seguinte. / 0: O melhor perfume é o do forno.
  - ⚠ A fala 'O melhor perfume é o do forno.' soa um pouco poética demais para um aldeão comum, mas ainda aceitável.

### vila_porta_noite (4.43)  _dois aldeões; é noite_
- nota 0: 0: À noite todo cuidado é pouco. / 1: Eu prendo tudo duas vezes. / 0: Amanhã tudo estará no lugar.
  - ⚠ avaliador falhou
- nota 4: 0: A porta bem trancada é a minha paz. / 1: Zumbi quebra porta de madeira, sabia? / 0: Amanhã tudo estará no lugar.
  - ⚠ A fala 'Amanhã tudo estará no lugar' não responde diretamente à preocupação sobre zumbis quebrarem portas, deixando o fecho um pouco vago.
- nota 4: 0: A porta bem trancada é a minha paz. / 1: Zumbi quebra porta de madeira, sabia? / 0: Dorme bem.
  - ⚠ A fala 'Dorme bem.' soa um pouco abrupta como fecho, mas é aceitável.
- nota 4: 0: Eu confiro a porta antes de dormir. / 1: Zumbi quebra porta de madeira, sabia? / 0: Amanhã tudo estará no lugar.
  - ⚠ A fala 'Amanhã tudo estará no lugar' não responde diretamente à preocupação sobre zumbis quebrarem portas, deixando o fecho um pouco vago.

### bicho_hora_comer (4.50)  _dois animais da fazenda; é de dia_
- nota 4: 0: O estômago avisa a hora certa. / 1: Quem chega primeiro come melhor. / 0: Vamos juntos.
  - ⚠ Fala 0 'O estômago avisa a hora certa.' é um pouco filosófica para animais de fazenda, mas aceitável.
  - ⚠ Fala 1 'Quem chega primeiro come melhor.' sugere competição, o que é plausível, mas o fecho 'Vamos juntos.' contradiz a competição.
- nota 4: 0: O estômago avisa a hora certa. / 1: Quem chega primeiro come melhor. / 0: Guarda um lugar para mim.
  - ⚠ Fala 0 'O estômago avisa a hora certa.' é um pouco filosófica para animais de fazenda, mas aceitável.
  - ⚠ Fala 1 'Quem chega primeiro come melhor.' soa competitiva, mas plausível entre animais.
- nota 4: 0: Sinto cheiro de comida chegando. / 1: Quem chega primeiro come melhor. / 0: Guarda um lugar para mim.
  - ⚠ A fala 'Quem chega primeiro come melhor' soa mais como um ditado humano do que algo que um animal diria naturalmente.
- nota 4: 0: O estômago avisa a hora certa. / 1: O meu também está reclamando. / 0: Guarda um lugar para mim.
  - ⚠ Fala 0 'Guarda um lugar para mim' é um pouco vaga, mas aceitável para animais indo comer.

### bicho_vento (4.50)  _dois animais da fazenda; é de dia_
- nota 3: 0: O vento hoje traz cheiros de longe. / 1: O vento esfria o calor. / 0: Que continue assim.
  - ⚠ Fala 0: 'O vento hoje traz cheiros de longe.' soa poética demais para animais de fazenda, que tenderiam a ser mais simples.
  - ⚠ Fala 1: 'O vento esfria o calor.' é redundante e pouco natural, como se explicasse o óbvio.
- nota 4: 0: Hoje venta bastante. / 1: O vento esfria o calor. / 0: Vento bom é vento fraco.
  - ⚠ A fala 'Vento bom é vento fraco' soa um pouco filosófica demais para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: Hoje venta bastante. / 1: Eu gosto do vento no pelo. / 0: Vento bom é vento fraco.
  - ⚠ A fala 'Vento bom é vento fraco.' soa um pouco filosófica demais para animais de fazenda, mas ainda é aceitável.

### cartografo (4.50)  _villager:cartographer e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Todo caminho começa num bom desenho. / 1: Deve ser bonito ver o mundo no papel. / 0: O mapa guarda o que ninguém viu.
  - ⚠ A fala 'Todo caminho começa num bom desenho.' soa um pouco filosófica demais para um aldeão cartógrafo, mas ainda aceitável.
  - ⚠ A resposta 'Deve ser bonito ver o mundo no papel.' é plausível, mas poderia ser mais específica ao contexto de aldeões.
- nota 4: 0: Mapa bom mostra mais do que estradas. / 1: O mundo além das colinas deve ser enorme. / 0: Um dia alguém percorre o que eu desenhei.
  - ⚠ A fala 'Um dia alguém percorre o que eu desenhei.' soa um pouco filosófica para um aldeão cartógrafo, mas ainda é plausível.
- nota 4: 0: Desenhei um mapa novo hoje. / 1: Deve ser bonito ver o mundo no papel. / 0: O mapa guarda o que ninguém viu.
  - ⚠ A fala 'O mapa guarda o que ninguém viu.' soa um pouco filosófica demais para um aldeão cartógrafo, que normalmente fala de forma mais prática.
- nota 4: 0: Todo caminho começa num bom desenho. / 1: O mundo além das colinas deve ser enorme. / 0: O mapa guarda o que ninguém viu.
  - ⚠ A fala 'Todo caminho começa num bom desenho.' soa um pouco filosófica demais para um aldeão cartógrafo, mas ainda aceitável.
  - ⚠ A resposta 'O mundo além das colinas deve ser enorme.' é plausível, mas poderia ser mais específica ao contexto de mapas.

### colheita (4.50)  _dois aldeões; é de dia_
- nota 4: 0: Como anda a sua plantação de trigo? / 1: Troquei um pouco com um viajante outro dia. / 0: A terra daqui é generosa.
  - ⚠ A resposta 'Troquei um pouco com um viajante outro dia' não responde diretamente à pergunta sobre a plantação de trigo, mas ainda é plausível para aldeões.
- nota 3: 0: Colhi abóbora a manhã inteira. / 1: Também acho. / 0: Se sobrar, a gente troca.
  - ⚠ A resposta 'Também acho.' não combina com a fala anterior, que é uma afirmação sobre colher abóbora, não uma opinião.
  - ⚠ A fala 'Se sobrar, a gente troca.' é vaga e não fecha a conversa de forma natural, pois não especifica o que seria trocado.
- nota 4: 0: Hoje só pensei em batata. / 1: É verdade. / 0: A terra daqui é generosa.
  - ⚠ A resposta 'É verdade.' é muito vaga e não desenvolve a conversa, mas ainda é plausível para aldeões.

### curiosidade_creeper (4.50)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dizem que creeper tem medo de gato. / 1: Também acho. / 0: Que ele passe longe daqui.
  - ⚠ A fala 'Também acho.' é um pouco vaga, mas aceitável para uma resposta curta.
  - ⚠ O fecho 'Que ele passe longe daqui.' é um desejo, mas não fecha totalmente a conversa; poderia ser mais conclusivo.
- nota 4: 0: Dizem que creeper tem medo de gato. / 1: Pois é. / 0: Que ele passe longe daqui.
  - ⚠ A fala 'Pois é.' é muito vaga e não desenvolve a conversa, mas é aceitável para um aldeão.
  - ⚠ A fala 'Que ele passe longe daqui.' soa um pouco abrupta, mas fecha a conversa de forma coerente.
- nota 4: 0: Já viu um creeper de perto? Silencioso demais. / 1: Eu ouvi isso também, deve ser verdade. / 0: Por isso fico de olho em tudo.
  - ⚠ A fala 'Eu ouvi isso também, deve ser verdade.' não responde diretamente à pergunta 'Já viu um creeper de perto?', mas é aceitável como concordância.
  - ⚠ A situação é genérica ('uma situação qualquer do dia a dia'), o que dificulta avaliar a coerência contextual.
- nota 4: 0: Dizem que creeper tem medo de gato. / 1: O pior é que ele chega sem avisar. / 0: Que ele passe longe daqui.
  - ⚠ A fala 'O pior é que ele chega sem avisar.' não responde diretamente ao medo de gato mencionado, mas ainda é coerente com o contexto de creepers.

### esqueleto_flechas (4.50)  _um esqueleto e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Cada flecha que erra é uma vergonha. / 1: Pega algumas do chão. / 0: Vou acertar da próxima.
  - ⚠ A fala 'Pega algumas do chão.' é um pouco vaga, mas faz sentido para esqueletos que reutilizam flechas.
- nota 4: 0: Uma boa flecha precisa de pena e osso. / 1: Eu nunca erro duas vezes. / 0: Vou acertar da próxima.
  - ⚠ A fala 'Eu nunca erro duas vezes' soa como um ditado humano, não como algo que um esqueleto diria naturalmente.
  - ⚠ O fecho 'Vou acertar da próxima' é um pouco vago e não conecta diretamente com a fala anterior sobre nunca errar duas vezes.
- nota 4: 0: Cada flecha que erra é uma vergonha. / 1: Eu nunca erro duas vezes. / 0: Mais uma tentativa.
  - ⚠ A fala 'Eu nunca erro duas vezes' soa um pouco vaga, mas ainda faz sentido para esqueletos.
  - ⚠ O fecho 'Mais uma tentativa' é aceitável, mas poderia ser mais conclusivo.

### flecheiro (4.50)  _villager:fletcher e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Uma boa flecha precisa de equilíbrio. / 1: A vila fica mais segura com boas flechas. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Cada flecha tem seu destino.' soa filosófica demais para um aldeão comum, que normalmente fala de forma simples e prática.
- nota 4: 0: Fiz flechas novas esta manhã. / 1: A vila fica mais segura com boas flechas. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Cada flecha tem seu destino' soa filosófica demais para um aldeão comum, que normalmente fala de forma simples e prática.
- nota 4: 0: Fiz flechas novas esta manhã. / 1: Precisão é uma virtude. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Precisão é uma virtude' soa um pouco filosófica demais para um aldeão comum, mas ainda aceitável.
- nota 4: 0: Fiz flechas novas esta manhã. / 1: Isso é trabalho de mestre. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Cada flecha tem seu destino' soa filosófica demais para um aldeão comum, que normalmente fala de forma simples e prática.

### jogador_troca (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já fez uma troca justa com o jogador (fato verificado)_
- nota 4: 0: O humano fez uma troca justa comigo. / 1: Bom saber, eu também troco com quem é honesto. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' parece desconectada da conversa anterior, que era sobre trocas justas e honestidade, não sobre pagamento.
- nota 4: 0: A última troca com o humano foi tranquila. / 1: Bom saber, eu também troco com quem é honesto. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' parece desconectada da conversa anterior sobre trocas honestas, soando como um fecho abrupto.
- nota 4: 0: Negociei com o humano outro dia, correu tudo bem. / 1: Bom saber, eu também troco com quem é honesto. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' parece desconectada da conversa anterior, pois não há menção a pagamento ou dívida.
- nota 4: 0: A última troca com o humano foi tranquila. / 1: Paga direito? / 0: Dá para confiar.
  - ⚠ A fala 'Paga direito?' é ambígua e não se encaixa perfeitamente na situação de troca já concluída; poderia ser interpretada como dúvida sobre o pagamento, mas a troca foi justa.

### jogador_voltou (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador_
- nota 4: 0: Já conheço esse humano. / 1: Gosto quando ele volta. / 0: Vamos ver o que ele quer.
  - ⚠ A fala 'Vamos ver o que ele quer.' soa um pouco genérica, mas ainda é plausível para criaturas calmas.
- nota 4: 0: Olha só, o humano de novo. / 1: Ele sempre traz movimento. / 0: Que fique à vontade.
  - ⚠ Fala 1 'Ele sempre traz movimento.' é um pouco vaga e não responde diretamente à observação inicial, mas ainda é plausível.
  - ⚠ Fala 0 final 'Que fique à vontade.' soa mais como um desejo do que um fecho natural de conversa entre criaturas da mesma espécie.
- nota 4: 0: Olha só, o humano de novo. / 1: Ele sempre traz movimento. / 0: Vamos ver o que ele quer.
  - ⚠ Fala 1 'Ele sempre traz movimento.' é um pouco vaga e não responde diretamente à observação inicial, mas ainda é plausível para criaturas calmas.
- nota 4: 0: Já conheço esse humano. / 1: Ele sempre traz movimento. / 0: Vamos ver o que ele quer.
  - ⚠ Fala 1 'Ele sempre traz movimento.' é um pouco vaga e não se conecta claramente com a fala anterior.
  - ⚠ Fala 0 final 'Vamos ver o que ele quer.' soa mais como uma decisão de ação do que um fecho natural de conversa.

### monstros_ferido (4.50)  _dois monstros hostis; o jogador está ferido_
- nota 3: 0: O humano está ferido. / 1: Eu fico por perto. / 0: Deixa ele vir.
  - ⚠ Fala 1 'Eu fico por perto.' é vaga e não combina com a hostilidade esperada de monstros hostis.
  - ⚠ Fala 0 'Deixa ele vir.' soa como um desafio, mas não fecha claramente a conversa nem mostra intenção hostil.
- nota 4: 0: Cheiro de sangue por perto. / 1: Eu fico por perto. / 0: Sem pressa.
  - ⚠ A fala 'Eu fico por perto.' é um pouco vaga e não avança a conversa, mas ainda é plausível para monstros hostis.
- nota 4: 0: Cheiro de sangue por perto. / 1: Eu fico por perto. / 0: Deixa ele vir.
  - ⚠ 'Eu fico por perto' é vago demais para um monstro hostil; soaria mais ameaçador algo como 'vou cercar ele'
  - ⚠ O fecho 'Deixa ele vir' enfraquece a ameaça, já que o jogador ferido não está vindo, e sim sendo observado

### pasto (4.50)  _dois animais da fazenda; é de dia_
- nota 4: 0: Esse capim está uma delícia. / 1: Pois é. / 0: Aqui a gente está seguro.
  - ⚠ A fala 'Aqui a gente está seguro' soa um pouco filosófica para animais de fazenda, mas é aceitável.
- nota 4: 0: Esse capim está uma delícia. / 1: Dá para viver só disso. / 0: A vida é simples, e isso me basta.
  - ⚠ A fala 'A vida é simples, e isso me basta.' soa filosófica demais para um animal de fazenda, que normalmente não reflete sobre a vida.
- nota 4: 0: Passei a manhã pastando, que paz. / 1: Pois é. / 0: A vida é simples, e isso me basta.
  - ⚠ A fala 'A vida é simples, e isso me basta.' soa filosófica demais para um animal de fazenda, que normalmente não reflete sobre a vida.
- nota 4: 0: Viu aquela touceira de grama ali? / 1: Dá para viver só disso. / 0: A vida é simples, e isso me basta.
  - ⚠ A fala 'Dá para viver só disso.' é um pouco filosófica para animais de fazenda, mas ainda aceitável.
  - ⚠ A fala 'A vida é simples, e isso me basta.' soa mais como reflexão humana do que algo que um animal diria naturalmente.

### porco (4.50)  _um porco e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Barro é a melhor parte do dia. / 1: Achar comida enterrada é uma arte. / 0: Oink, a vida é boa.
  - ⚠ A fala 'Achar comida enterrada é uma arte.' soa um pouco filosófica demais para um porco, mas ainda é aceitável no contexto do jogo.
- nota 4: 0: Fuço o dia inteiro e nunca me canso. / 1: Achar comida enterrada é uma arte. / 0: Depois a gente se encontra no barro.
  - ⚠ Fala 1: 'Achar comida enterrada é uma arte' soa um pouco filosófica demais para um porco, mas ainda aceitável.
  - ⚠ Fala 0 (fecho): 'Depois a gente se encontra no barro' é coerente, mas poderia ser mais natural como 'Depois a gente se vê no barro'.
- nota 4: 0: Achei uma raiz gostosa debaixo da terra. / 1: Achar comida enterrada é uma arte. / 0: Oink, a vida é boa.
  - ⚠ A fala 'Achar comida enterrada é uma arte.' soa filosófica demais para um porco, que normalmente não reflete sobre arte.
  - ⚠ A fala 'Oink, a vida é boa.' é um fecho aceitável, mas 'a vida é boa' é uma expressão um pouco abstrata para um porco.
- nota 4: 0: Fuço o dia inteiro e nunca me canso. / 1: Oink, cada um com o seu cantinho de lama. / 0: Depois a gente se encontra no barro.
  - ⚠ A fala 'Oink, cada um com o seu cantinho de lama.' soa um pouco desconexa com a anterior, pois não responde diretamente ao cansaço mencionado.

### vaca (4.50)  _uma vaca e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Hoje o pasto está especialmente macio. / 1: Calma é o que a gente tem de melhor. / 0: Quando escurecer, a gente se junta.
  - ⚠ A fala 'Calma é o que a gente tem de melhor.' soa um pouco filosófica demais para uma vaca, mas ainda é aceitável.
- nota 4: 0: Muuu, o rebanho está todo junto hoje. / 1: Sem pressa, a vida rende mais. / 0: Fica por perto, que é mais seguro.
  - ⚠ A fala 'Sem pressa, a vida rende mais.' soa filosófica demais para uma vaca, que normalmente não expressa reflexões abstratas.
- nota 4: 0: Muuu, o rebanho está todo junto hoje. / 1: Sem pressa, a vida rende mais. / 0: Quando escurecer, a gente se junta.
  - ⚠ A fala 'Sem pressa, a vida rende mais.' soa filosófica demais para uma vaca, que normalmente não expressa reflexões abstratas.
- nota 4: 0: Muuu, o rebanho está todo junto hoje. / 1: Calma é o que a gente tem de melhor. / 0: Fica por perto, que é mais seguro.
  - ⚠ A fala 'Calma é o que a gente tem de melhor.' soa filosófica demais para uma vaca, que tende a expressões simples e concretas.

### vila_armadura (4.50)  _dois aldeões; o jogador veste armadura_
- nota 4: 0: Olha só, o humano está de uma armadura de ferro. / 1: Um bom armeiro faria igual. / 0: Pelo menos protege a vila também.
  - ⚠ A fala 'Um bom armeiro faria igual.' soa um pouco deslocada, pois não responde diretamente à observação sobre a armadura do jogador, mas ainda é plausível para um aldeão.
- nota 4: 0: Reparou na roupa de o humano? É uma armadura de ferro. / 1: Deve ter custado caro. / 0: Pelo menos protege a vila também.
  - ⚠ A fala 'Deve ter custado caro.' é plausível para um aldeão, mas poderia ser mais específica ao contexto de armadura de ferro, como mencionar o material ou a qualidade.
  - ⚠ A fala 'Pelo menos protege a vila também.' é um pouco vaga; não fica claro se o aldeão está sendo irônico ou genuíno, o que pode confundir o jogador.
- nota 4: 0: O humano veste uma armadura de ferro. Que peça boa. / 1: Dá até medo de chegar perto. / 0: Eu só queria saber onde fez.
  - ⚠ A fala 'Eu só queria saber onde fez.' soa um pouco estranha para um aldeão, pois eles não costumam se interessar por fabricação de armaduras, mas é aceitável.
- nota 4: 0: Reparou na roupa de o humano? É uma armadura de ferro. / 1: Deve ter custado caro. / 0: Eu só queria saber onde fez.
  - ⚠ A fala 'Eu só queria saber onde fez.' soa um pouco abrupta e não fecha a conversa de forma natural, pois não responde diretamente à fala anterior sobre o custo.

### vila_comerciante (4.50)  _dois aldeões; é de dia_
- nota 4: 0: Comerciante que aparece do nada traz boas histórias. / 1: Ele nunca fica mais de um dia. / 0: Quem sabe ele volte.
  - ⚠ A fala 'Comerciante que aparece do nada traz boas histórias.' soa um pouco formal para uma conversa casual entre aldeões, mas ainda é aceitável.
  - ⚠ A resposta 'Ele nunca fica mais de um dia.' é coerente, mas poderia ser mais natural como 'Ele nunca fica muito tempo.'
- nota 4: 0: Comerciante que aparece do nada traz boas histórias. / 1: Eu sempre olho o que ele traz. / 0: Quem sabe ele volte.
  - ⚠ Fala 0 'Comerciante que aparece do nada traz boas histórias.' é um pouco vaga, mas aceitável para aldeões.
  - ⚠ Fala 1 'Eu sempre olho o que ele traz.' é natural, mas poderia ser mais específica.
- nota 4: 0: Comerciante que aparece do nada traz boas histórias. / 1: As lhamas dele cospem em quem se aproxima. / 0: Cada visita rende uma boa história.
  - ⚠ A fala 'Comerciante que aparece do nada traz boas histórias.' é um pouco vaga, mas aceitável para aldeões.
  - ⚠ A resposta 'As lhamas dele cospem em quem se aproxima.' é coerente, mas poderia conectar melhor com 'boas histórias'.
- nota 4: 0: Comerciante que aparece do nada traz boas histórias. / 1: As lhamas dele cospem em quem se aproxima. / 0: Quem sabe ele volte.
  - ⚠ A fala 'Comerciante que aparece do nada traz boas histórias.' é um pouco vaga, mas plausível para aldeões.
  - ⚠ A resposta 'As lhamas dele cospem em quem se aproxima.' é coerente, mas poderia ser mais conectada à primeira fala.

### zumbi_carne (4.50)  _um zumbi e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Grrr... tem gente por perto. / 1: Grrrr... / 0: Quase... quase...
  - ⚠ A fala 'Quase... quase...' é vaga e não fecha claramente a conversa, deixando o sentido ambíguo.
- nota 4: 0: Humano... cheiro de carne. / 1: Eu também sinto o cheiro. / 0: Quase... quase...
  - ⚠ A fala 'Quase... quase...' é vaga e não fecha claramente a conversa, deixando o sentido ambíguo.
- nota 4: 0: Grrr... tem gente por perto. / 1: Eu também sinto o cheiro. / 0: Quase... quase...
  - ⚠ A fala 'Quase... quase...' é vaga e não fecha claramente a conversa, deixando a intenção ambígua.

### zumbi_sol (4.50)  _um zumbi e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Grrr... odeio o dia. / 1: Grrr... a sombra é a única amiga. / 0: Grrr... falta pouco.
  - ⚠ Fala 1: 'a sombra é a única amiga' soa filosófica demais para um zumbi, que normalmente não expressa sentimentos complexos.
- nota 3: 0: Grrr... preciso de sombra. / 1: Grrr... a sombra é a única amiga. / 0: Grrr... paciência.
  - ⚠ 'a sombra é a única amiga' é filosoficamente elaborado demais para um zumbi
  - ⚠ 'paciência' como fecho soa pouco zumbi e mais resignado humano

### afazeres (4.62)  _dois aldeões; é de dia_
- nota 4: 0: Passei a manhã sem parar, e ainda falta consertar uma cerca. / 1: Eu também tenho a minha lista. / 0: Valeu, ajuda é sempre bem-vinda.
  - ⚠ A fala final 'Valeu, ajuda é sempre bem-vinda' soa como se o primeiro aldeão estivesse agradecendo por uma oferta de ajuda, mas o segundo aldeão apenas mencionou ter sua própria lista, sem oferecer aj
- nota 3: 0: Hoje ainda preciso arrumar a casa. / 1: Trabalho de vila nunca acaba. / 0: Valeu, ajuda é sempre bem-vinda.
  - ⚠ A fala 'Valeu, ajuda é sempre bem-vinda.' não responde diretamente à fala anterior 'Trabalho de vila nunca acaba.' e parece agradecer por uma ajuda que não foi oferecida.
  - ⚠ A conversa não fecha de forma natural; o fecho soa deslocado.

### aranha_teia (4.62)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... as paredes são minhas. / 1: Sss... eu sinto as vibrações. / 0: Sss... paciência.
  - ⚠ Fala 0 'Sss... as paredes são minhas.' é um pouco possessiva demais para uma aranha, mas aceitável.
  - ⚠ Fala 1 'Sss... eu sinto as vibrações.' é coerente com a percepção de aranhas, mas poderia ser mais específica à situação.
- nota 4: 0: Sss... tem gente quente por perto. / 1: Sss... a noite é nossa. / 0: Sss... paciência.
  - ⚠ A fala 'Sss... tem gente quente por perto.' é um pouco vaga, mas aceitável para aranhas.
  - ⚠ A resposta 'Sss... a noite é nossa.' não responde diretamente à primeira fala, mas mantém o tom.
- nota 4: 0: Sss... a teia está pronta. / 1: Sss... deixa chegar mais perto. / 0: Sss...
  - ⚠ A fala 'Sss... deixa chegar mais perto.' é um pouco vaga, mas aceitável para aranhas caçando.
  - ⚠ O fecho 'Sss...' é muito curto e não conclui claramente a conversa, mas pode ser interpretado como um som de concordância.

### bicho_agua (4.62)  _dois animais da fazenda; é de dia_
- nota 4: 0: Beber água limpa é um prazer. / 1: Eu vou beber depois. / 0: Que a água nunca falte.
  - ⚠ Fala 0 'Beber água limpa é um prazer.' soa um pouco filosófica para animais de fazenda, mas ainda aceitável.
  - ⚠ Fala 1 'Eu vou beber depois.' é uma resposta simples, mas não desenvolve a conversa.
- nota 4: 0: A sede aperta quando o sol esquenta. / 1: Eu vou beber depois. / 0: Depois a gente vai juntos.
  - ⚠ Fala 1 'Eu vou beber depois.' é um pouco vaga e não responde diretamente à observação sobre a sede, mas é plausível para um animal.
- nota 4: 0: Beber água limpa é um prazer. / 1: Eu vou beber depois. / 0: Depois a gente vai juntos.
  - ⚠ Fala 1 'Eu vou beber depois.' é uma resposta um pouco seca, mas aceitável para animais de fazenda.
  - ⚠ Fala 0 'Depois a gente vai juntos.' fecha a conversa, mas poderia ser mais natural, como 'Depois a gente bebe junto.'

### bicho_sombra (4.62)  _dois animais da fazenda; é de dia; o céu está limpo_
- nota 3: 0: Achei uma sombra boa. / 1: É verdade. / 0: Fica à vontade.
  - ⚠ Fala 1 'É verdade.' é muito vaga e não acrescenta nada à conversa.
  - ⚠ Fala 0 'Fica à vontade.' soa como um convite humano, não como algo que um animal diria naturalmente.
- nota 4: 0: Achei uma sombra boa. / 1: É verdade. / 0: Aqui a gente descansa.
  - ⚠ A fala 'É verdade.' é muito genérica e não acrescenta nada à conversa, soando um pouco artificial para animais da fazenda.

### cavalo (4.62)  _um cavalo e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Hoje o campo está livre, só falta espaço. / 1: Um galope longo limpa a cabeça. / 0: Relincho de alegria.
  - ⚠ Fala 0: 'Hoje o campo está livre, só falta espaço.' é um pouco vaga, mas aceitável para cavalos.
  - ⚠ Fala 1: 'Um galope longo limpa a cabeça.' soa levemente filosófica para um cavalo, mas ainda dentro do possível.
- nota 4: 0: Hoje o campo está livre, só falta espaço. / 1: Eu prefiro trotar e olhar a paisagem. / 0: Mais tarde a gente corre junto.
  - ⚠ Fala 0 'Hoje o campo está livre, só falta espaço.' é um pouco vaga e não soa como algo que um cavalo diria naturalmente; 'só falta espaço' é redundante com 'campo livre'.
  - ⚠ Fala 1 'Eu prefiro trotar e olhar a paisagem.' é aceitável, mas 'olhar a paisagem' é uma expressão um pouco humana demais para um cavalo; poderia ser mais simples como 'ver o campo'.
- nota 4: 0: Hoje o campo está livre, só falta espaço. / 1: Correr é o que fazemos de melhor. / 0: Relincho de alegria.
  - ⚠ A fala 'Relincho de alegria' é uma descrição de ação, não uma fala natural; poderia ser apenas 'Relincho!' ou uma frase curta.

### creeper_silencio (4.62)  _um creeper e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Ssss... paciência antes da explosão. / 1: Ssss... quem escuta tarde, escuta demais. / 0: Ssss...
  - ⚠ A fala 'Ssss... quem escuta tarde, escuta demais.' é um provérbio humano que não combina com o comportamento instintivo de um creeper.
  - ⚠ O fecho 'Ssss...' é vago e não conclui a conversa de forma satisfatória.
- nota 4: 0: Ssss... o segredo é chegar sem fazer barulho. / 1: Ssss... quem escuta tarde, escuta demais. / 0: Ssss...
  - ⚠ A fala 'quem escuta tarde, escuta demais' é um provérbio humano que não combina com o vocabulário de um creeper, que normalmente se limita a sibilos e sons curtos.

### curiosidade_fundo (4.62)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dizem que tem brilho de diamante bem fundo. / 1: Nem me fale. / 0: Que ninguém desça sem tocha.
  - ⚠ A fala 'Nem me fale.' é um pouco vaga, mas aceitável como resposta de aldeão.
  - ⚠ A última fala 'Que ninguém desça sem tocha.' soa como um aviso, mas não fecha claramente a conversa.
- nota 4: 0: O que será que tem lá embaixo, nas cavernas? / 1: Prefiro o lado de cima. / 0: Que ninguém desça sem tocha.
  - ⚠ A fala 'Que ninguém desça sem tocha.' soa um pouco formal para uma conversa casual entre aldeões, mas ainda é plausível.
- nota 4: 0: O que será que tem lá embaixo, nas cavernas? / 1: Prefiro o lado de cima. / 0: Melhor deixar o fundo em paz.
  - ⚠ A fala 'Prefiro o lado de cima.' é um pouco vaga, mas aceitável para um aldeão.
  - ⚠ A conversa é curta e não desenvolve muito, mas fecha de forma coerente.

### esqueleto_armadura (4.62)  _um esqueleto e outra criatura da mesma espécie; o jogador veste armadura_
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Armadura nenhuma é perfeita. / 0: Vamos tentar mesmo assim.
  - ⚠ A fala 'Armadura nenhuma é perfeita.' soa filosófica demais para um esqueleto, que normalmente tem falas mais diretas e hostis.
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Mire na cabeça. / 0: Vamos tentar mesmo assim.
  - ⚠ A fala 'Mire na cabeça.' é um pouco vaga, mas plausível para esqueletos que atacam com arco.
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Armadura nenhuma é perfeita. / 0: Paciência é a nossa arma.
  - ⚠ A fala 'Paciência é a nossa arma' soa um pouco filosófica demais para um esqueleto, que normalmente é hostil e direto.

### esqueleto_creeper (4.62)  _um esqueleto e um creeper; uma situação qualquer do dia a dia_
- nota 4: 0: Você explode e eu atiro. Dá um bom time. / 1: Ssss... só não me acerta. / 0: Então vamos.
  - ⚠ A fala do creeper 'Ssss... só não me acerta.' é um pouco longa para o padrão de creepers, que costumam ser mais curtos e sibilantes.
- nota 4: 0: Fica longe da minha flecha, hein? / 1: Ssss... eu chego perto, você mira de longe. / 0: Então vamos.
  - ⚠ A fala 'Então vamos.' é um fecho um pouco vago, mas aceitável.
- nota 4: 0: Fica longe da minha flecha, hein? / 1: Ssss... só não me acerta. / 0: Então vamos.
  - ⚠ A fala 'Então vamos.' é vaga e não fecha claramente a conversa, deixando a interação sem um desfecho natural.

### golem_quer_flor (4.62)  _um golem de ferro e dois aldeões; o jogador segura um item; quem abre GOSTA do que o jogador segura_
- nota 4: 0: O humano está com uma papoula. Eu adoro isso. / 1: Pede com educação, quem sabe ele dá. / 0: Eu cuido da vila, e ele cuida das flores.
  - ⚠ A fala 'Eu cuido da vila, e ele cuida das flores.' soa um pouco filosófica para um golem de ferro, que normalmente tem falas simples e diretas.
- nota 4: 0: O humano está com uma papoula. Eu adoro isso. / 1: Ele nem percebeu que você está olhando. / 0: Eu cuido da vila, e ele cuida das flores.
  - ⚠ A fala 'Eu cuido da vila, e ele cuida das flores.' soa um pouco filosófica para um golem de ferro, que normalmente tem falas simples e protetoras.
- nota 4: 0: Olha, uma papoula na mão de o humano. Gosto muito. / 1: Ele nem percebeu que você está olhando. / 0: Eu cuido da vila, e ele cuida das flores.
  - ⚠ A fala 'Eu cuido da vila, e ele cuida das flores.' soa um pouco filosófica demais para um golem de ferro, que normalmente tem falas simples e diretas.

### golem_ronda (4.62)  _um golem de ferro e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dei a volta na vila e está tudo calmo. / 1: Sem você, eu não teria coragem de sair. / 0: É o que sei fazer.
  - ⚠ A fala 'Sem você, eu não teria coragem de sair.' soa um pouco dramática para um aldeão, que normalmente tem medo de sair à noite, mas pode ser plausível se o golem estiver por perto.
  - ⚠ A fala 'É o que sei fazer.' é um fecho um pouco seco, mas aceitável para um golem de ferro, que é uma criatura protetora e de poucas palavras.
- nota 4: 0: A noite foi tranquila na vila. / 1: Valeu, a gente dorme melhor assim. / 0: É o que sei fazer.
  - ⚠ A fala 'É o que sei fazer.' do golem soa um pouco vaga e não fecha a conversa de forma natural, pois não responde diretamente ao agradecimento do aldeão.
- nota 4: 0: A noite foi tranquila na vila. / 1: Sem você, eu não teria coragem de sair. / 0: É o que sei fazer.
  - ⚠ A fala 'Sem você, eu não teria coragem de sair.' soa um pouco dramática para um aldeão, que normalmente tem medo de tudo, mas é plausível.
  - ⚠ A fala 'É o que sei fazer.' do golem é um pouco vaga, mas aceitável.

### jogador_chuva (4.62)  _dois aldeões; está chovendo_
- nota 4: 0: O humano está na chuva, nem parece se importar. / 1: Deve estar com frio. / 0: Ao menos a chuva lava a poeira.
  - ⚠ A fala 'Ao menos a chuva lava a poeira' soa um pouco filosófica demais para um aldeão, que tende a ser mais prático e simples.
- nota 4: 0: Olha o humano debaixo dessa chuva toda. / 1: Deve estar com frio. / 0: Se vier até aqui, eu deixo ficar.
  - ⚠ A fala 'Se vier até aqui, eu deixo ficar.' soa um pouco estranha para um aldeão, pois eles normalmente não oferecem abrigo a estranhos, mas é aceitável.
- nota 4: 0: O humano está na chuva, nem parece se importar. / 1: Alguém devia oferecer um abrigo. / 0: Ao menos a chuva lava a poeira.
  - ⚠ A fala 'Alguém devia oferecer um abrigo.' soa um pouco vaga e não é uma resposta direta à observação anterior, mas ainda é plausível para aldeões.

### lobo (4.62)  _um lobo e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Cheirei um osso enterrado ali perto. / 1: Quem é da matilha, eu protejo. / 0: Vamos patrulhar juntos.
  - ⚠ A fala 'Quem é da matilha, eu protejo.' soa um pouco genérica e não responde diretamente ao osso mencionado, mas ainda é plausível para um lobo.
- nota 4: 0: Ouvi um uivo lá longe. / 1: Quem é da matilha, eu protejo. / 0: Auuu, fico de olho nos meus.
  - ⚠ A fala 'Quem é da matilha, eu protejo.' soa um pouco formal para um lobo, mas ainda aceitável.
  - ⚠ A resposta 'Auuu, fico de olho nos meus.' mistura uivo com fala, o que pode parecer estranho, mas é compreensível.
- nota 4: 0: Cheirei um osso enterrado ali perto. / 1: Quem é da matilha, eu protejo. / 0: Auuu, fico de olho nos meus.
  - ⚠ A fala 'Quem é da matilha, eu protejo.' não responde diretamente à primeira fala sobre o osso, mas ainda é plausível como um comentário de lealdade.
  - ⚠ A fala 'Auuu, fico de olho nos meus.' é um fecho aceitável, mas poderia ser mais conectada ao osso ou à proteção.

### noite_frio (4.62)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite_
- nota 4: 0: O vento da noite gela até os ossos. / 1: Escondido do vento é melhor. / 0: Ainda bem que o dia volta.
  - ⚠ Fala 1 'Escondido do vento é melhor.' soa um pouco estranha em português; seria mais natural 'Melhor se esconder do vento.'
- nota 4: 0: O vento da noite gela até os ossos. / 1: A gente se acostuma com o frio. / 0: Amanhã o sol esquenta de novo.
  - ⚠ 'gela até os ossos' é um pouco literário para um aldeão/animal simples, mas passável
- nota 4: 0: O vento da noite gela até os ossos. / 1: A gente se acostuma com o frio. / 0: Ainda bem que o dia volta.
  - ⚠ Fala 0: 'O vento da noite gela até os ossos.' soa um pouco filosófica para criaturas simples como animais de fazenda, mas é aceitável para aldeões.

### zumbi_armadura (4.62)  _um zumbi e outra criatura da mesma espécie; o jogador veste armadura_
- nota 4: 0: O humano veste uma armadura de ferro. Duro de morder. / 1: Eu mordo de qualquer jeito. / 0: Hmmm...
  - ⚠ A fala 'Hmmm...' é muito vaga e não fecha a conversa de forma clara.
- nota 4: 0: Metal... uma armadura de ferro... Grrr. / 1: Eu mordo de qualquer jeito. / 0: Hmmm...
  - ⚠ A fala 'Eu mordo de qualquer jeito.' é um pouco curta e não desenvolve a conversa, mas ainda é plausível para zumbis.
  - ⚠ O fecho 'Hmmm...' é vago e não encerra claramente a conversa.
- nota 4: 0: Metal... uma armadura de ferro... Grrr. / 1: Eu mordo de qualquer jeito. / 0: Grrr...
  - ⚠ A fala 'Eu mordo de qualquer jeito' é um pouco genérica, mas aceitável para zumbis.

### zumbi_jogador (4.62)  _um zumbi e outra criatura da mesma espécie; o jogador segura um item_
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Cuidado... pode doer. / 0: Fome...
  - ⚠ A fala 'Fome...' como fecho é um pouco vaga, mas ainda aceitável para zumbis.
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Tira dele... tira... / 0: Fome...
  - ⚠ A fala 'Tira dele... tira...' é um pouco vaga, mas aceitável para zumbis.
  - ⚠ A fala 'Fome...' fecha a conversa de forma abrupta, mas condiz com zumbis.
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Tira dele... tira... / 0: Grrr...
  - ⚠ A fala 'Tira dele... tira...' é um pouco vaga, mas aceitável para zumbis.
  - ⚠ O fecho 'Grrr...' é curto e fecha bem, mas poderia ser mais reativo à espada.

### bibliotecario (4.75)  _villager:librarian e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Passei a manhã organizando as estantes. / 1: Eu não entendo as letras, mas gosto de ouvir você. / 0: Ler é uma forma de viajar.
  - ⚠ A fala 'Eu não entendo as letras, mas gosto de ouvir você.' soa um pouco estranha para um aldeão, pois aldeões não têm relação com leitura, mas é aceitável como expressão de admiração.
  - ⚠ A fala 'Ler é uma forma de viajar.' é um pouco filosófica para um aldeão, mas ainda se encaixa no contexto de bibliotecário.
- nota 4: 0: Cada livro guarda um segredo. / 1: Um dia você me ensina? / 0: Ler é uma forma de viajar.
  - ⚠ A fala 'Um dia você me ensina?' parece mais adequada a um aprendiz, mas não há indicação de que os outros dois aldeões sejam aprendizes; poderia ser uma conversa entre iguais.
  - ⚠ A resposta 'Ler é uma forma de viajar.' não responde diretamente ao pedido de ensinar, apenas comenta sobre leitura, deixando a conversa sem um fecho claro.

### bicho_cheiro (4.75)  _dois animais da fazenda; é de dia_
- nota 4: 0: O vento trouxe cheiro de chuva. / 1: O nariz da gente não engana. / 0: Vou seguir o cheiro depois.
  - ⚠ A fala 'O nariz da gente não engana' soa um pouco estranha para animais, pois 'da gente' é uma expressão mais humana, mas ainda aceitável.
  - ⚠ A fala 'Vou seguir o cheiro depois' é um pouco vaga e não fecha totalmente a conversa, mas é plausível.
- nota 4: 0: O vento trouxe cheiro de chuva. / 1: Esse cheiro me dá fome. / 0: Vou seguir o cheiro depois.
  - ⚠ A fala 'Esse cheiro me dá fome' é um pouco estranha, pois cheiro de chuva normalmente não é associado a fome, mas pode ser passável para animais.

### entardecer (4.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é fim de tarde_
- nota 4: 0: O sol está se pondo. / 1: Hora de ficar de olho, a noite traz coisa ruim. / 0: Cada dia termina assim.
  - ⚠ A fala 'Cada dia termina assim.' soa um pouco vaga e não fecha a conversa de forma natural, podendo ser interpretada como filosófica demais para criaturas simples.
- nota 4: 0: A tarde acabou rápido hoje. / 1: Eu gosto dessa cor no céu. / 0: É verdade, vamos com cuidado.
  - ⚠ A fala 'É verdade, vamos com cuidado.' não fecha claramente a conversa, pois não responde diretamente à fala anterior sobre a cor do céu.

### golem_guarda (4.75)  _dois aldeões e um golem de ferro; uma situação qualquer do dia a dia_
- nota 4: 0: Dá uma sensação boa ter você por perto. / 1: Eu só faço o que precisa ser feito. / 0: Qualquer coisa, grito por você.
  - ⚠ A fala 'Qualquer coisa, grito por você.' soa um pouco estranha para um aldeão, pois gritar não é uma ação típica deles; talvez 'chamo' fosse mais natural.
- nota 4: 0: A vila fica mais tranquila com você aqui. / 1: Dormir não é comigo, eu fico de pé. / 0: Qualquer coisa, grito por você.
  - ⚠ A fala 'Dormir não é comigo, eu fico de pé.' soa como uma resposta a um comentário sobre dormir, mas a fala anterior não menciona dormir, apenas tranquilidade.

### golem_orgulho (4.75)  _dois aldeões e um golem de ferro; uma situação qualquer do dia a dia_
- nota 4: 0: Com o golem por perto, durmo tranquilo. / 1: Eu só faço o que preciso. / 0: A vila agradece.
  - ⚠ A fala 'Eu só faço o que preciso.' do golem é um pouco vaga e não responde diretamente ao aldeão, mas ainda é aceitável para um golem de ferro.
- nota 4: 0: Quando o golem passa, a vila respira aliviada. / 1: Eu só faço o que preciso. / 0: Por isso a vila ainda existe.
  - ⚠ A fala 'Eu só faço o que preciso.' soa um pouco vaga para um golem, que normalmente não fala de forma tão abstrata, mas é aceitável.

### jogador_honesto (4.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já devolveu a quem abre algo que ele tinha entregado, sem ser pedido (fato verificado)_
- nota 4: 0: O humano me devolveu o que eu tinha entregado, sem eu pedir. / 1: Isso é raro, essa pessoa é honesta. / 0: Fez toda a diferença para mim.
  - ⚠ A fala 'Isso é raro, essa pessoa é honesta.' soa um pouco genérica e não específica da criatura, mas ainda é plausível para aldeões ou animais calmos.
- nota 4: 0: O humano me devolveu o que eu tinha entregado, sem eu pedir. / 1: Então vale a confiança. / 0: Fez toda a diferença para mim.
  - ⚠ A fala 'Então vale a confiança.' é um pouco vaga e não se conecta claramente com a devolução mencionada.
  - ⚠ A fala 'Fez toda a diferença para mim.' soa um pouco genérica e poderia ser mais específica ao contexto da devolução.

### trovoada (4.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; há tempestade_
- nota 4: 0: Que tempestade feia. / 1: Fica longe de árvore alta, dizem que atrai raio. / 0: Vamos aguentar juntos.
  - ⚠ A fala 'Fica longe de árvore alta, dizem que atrai raio.' soa mais como conselho de aldeão do que de animal de fazenda, mas ainda é plausível para criaturas calmas.
- nota 4: 0: Esse temporal está de dar medo. / 1: Fica longe de árvore alta, dizem que atrai raio. / 0: Chega mais perto, é mais seguro.
  - ⚠ A fala 'Chega mais perto, é mais seguro.' pode ser ambígua: se estão ao ar livre durante tempestade, aproximar-se não é necessariamente mais seguro, mas pode ser interpretado como buscar abrigo juntos

### vila_sino (4.75)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: O sino da vila é o som que mais me assusta. / 1: A vila inteira ouve. / 0: A vila sempre se junta.
  - ⚠ A fala 'A vila inteira ouve.' não responde diretamente ao medo expresso na primeira fala.
  - ⚠ A fala 'A vila sempre se junta.' não fecha a conversa de forma natural, deixando o diálogo sem conclusão clara.

### zumbi_porta (4.75)  _um zumbi e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Grrr... bater na porta cansa. / 1: Grrr... paciência abre qualquer madeira. / 0: Grrr...
  - ⚠ A fala 'paciência abre qualquer madeira' é um pouco filosófica demais para um zumbi, que normalmente não expressa ideias abstratas.
- nota 4: 0: Grrr... bater na porta cansa. / 1: Grrr... paciência abre qualquer madeira. / 0: Grrr... insiste.
  - ⚠ Fala 1: 'paciência abre qualquer madeira' soa filosófica demais para um zumbi, que normalmente não tem raciocínio abstrato.

### amanhecer (4.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está amanhecendo_
- nota 4: 0: O dia está nascendo, olha ali. / 1: Que alívio, nem dormi direito. / 0: Vamos ver o que o dia traz.
  - ⚠ Fala 1: 'Que alívio, nem dormi direito.' soa mais humana do que de criatura calma de fazenda, mas ainda passável.

### aranha_caverna (4.88)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... a teia é a minha casa. / 1: Sss... subir é mais fácil que andar. / 0: Sss...
  - ⚠ A fala 'Sss... subir é mais fácil que andar.' não responde diretamente à afirmação anterior sobre a teia ser a casa, mas ainda é plausível como comentário de aranha.
  - ⚠ O fecho 'Sss...' é muito vago e não conclui a conversa de forma clara.

### bicho_cochilo (4.88)  _dois animais da fazenda; é de dia_
- nota 4: 0: Esse canto está ótimo para dormir. / 1: Fecha os olhos que eu vigio. / 0: Me acorda quando o sol baixar.
  - ⚠ Fala 0: 'Esse canto está ótimo para dormir.' é plausível para animais de fazenda, mas um pouco genérica; poderia ser mais específica do animal.
  - ⚠ Fala 1: 'Fecha os olhos que eu vigio.' soa levemente humano, mas aceitável para animais que podem ter comportamento de vigília.

### bruxa_pocao2 (4.88)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Hehe, acertei a mistura certa. / 1: Eu prefiro as venenosas. / 0: Hehe, depois a gente compara.
  - ⚠ A resposta 'Eu prefiro as venenosas' é um pouco vaga sobre o que se refere (mistura? plantas?), mas funciona no contexto de bruxas

### camas (4.88)  _dois aldeões; é noite_
- nota 4: 0: Aquela cama perto da porta é minha, hein. / 1: Eu também, mal me aguento em pé. / 0: Até amanhã.
  - ⚠ A fala 'Eu também, mal me aguento em pé.' não responde diretamente à primeira fala sobre a cama, mas pode ser interpretada como concordância em ir dormir.

### creeper_chiado (4.88)  _um creeper e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Ssss... silêncio. / 1: Ssss... cuidado com os gatos. / 0: Ssss...
  - ⚠ A fala 'Ssss... silêncio.' é um pouco vaga, mas aceitável para creepers.
  - ⚠ A resposta 'Ssss... cuidado com os gatos.' introduz um tópico novo sem conexão clara com 'silêncio', mas ainda faz sentido no contexto de creepers.

### curiosidade_abelha (4.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é de dia; o céu está limpo_
- nota 4: 0: Você viu as abelhas hoje? Trabalham sem parar. / 1: Dizem que o mel é uma maravilha. / 0: Elas sabem o que fazem.
  - ⚠ A fala 'Dizem que o mel é uma maravilha.' soa um pouco vaga e não responde diretamente à pergunta sobre as abelhas trabalharem sem parar.

### enderman_agua (4.88)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: A chuva é a minha pior inimiga. / 1: Eu me teletransporto quando ela cai. / 0: Eu sumo antes que me molhe.
  - ⚠ A fala 1 'Eu me teletransporto quando ela cai' é um pouco redundante com a fala 0, mas ainda coerente
  - ⚠ O fecho 'Eu sumo antes que me molhe' repete a ideia da fala 1 em vez de fechar com algo novo

### fofoca_vila (4.88)  _dois aldeões; é de dia_
- nota 4: 0: Alguém viu o que se passa perto do rio? / 1: Aqui na vila as notícias correm rápido. / 0: Vou ficar de olho.
  - ⚠ A resposta 'Aqui na vila as notícias correm rápido.' não responde diretamente à pergunta sobre o rio, deixando a conversa um pouco vaga.

### jogador_item (4.88)  _dois aldeões; o jogador segura um item_
- nota 4: 0: O humano está segurando esmeraldas, reparou? / 1: Parece útil, isso. / 0: Vou perguntar, quem sabe.
  - ⚠ A fala 'Vou perguntar, quem sabe.' é um pouco vaga, mas aceitável para aldeões curiosos.

### madrugada (4.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está amanhecendo_
- nota 4: 0: Acordei cedo hoje. / 1: O frio da madrugada passa logo. / 0: Que ele seja tranquilo.
  - ⚠ A fala 'Que ele seja tranquilo.' soa um pouco vaga, mas ainda aceitável como fecho.

### monstros_lua (4.88)  _dois monstros hostis; é noite_
- nota 4: 0: A lua está cheia hoje. / 1: A escuridão é nossa casa. / 0: Vamos começar.
  - ⚠ A fala 'Vamos começar.' é vaga e não fecha claramente a conversa, deixando a intenção ambígua.

### monstros_noite (4.88)  _dois monstros hostis; é noite_
- nota 4: 0: Escuridão boa, essa. / 1: Vamos juntos, então. / 0: Que a noite comece.
  - ⚠ Fala 1 'Vamos juntos, então.' é vaga e não deixa claro o que farão juntos, mas ainda é plausível para monstros hostis.

### ovelha (4.88)  _uma ovelha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Passei o dia mordiscando grama. / 1: Mééé, lã crescida aquece no frio. / 0: A gente se junta quando escurecer.
  - ⚠ A fala 'Mééé, lã crescida aquece no frio.' soa um pouco desconexa da anterior, mas ainda aceitável para ovelhas.

### vila_passando_troca (4.88)  _dois aldeões; é de dia_
- nota 4: 0: O humano passou por aqui. Será que quer trocar alguma coisa? / 1: Hoje o meu estoque está bom. / 0: Que venha negociar.
  - ⚠ A fala 'Hoje o meu estoque está bom.' não responde diretamente à pergunta sobre o humano querer trocar, mas é plausível como comentário relacionado.

### warden_vibracao (4.88)  _um Warden e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Há vibração por perto. / 1: Cada passo ecoa no meu peito. / 0: Escuta.
  - ⚠ A fala 'Cada passo ecoa no meu peito.' é um pouco poética demais para um Warden, que normalmente se comunica de forma mais instintiva e sensorial.

### vila_esmeralda (5.00)  _dois aldeões; é de dia_
- nota 0: 0: O preço das esmeraldas muda todo dia. / 1: Um bom estoque vale ouro, ou melhor, esmeralda. / 0: Cada esmeralda conta.
  - ⚠ avaliador falhou
- nota 0: 0: Esmeralda é a moeda que todo mundo quer. / 1: Eu troco o que sobra por esmeraldas. / 0: Negócio honesto é o melhor negócio.
  - ⚠ avaliador falhou
- nota 0: 0: O preço das esmeraldas muda todo dia. / 1: Eu troco o que sobra por esmeraldas. / 0: Negócio honesto é o melhor negócio.
  - ⚠ avaliador falhou

### vila_tempestade (5.00)  _dois aldeões; há tempestade_
- nota 0: 0: A tempestade assusta até o golem. / 1: Dentro de casa a gente fica seguro. / 0: A vila aguenta qualquer tempo.
  - ⚠ avaliador falhou
- nota 0: 0: Fechei as janelas por causa da tempestade. / 1: Eu acendo uma tocha e espero passar. / 0: Amanhã o céu limpa.
  - ⚠ avaliador falhou
- nota 0: 0: Fechei as janelas por causa da tempestade. / 1: Raio que cai perto faz tudo tremer. / 0: A vila aguenta qualquer tempo.
  - ⚠ avaliador falhou
- nota 0: 0: A tempestade assusta até o golem. / 1: Dentro de casa a gente fica seguro. / 0: Amanhã o céu limpa.
  - ⚠ avaliador falhou
