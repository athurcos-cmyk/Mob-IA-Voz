# Juiz de IA por família de assunto (conversas ambiente)

2026-10-31 19:22; 139 famílias, 1112 cenas, juiz `deepseek-v4-pro`, 318 s. Média geral **4.43**; famílias abaixo de 4.0: **11**.

| Família | cenas | nota |
|---|---|---|
| curiosidade_quadrado | 8 | 3.25  REVER |
| cercado | 8 | 3.38  REVER |
| creeper_zumbi | 8 | 3.62  REVER |
| bicho_jogador_chuva | 8 | 3.88  REVER |
| bicho_jogador_fome | 8 | 3.88  REVER |
| bicho_jogador_noite | 8 | 3.88  REVER |
| curiosidade_enderman | 8 | 3.88  REVER |
| jogador_ameacou | 8 | 3.88  REVER |
| jogador_apresenta | 8 | 3.88  REVER |
| jogador_conhecido | 8 | 3.88  REVER |
| jogador_dono | 8 | 3.88  REVER |
| aranha_zumbi | 8 | 4.00 |
| bicho_filhotes_cuidado | 8 | 4.00 |
| bicho_jogador_ferido | 8 | 4.00 |
| jogador_sem_nome | 8 | 4.00 |
| monstros_armadura | 8 | 4.00 |
| monstros_chuva | 8 | 4.00 |
| sol | 8 | 4.00 |
| vila_comerciante | 8 | 4.00 |
| vila_gato | 8 | 4.00 |
| zumbi_esqueleto | 8 | 4.00 |
| armeiro | 8 | 4.12 |
| bicho_abelha | 8 | 4.12 |
| bicho_agua | 8 | 4.12 |
| bicho_armadura | 8 | 4.12 |
| bicho_barulho | 8 | 4.12 |
| bicho_barulho_estranho | 8 | 4.12 |
| bicho_item | 8 | 4.12 |
| bicho_noite_lua | 8 | 4.12 |
| chuva | 8 | 4.12 |
| clerigo | 8 | 4.12 |
| curiosidade_fundo | 8 | 4.12 |
| curiosidade_portal | 8 | 4.12 |
| enderman_olhar | 8 | 4.12 |
| esqueleto_flechas | 8 | 4.12 |
| jogador_nome_conta | 8 | 4.12 |
| medo_lobo | 8 | 4.12 |
| zumbi_jogador | 8 | 4.12 |
| zumbi_porta | 8 | 4.12 |
| bruxa_cogumelo | 8 | 4.25 |
| creeper_silencio | 8 | 4.25 |
| flecheiro | 8 | 4.25 |
| jogador_monstros_visto | 8 | 4.25 |
| jogador_passando | 8 | 4.25 |
| jogador_troca | 8 | 4.25 |
| lobo | 8 | 4.25 |
| monstros_ferido | 8 | 4.25 |
| pastor | 8 | 4.25 |
| vila_pilhadores | 8 | 4.33 |
| aranha_presa | 8 | 4.38 |
| aranha_teia | 8 | 4.38 |
| bicho_hora_comer | 8 | 4.38 |
| bicho_jogador_conhecido | 8 | 4.38 |
| bicho_sombra | 8 | 4.38 |
| ceu_estrelas | 8 | 4.38 |
| colheita | 8 | 4.38 |
| creeper_gato | 8 | 4.38 |
| enderman_bloco | 8 | 4.38 |
| esqueleto_creeper | 8 | 4.38 |
| esqueleto_sombra | 8 | 4.38 |
| fome_bicho | 8 | 4.38 |
| golem_flor | 8 | 4.38 |
| golem_quer_flor | 8 | 4.38 |
| jogador_ferido | 8 | 4.38 |
| jogador_honesto | 8 | 4.38 |
| noite | 8 | 4.38 |
| porco | 8 | 4.38 |
| vaca | 8 | 4.38 |
| acougueiro | 8 | 4.50 |
| aranha_caverna | 8 | 4.50 |
| bibliotecario | 8 | 4.50 |
| bruxa_pocao | 8 | 4.50 |
| cartografo | 8 | 4.50 |
| cavalo | 8 | 4.50 |
| curiosidade_creeper | 8 | 4.50 |
| entardecer | 8 | 4.50 |
| esqueleto_armadura | 8 | 4.50 |
| jogador_bateu | 8 | 4.50 |
| jogador_chuva | 8 | 4.50 |
| jogador_nome_ambos | 8 | 4.50 |
| jogador_presente | 8 | 4.50 |
| monstros_item | 8 | 4.50 |
| noite_frio | 8 | 4.50 |
| pasto | 8 | 4.50 |
| pescador | 8 | 4.50 |
| zumbi_carne | 8 | 4.50 |
| bicho_quer_comida | 8 | 4.62 |
| bruxa_pocao2 | 8 | 4.62 |
| curtidor | 8 | 4.62 |
| ferreiro_armas | 8 | 4.62 |
| galinha | 8 | 4.62 |
| gato | 8 | 4.62 |
| golem_ronda | 8 | 4.62 |
| jogador_acalmou | 8 | 4.62 |
| jogador_fome | 8 | 4.62 |
| jogador_traiu | 8 | 4.62 |
| trovoada | 8 | 4.62 |
| vila_armadura | 8 | 4.62 |
| zumbi_armadura | 8 | 4.62 |
| afazeres | 8 | 4.75 |
| amanhecer | 8 | 4.75 |
| bicho_cheiro | 8 | 4.75 |
| bicho_manha | 8 | 4.75 |
| camas | 8 | 4.75 |
| creeper_chiado | 8 | 4.75 |
| enderman_agua | 8 | 4.75 |
| esqueleto_mira | 8 | 4.75 |
| ferreiro | 8 | 4.75 |
| golem_guarda | 8 | 4.75 |
| jogador_item | 8 | 4.75 |
| monstros_dia | 8 | 4.75 |
| monstros_lua | 8 | 4.75 |
| ovelha | 8 | 4.75 |
| vila_fome | 8 | 4.75 |
| vila_porta_noite | 8 | 4.75 |
| warden_sculk | 8 | 4.75 |
| zumbi_sol | 8 | 4.75 |
| bicho_cochilo | 8 | 4.88 |
| bicho_lama | 8 | 4.88 |
| bicho_vento | 8 | 4.88 |
| fofoca_vila | 8 | 4.88 |
| golem_orgulho | 8 | 4.88 |
| jogador_noite | 8 | 4.88 |
| jogador_voltou | 8 | 4.88 |
| madrugada | 8 | 4.88 |
| monstros_noite | 8 | 4.88 |
| pedreiro | 8 | 4.88 |
| vila_esmeralda | 8 | 4.88 |
| vila_manha | 8 | 4.88 |
| vila_pao | 8 | 4.88 |
| vila_sino | 8 | 4.88 |
| vila_tempestade | 8 | 4.88 |
| warden_vibracao | 8 | 4.88 |
| ceu_nuvens | 8 | 5.00 |
| curiosidade_abelha | 8 | 5.00 |
| fazendeiro | 8 | 5.00 |
| trocas_vila | 8 | 5.00 |
| vila_passando_troca | 8 | 5.00 |
| zumbis_na_vila | 8 | 5.00 |

## Problemas apontados (famílias abaixo do mínimo primeiro)

### curiosidade_quadrado (3.25)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: O sol nasce sempre do mesmo lado, já reparou? / 1: Já reparei, e nunca entendi por quê. / 0: Melhor não pensar muito nisso.
  - ⚠ A fala 'Melhor não pensar muito nisso.' soa um pouco evasiva para um aldeão, que normalmente é curioso e tagarela, mas ainda é plausível.
- nota 3: 0: O sol nasce sempre do mesmo lado, já reparou? / 1: Que ideia estranha, mas me deixou pensando. / 0: Pelo menos é um mundo bonito.
  - ⚠ A fala 'Que ideia estranha, mas me deixou pensando.' soa mais como um comentário de um jogador do que de um aldeão, que normalmente fala de forma simples e direta.
  - ⚠ A fala 'Pelo menos é um mundo bonito.' é um fecho vago e não responde diretamente à fala anterior, deixando a conversa sem conclusão clara.
- nota 3: 0: O sol nasce sempre do mesmo lado, já reparou? / 1: Esse mundo é cheio de mistérios. / 0: Melhor não pensar muito nisso.
  - ⚠ Fala 1: 'Esse mundo é cheio de mistérios.' soa filosófica demais para um aldeão comum.
  - ⚠ Fala 0 (fecho): 'Melhor não pensar muito nisso.' é vaga e não fecha a conversa de forma natural.
- nota 4: 0: Eu sonhei que o mundo era redondo. / 1: Esse mundo é cheio de mistérios. / 0: Melhor não pensar muito nisso.
  - ⚠ A fala 'Eu sonhei que o mundo era redondo' é um pouco filosófica demais para um aldeão comum, mas ainda aceitável.
  - ⚠ A resposta 'Esse mundo é cheio de mistérios' é genérica e não desenvolve a ideia do sonho, mas fecha de forma passável.
- nota 3: 0: O sol nasce sempre do mesmo lado, já reparou? / 1: Que ideia estranha, mas me deixou pensando. / 0: Melhor não pensar muito nisso.
  - ⚠ Fala 0: 'O sol nasce sempre do mesmo lado, já reparou?' soa filosófica demais para um aldeão comum.
  - ⚠ Fala 1: 'Que ideia estranha, mas me deixou pensando.' é vaga e não desenvolve a conversa.

### cercado (3.38)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 4: 0: O cercado está cheio hoje. / 1: Gosto de ter companhia por perto. / 0: Hoje está bom aqui.
  - ⚠ A fala 'Hoje está bom aqui.' é um fecho um pouco vago e não responde diretamente à fala anterior, mas ainda é aceitável.
- nota 3: 0: O cercado está cheio hoje. / 1: Perto da cerca é onde eu fico. / 0: Hoje está bom aqui.
  - ⚠ A resposta 'Perto da cerca é onde eu fico' não responde de fato ao comentário sobre o cercado cheio
  - ⚠ O fecho 'Hoje está bom aqui' é genérico e não fecha a conversa iniciada
- nota 3: 0: O cercado está cheio hoje. / 1: Perto da cerca é onde eu fico. / 0: Assim ninguém se perde.
  - ⚠ A resposta 'Perto da cerca é onde eu fico' não responde de fato ao comentário sobre o cercado cheio
  - ⚠ O fecho 'Assim ninguém se perde' não conecta bem com a fala anterior sobre ficar perto da cerca
- nota 3: 0: Tem espaço de sobra aqui dentro. / 1: Gosto de ter companhia por perto. / 0: Assim ninguém se perde.
  - ⚠ Fala 0 'Tem espaço de sobra aqui dentro.' é vaga e não estabelece contexto claro para a situação.
  - ⚠ Fala 1 'Gosto de ter companhia por perto.' é genérica e não responde diretamente à fala anterior.
- nota 3: 0: Tem espaço de sobra aqui dentro. / 1: Perto da cerca é onde eu fico. / 0: Assim ninguém se perde.
  - ⚠ Fala 0 'Tem espaço de sobra aqui dentro.' é vaga e não estabelece contexto claro para a conversa.
  - ⚠ Fala 1 'Perto da cerca é onde eu fico.' parece uma resposta desconexa, sem relação direta com a fala anterior.

### creeper_zumbi (3.62)  _um creeper e um zumbi; uma situação qualquer do dia a dia_
- nota 2: 0: Ssss... hoje eu exploro. / 1: Grrr... gato é bicho ruim. / 0: Ssss...
  - ⚠ Fala 0 'Ssss... hoje eu exploro.' não combina com creeper, que não fala de explorar, mas de explodir.
  - ⚠ Fala 1 'Grrr... gato é bicho ruim.' não responde à fala anterior, quebra a conversa.
- nota 4: 0: Ssss... hoje eu exploro. / 1: Grrr... explode longe de mim. / 0: Ssss...
  - ⚠ A fala do creeper 'Ssss... hoje eu exploro.' é ambígua: 'exploro' pode ser entendido como explorar o ambiente, mas para um creeper o verbo 'explodir' seria mais característico; ainda assim, é aceitáve
  - ⚠ A resposta do zumbi 'Grrr... explode longe de mim.' é coerente, mas o fecho 'Ssss...' do creeper é muito vago e não encerra claramente a conversa.
- nota 3: 0: Ssss... hoje eu exploro. / 1: Grrr... gato é bicho ruim. / 0: Ssss... silêncio.
  - ⚠ Fala 0 'Ssss... hoje eu exploro.' não combina com creeper, que não explora, apenas vagueia e explode.
  - ⚠ Fala 1 'Grrr... gato é bicho ruim.' é uma resposta desconexa da fala anterior.
- nota 4: 0: Ssss... não chegue perto de gato. / 1: Grrr... explode longe de mim. / 0: Ssss... silêncio.
  - ⚠ A fala 'Ssss... silêncio.' é um fecho um pouco abrupto, mas aceitável para um creeper.
- nota 4: 0: Ssss... hoje eu exploro. / 1: Grrr... explode longe de mim. / 0: Ssss... silêncio.
  - ⚠ A fala 'Ssss... silêncio.' é um fecho um pouco vago, mas aceitável para um creeper.

### bicho_jogador_chuva (3.88)  _dois animais da fazenda; está chovendo_
- nota 4: 0: O humano está na chuva. / 1: Eu prefiro um canto seco. / 0: Eu só queria sombra.
  - ⚠ A fala 'Eu só queria sombra' não fecha a conversa de forma clara, pois não responde diretamente à preferência por um canto seco.
- nota 4: 0: Olha o humano debaixo da chuva. / 1: Eu prefiro um canto seco. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Eu prefiro um canto seco' é um pouco vaga, mas aceitável para animais da fazenda.
  - ⚠ A fala 'Cada um com o seu gosto' soa levemente filosófica para animais simples, mas ainda passável.
- nota 4: 0: Olha o humano debaixo da chuva. / 1: Fica molhado, coitado. / 0: Eu só queria sombra.
  - ⚠ A fala 'Eu só queria sombra' não fecha a conversa de forma clara, pois não responde diretamente à fala anterior sobre o humano molhado.
- nota 3: 0: Olha o humano debaixo da chuva. / 1: Ele não se importa? / 0: Eu só queria sombra.
  - ⚠ Fala 0 'Eu só queria sombra' não fecha a conversa de forma coerente com a resposta anterior sobre o humano não se importar com a chuva.
  - ⚠ A situação de chuva não é diretamente aproveitada na última fala, que menciona sombra, criando desconexão.
- nota 3: 0: Olha o humano debaixo da chuva. / 1: Eu prefiro um canto seco. / 0: Eu só queria sombra.
  - ⚠ O fecho 'Eu só queria sombra' não responde bem ao 'canto seco' e não fecha a conversa sobre a chuva
  - ⚠ Sombra não resolve chuva; mistura os temas e soa desconexo

### bicho_jogador_fome (3.88)  _dois animais da fazenda; o jogador está com fome_
- nota 4: 0: O humano está com cara de fome. / 1: Aqui só tem capim, mas é bom. / 0: Que ache comida logo.
  - ⚠ 'Aqui só tem capim, mas é bom' soa um pouco como oferta de comida ao humano, o que é estranho para um animal falando com outro
- nota 4: 0: O humano deve estar faminto. / 1: Ele devia achar algo para comer. / 0: Eu entendo bem essa fome.
  - ⚠ A fala 'Eu entendo bem essa fome.' é um pouco vaga para fechar a conversa, mas ainda faz sentido.
- nota 4: 0: O humano deve estar faminto. / 1: Aqui só tem capim, mas é bom. / 0: Eu entendo bem essa fome.
  - ⚠ A fala 'Aqui só tem capim, mas é bom.' soa estranha para um animal da fazenda, pois capim é alimento natural para eles, não uma limitação.
- nota 4: 0: O humano ficou olhando para a comida. / 1: Ele devia achar algo para comer. / 0: Que ache comida logo.
  - ⚠ Fala 0: 'O humano ficou olhando para a comida.' é um pouco vaga, pois não especifica que comida é essa, mas ainda faz sentido.
  - ⚠ Fala 1: 'Ele devia achar algo para comer.' soa levemente formal para uma conversa entre animais, mas é aceitável.
- nota 4: 0: O humano deve estar faminto. / 1: Aqui só tem capim, mas é bom. / 0: Que ache comida logo.
  - ⚠ A fala 'Aqui só tem capim, mas é bom.' soa estranha para um animal da fazenda, pois capim é alimento natural para eles, não uma limitação.

### bicho_jogador_noite (3.88)  _dois animais da fazenda; é noite_
- nota 4: 0: Olha lá, o humano no escuro. / 1: Eu fico quieto até ele passar. / 0: Eu fico por aqui.
  - ⚠ Fala 1: 'Eu fico quieto até ele passar' soa um pouco vago, mas aceitável para animais.
  - ⚠ Fala 0 (fecho): 'Eu fico por aqui' não fecha claramente a conversa, parece apenas uma continuação.
- nota 4: 0: O humano caminha de noite. / 1: Melhor ele passar longe de mim. / 0: Que passe sem nos incomodar.
  - ⚠ Fala 1 'Melhor ele passar longe de mim.' soa um pouco vaga e não especifica por que o animal quer distância, mas ainda é plausível para animais noturnos.
- nota 4: 0: O humano caminha de noite. / 1: Eu fico quieto até ele passar. / 0: Que passe sem nos incomodar.
  - ⚠ Fala 0 'O humano caminha de noite.' é uma observação neutra, mas não especifica qual animal fala; poderia ser dita por qualquer animal da fazenda, o que é aceitável.
  - ⚠ Fala 1 'Eu fico quieto até ele passar.' sugere medo ou cautela, o que é plausível para animais noturnos, mas não é específico de uma espécie.
- nota 4: 0: Tem alguém andando no escuro. / 1: Ele devia ter medo do escuro. / 0: Que passe sem nos incomodar.
  - ⚠ 'Ele devia ter medo do escuro' soa um pouco especulativo/filosófico para um animal, mas aceitável
- nota 3: 0: O humano caminha de noite. / 1: Ele devia ter medo do escuro. / 0: Eu fico por aqui.
  - ⚠ Fala 0 'O humano caminha de noite.' é uma observação neutra, mas não combina com o tom de alerta ou medo esperado de animais à noite.
  - ⚠ Fala 1 'Ele devia ter medo do escuro.' soa mais como um julgamento humano do que uma preocupação instintiva de animal.

### curiosidade_enderman (3.88)  _dois aldeões; é noite_
- nota 2: 0: Já viu aqueles olhos roxos no escuro? / 1: Nunca falei com um, mas tenho vontade. / 0: Cada um com seu jeito, né?
  - ⚠ 'Nunca falei com um, mas tenho vontade' — aldeão querendo conversar com Enderman/olhos roxos é bizarro e perigoso, não combina com aldeão medroso
  - ⚠ 'Cada um com seu jeito, né?' — fecha de forma filosófica e desconexa, não responde ao medo do primeiro nem à vontade do segundo
- nota 4: 0: Dizem que enderman odeia água. / 1: Nunca falei com um, mas tenho vontade. / 0: Deve ser uma vida estranha.
  - ⚠ A fala 'Nunca falei com um, mas tenho vontade.' soa um pouco estranha para um aldeão, pois eles normalmente não demonstram curiosidade em conversar com endermen, que são criaturas hostis e assustadora
- nota 4: 0: Já viu aqueles olhos roxos no escuro? / 1: Nunca falei com um, mas tenho vontade. / 0: Deve ser uma vida estranha.
  - ⚠ A fala 'Nunca falei com um, mas tenho vontade.' sugere curiosidade sobre Endermen, o que é plausível, mas a resposta não responde diretamente à pergunta sobre ter visto os olhos roxos.
  - ⚠ O fecho 'Deve ser uma vida estranha.' é um pouco vago e não conclui claramente a conversa, embora seja aceitável.
- nota 4: 0: Tem uns bichos altos que levam blocos embora. / 1: Melhor não encarar, dizem que ficam bravos. / 0: Cada um com seu jeito, né?
  - ⚠ Fala 0: 'Tem uns bichos altos que levam blocos embora.' é vaga; aldeões normalmente se referem a Endermen de forma mais específica ou temerosa.
  - ⚠ Fala 0: 'Cada um com seu jeito, né?' soa muito filosófica para um aldeão, que tende a ser mais prático ou medroso.
- nota 4: 0: Já viu aqueles olhos roxos no escuro? / 1: Eles somem num piscar de olhos. / 0: Cada um com seu jeito, né?
  - ⚠ A fala 'Cada um com seu jeito, né?' não fecha claramente a conversa sobre olhos roxos, soando um pouco vaga.

### jogador_ameacou (3.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já ameaçou quem abre com palavras (fato verificado)_
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Ameaça de boca pesa, né? / 0: Vou dar uma chance.
  - ⚠ 'Ameaça de boca pesa, né?' soa um pouco reflexivo demais para um aldeão/animal simples, mas é passável
  - ⚠ O fecho 'Vou dar uma chance' é curto e fecha bem, mas não reage diretamente à fala 1
- nota 3: 0: Eu me assustei com as palavras de o humano outro dia. / 1: Ameaça de boca pesa, né? / 0: Vou dar uma chance.
  - ⚠ Fala 1 'Ameaça de boca pesa, né?' soa como um comentário filosófico, o que não combina com criaturas simples como vacas ou aldeões.
  - ⚠ Fala 0 'Vou dar uma chance.' é vaga e não fecha claramente a conversa sobre o medo do humano.
- nota 4: 0: Eu me assustei com as palavras de o humano outro dia. / 1: Tem quem fale sem pensar. / 0: Vou dar uma chance.
  - ⚠ A fala 'Eu me assustei com as palavras de o humano outro dia.' soa estranha em português; seria mais natural 'Eu me assustei com as palavras do humano outro dia.'
  - ⚠ A fala 'Tem quem fale sem pensar.' é um pouco vaga, mas aceitável.
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Tem quem fale sem pensar. / 0: Vou dar uma chance.
  - ⚠ A fala 'Tem quem fale sem pensar.' é um pouco vaga e não responde diretamente à ameaça, mas ainda é plausível.
  - ⚠ O fecho 'Vou dar uma chance.' é aceitável, mas poderia ser mais natural se conectasse melhor com a fala anterior.
- nota 4: 0: O humano me ameaçou uma vez, só com palavras. / 1: Espero que tenha sido um mal-entendido. / 0: Pode ser.
  - ⚠ A fala 'O humano me ameaçou uma vez, só com palavras.' soa um pouco formal para uma conversa casual entre criaturas da fazenda, mas é aceitável.
  - ⚠ A resposta 'Espero que tenha sido um mal-entendido.' é um pouco genérica e poderia ser mais específica ao contexto da ameaça.

### jogador_apresenta (3.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador; NÃO: quem responde já conhece o jogador_
- nota 4: 0: Aquele humano eu já conheço de outros dias. / 1: Eu ainda não o conhecia. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Eu ainda não o conhecia.' soa um pouco formal para uma conversa casual entre criaturas da mesma espécie, mas é aceitável.
- nota 3: 0: Reconheci o humano, já nos vimos antes. / 1: Nunca tinha cruzado com ele. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Nunca tinha cruzado com ele.' contradiz a situação, pois quem responde não conhece o jogador, mas a fala sugere que já o viu antes.
  - ⚠ A fala 'Vale a pena conhecer.' é vaga e não fecha claramente a conversa, deixando o diálogo sem conclusão natural.
- nota 4: 0: O humano ali já esteve comigo antes. / 1: Eu ainda não o conhecia. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Eu ainda não o conhecia.' soa um pouco formal para uma conversa casual entre criaturas da mesma espécie, mas é aceitável.
- nota 4: 0: O humano ali já esteve comigo antes. / 1: Para mim é a primeira vez que o vejo. / 0: Ele é tranquilo, pode confiar.
  - ⚠ A fala 'Ele é tranquilo, pode confiar.' soa um pouco genérica, mas ainda plausível para criaturas calmas.
- nota 4: 0: Reconheci o humano, já nos vimos antes. / 1: Para mim é a primeira vez que o vejo. / 0: Vale a pena conhecer.
  - ⚠ A fala 'Vale a pena conhecer.' soa um pouco vaga e não fecha a conversa de forma natural, pois não responde diretamente à fala anterior.

### jogador_conhecido (3.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador_
- nota 3: 0: Eu já conversei com o humano, sabia? / 1: Me conta, o que foi que disse? / 0: Cada conversa é diferente.
  - ⚠ Fala 0 'Cada conversa é diferente.' é vaga e não responde diretamente à pergunta 'o que foi que disse?', deixando a conversa sem fechamento claro.
  - ⚠ A resposta 'Me conta, o que foi que disse?' é natural, mas a fala final não fornece conteúdo, tornando o diálogo pouco informativo.
- nota 4: 0: Já cruzei com o humano por aqui antes. / 1: Que interessante. / 0: Foi tranquilo, achei simpático.
  - ⚠ A fala 'Que interessante.' é muito vaga e não combina com a resposta esperada de uma criatura da mesma espécie em uma conversa casual.
  - ⚠ O fecho 'Foi tranquilo, achei simpático.' não responde diretamente à fala anterior, deixando a conversa sem um encerramento natural.
- nota 4: 0: O humano e eu já conversamos um pouco. / 1: Me conta, o que foi que disse? / 0: Foi tranquilo, achei simpático.
  - ⚠ Fala 1 'Me conta, o que foi que disse?' soa um pouco formal para uma conversa casual entre criaturas da mesma espécie, mas é aceitável.
- nota 3: 0: Eu já conversei com o humano, sabia? / 1: E como foi? / 0: Cada conversa é diferente.
  - ⚠ Fala 0 'Cada conversa é diferente.' é vaga e não fecha a conversa de forma satisfatória.
  - ⚠ Fala 1 'E como foi?' é genérica e não aprofunda a interação.
- nota 4: 0: O humano e eu já conversamos um pouco. / 1: E como foi? / 0: Cada conversa é diferente.
  - ⚠ 'Cada conversa é diferente' é um fecho um pouco vago/filosófico para um aldeão ou animal calmo
  - ⚠ A fala 1 'E como foi?' é genérica e não reage ao conteúdo específico da abertura

### jogador_dono (3.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre foi domado e agora pertence ao jogador (fato verificado)_
- nota 4: 0: Agora eu sou de o humano, e isso me faz bem. / 1: Ele te trata bem? / 0: Trata, sim, e estou bem.
  - ⚠ A fala 'Agora eu sou de o humano' soa estranha; o natural seria 'Agora eu sou do humano'.
  - ⚠ A expressão 'e isso me faz bem' é um pouco formal para uma conversa curta entre criaturas.
- nota 4: 0: O humano é o meu dono agora. / 1: Está sendo bem cuidado? / 0: Trata, sim, e estou bem.
  - ⚠ 'Trata, sim, e estou bem' soa truncado; 'Ele me trata bem, sim' seria mais natural em português falado
- nota 4: 0: O humano cuida de mim agora, sabia? / 1: Está feliz assim? / 0: Trata, sim, e estou bem.
  - ⚠ A fala 'Trata, sim, e estou bem.' soa um pouco truncada; 'Trata, sim, e estou bem.' poderia ser mais natural como 'Ele trata, sim, e estou bem.'
- nota 4: 0: O humano cuida de mim agora, sabia? / 1: Está sendo bem cuidado? / 0: Trata, sim, e estou bem.
  - ⚠ 'Trata, sim, e estou bem' soa truncado; 'Ele trata, sim' seria mais natural
  - ⚠ O fecho repete a pergunta de forma pouco fluida em vez de fechar com algo como 'Sim, estou bem'
- nota 3: 0: Agora eu sou de o humano, e isso me faz bem. / 1: Está feliz assim? / 0: Estou, sim, de verdade.
  - ⚠ Fala 0: 'Agora eu sou de o humano' soa estranho; o natural seria 'do humano'.
  - ⚠ Fala 0: 'e isso me faz bem' é vago e pouco natural para uma criatura domada; espera-se algo como 'estou contente' ou 'gosto daqui'.

### aranha_zumbi (4.00)  _uma aranha e um zumbi; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... a sua fome é barulhenta. / 1: Grrr... teia gruda. / 0: Sss... uma corrida, então.
  - ⚠ A fala 'Grrr... teia gruda.' é um pouco vaga e não responde diretamente à provocação da aranha, mas ainda é plausível para um zumbi.
  - ⚠ O fecho 'Sss... uma corrida, então.' é aceitável, mas poderia ser mais natural se a aranha respondesse de forma mais direta à fala do zumbi.
- nota 3: 0: Sss... a sua fome é barulhenta. / 1: Grrr... teia gruda. / 0: Sss... paciência.
  - ⚠ Fala 0 'Sss... a sua fome é barulhenta.' é estranha para uma aranha, pois aranhas não costumam comentar sobre fome de zumbis.
  - ⚠ Fala 1 'Grrr... teia gruda.' é uma resposta vaga e não se conecta claramente com a fala anterior.
- nota 4: 0: Sss... eu fico no teto, você no chão. / 1: Grrr... quem pegar o humano primeiro. / 0: Sss... uma corrida, então.
  - ⚠ A fala 'Grrr... quem pegar o humano primeiro.' soa como um desafio amigável, o que é estranho para um zumbi, que normalmente não demonstra espírito esportivo.
- nota 4: 0: Sss... eu fico no teto, você no chão. / 1: Grrr... teia gruda. / 0: Sss... paciência.
  - ⚠ A fala 'Grrr... teia gruda.' é um pouco vaga, mas aceitável para um zumbi.
  - ⚠ A fala 'Sss... paciência.' é um fecho um pouco abrupto, mas funciona.
- nota 3: 0: Sss... eu fico no teto, você no chão. / 1: Grrr... teia gruda. / 0: Sss... uma corrida, então.
  - ⚠ 'teia gruda' é resposta fraca e não reage bem à fala anterior sobre teto/chão
  - ⚠ o fecho 'uma corrida, então' não decorre do que o zumbi disse; parece aleatório

### bicho_filhotes_cuidado (4.00)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 3: 0: Filhote cansa de tanto brincar. / 1: Os meus dormem em cima de mim. / 0: Que cresçam fortes.
  - ⚠ Fala 0 'Filhote cansa de tanto brincar.' soa como narração, não como fala natural de um animal.
  - ⚠ Fala 1 'Os meus dormem em cima de mim.' é plausível, mas falta contexto para saber se é resposta direta.
- nota 3: 0: Filhote cansa de tanto brincar. / 1: Os meus dormem em cima de mim. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Filhote cansa de tanto brincar.' é genérica e não especifica qual animal, mas aceitável.
  - ⚠ Fala 1 'Os meus dormem em cima de mim.' soa estranha para animais de fazenda, pois não é comum filhotes dormirem sobre os pais, exceto em aves.
- nota 4: 0: Filhote cansa de tanto brincar. / 1: Daqui a pouco já estão do nosso tamanho. / 0: Que cresçam fortes.
  - ⚠ Fala 0 'Filhote cansa de tanto brincar.' soa um pouco genérica, sem especificar o animal, mas é aceitável.
  - ⚠ Fala 1 'Daqui a pouco já estão do nosso tamanho.' é um pouco vaga, mas plausível para animais de fazenda.
- nota 3: 0: Os pequenos vivem atrás da gente. / 1: Os meus dormem em cima de mim. / 0: Cada um cresce no seu tempo.
  - ⚠ Fala 0 'Os pequenos vivem atrás da gente.' é vaga e não estabelece contexto claro para a conversa.
  - ⚠ Fala 1 'Os meus dormem em cima de mim.' pode ser estranha para animais de fazenda, pois não é comum filhotes dormirem sobre os pais.
- nota 4: 0: Os filhotes não param quietos. / 1: Os meus dormem em cima de mim. / 0: Cada um cresce no seu tempo.
  - ⚠ A fala 'Os meus dormem em cima de mim' é um pouco específica demais para uma resposta genérica, mas ainda plausível para animais de fazenda.

### bicho_jogador_ferido (4.00)  _dois animais da fazenda; o jogador está ferido_
- nota 4: 0: O humano parece sentir dor. / 1: Eu fico quieto para não incomodar. / 0: Fico de olho nele.
  - ⚠ Fala 1: 'Eu fico quieto para não incomodar.' soa mais como pensamento humano do que fala de animal de fazenda, mas é aceitável.
  - ⚠ Fala 0 (fecho): 'Fico de olho nele.' é um pouco vago, mas fecha a conversa de forma coerente.
- nota 4: 0: Olha como o humano anda devagar. / 1: Eu fico quieto para não incomodar. / 0: Que melhore logo.
  - ⚠ Fala 1: 'Eu fico quieto para não incomodar' soa mais como um pensamento do que uma resposta direta à observação sobre o humano andar devagar.
  - ⚠ Fala 0 (fecho): 'Que melhore logo' é um pouco abrupto, mas aceitável.
- nota 4: 0: O humano parece sentir dor. / 1: Ele devia descansar à sombra. / 0: Que melhore logo.
  - ⚠ Fala 1 'Ele devia descansar à sombra.' soa mais como conselho de aldeão do que de animal de fazenda, mas ainda é plausível para animais que observam o humano.
- nota 3: 0: Olha como o humano anda devagar. / 1: Eu fico quieto para não incomodar. / 0: Fico de olho nele.
  - ⚠ Fala 0: 'Olha como o humano anda devagar.' soa mais como observação de um animal selvagem do que de um animal de fazenda, que normalmente não comenta o estado do jogador.
  - ⚠ Fala 1: 'Eu fico quieto para não incomodar.' é passável, mas um animal de fazenda provavelmente não se preocuparia em 'não incomodar'.

### jogador_sem_nome (4.00)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já conhece o jogador; NÃO: quem abre sabe o nome do jogador_
- nota 4: 0: O humano deve ter um nome, mas eu não sei. / 1: Para mim é só o humano. / 0: Eu pergunto da próxima vez.
  - ⚠ A fala 'Para mim é só o humano.' soa um pouco vaga e não responde diretamente à curiosidade sobre o nome, mas é aceitável para criaturas simples.
- nota 4: 0: Ninguém sabe como o humano se chama. / 1: Eu também só o chamo de humano. / 0: Quem sabe um dia ele conta.
  - ⚠ A fala 0 diz 'ninguém sabe como o humano se chama', mas a situação diz que quem abre já conhece o jogador — conhecer sem saber o nome é coerente, porém 'ninguém sabe' soa categórico demais para uma cr
  - ⚠ O fecho 'Quem sabe um dia ele conta' é levemente reflexivo/filosófico para um animal, embora aceitável para aldeão
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Para mim é só o humano. / 0: Eu pergunto da próxima vez.
  - ⚠ A fala 'Nunca perguntei o nome de o humano.' soa estranha: 'de o humano' deveria ser 'do humano'.
  - ⚠ A resposta 'Para mim é só o humano.' é um pouco vaga, mas aceitável.
- nota 4: 0: Nunca perguntei o nome de o humano. / 1: Alguém precisa perguntar. / 0: Eu pergunto da próxima vez.
  - ⚠ A fala 'Nunca perguntei o nome de o humano.' soa estranha em português; o correto seria 'do humano'.
  - ⚠ A resposta 'Alguém precisa perguntar.' é um pouco vaga, mas aceitável.
- nota 4: 0: Ninguém sabe como o humano se chama. / 1: Para mim é só o humano. / 0: Quem sabe um dia ele conta.
  - ⚠ A fala 0 diz 'ninguém sabe como o humano se chama', mas a situação diz que quem abre já conhece o jogador — conhecer sem saber o nome é coerente, porém 'ninguém sabe' soa categórico demais para uma cr
  - ⚠ O fecho 'Quem sabe um dia ele conta' é levemente filosófico/reflexivo para um animal, embora aceitável para aldeão

### monstros_armadura (4.00)  _dois monstros hostis; o jogador veste armadura_
- nota 4: 0: Aquele humano está com uma armadura de ferro. / 1: Todo metal cansa no fim. / 0: Cada brecha serve.
  - ⚠ A fala 'Todo metal cansa no fim.' soa filosófica demais para monstros hostis, que normalmente não refletem sobre desgaste de materiais.
  - ⚠ A fala 'Cada brecha serve.' é vaga e não deixa claro se é uma conclusão prática ou uma ameaça, mas ainda é aceitável.
- nota 4: 0: Olha só, o humano trouxe uma armadura de ferro. / 1: A gente cansa ele primeiro. / 0: Paciência vence qualquer armadura.
  - ⚠ A fala 'A gente cansa ele primeiro' é um pouco vaga, mas aceitável para monstros hostis.
  - ⚠ A fala 'Paciência vence qualquer armadura' soa levemente filosófica para monstros hostis, mas ainda plausível.
- nota 4: 0: Aquele humano está com uma armadura de ferro. / 1: Eu espero ele baixar a guarda. / 0: Cada brecha serve.
  - ⚠ A fala 'Eu espero ele baixar a guarda.' soa um pouco formal para um monstro hostil; 'Vou esperar ele baixar a guarda' seria mais natural.
- nota 2: 0: Olha só, o humano trouxe uma armadura de ferro. / 1: Todo metal cansa no fim. / 0: Paciência vence qualquer armadura.
  - ⚠ 'Todo metal cansa no fim' é uma fala filosófica/abstrata demais para um monstro hostil
  - ⚠ 'Paciência vence qualquer armadura' soa como provérbio de sábio, não de monstro agressivo
- nota 4: 0: Olha só, o humano trouxe uma armadura de ferro. / 1: Todo metal cansa no fim. / 0: Cada brecha serve.
  - ⚠ A fala 'Todo metal cansa no fim.' soa filosófica demais para monstros hostis, que normalmente não refletem sobre desgaste de materiais.

### monstros_chuva (4.00)  _dois monstros hostis; está chovendo_
- nota 4: 0: A água me deixa de mau humor. / 1: Os humanos ficam trancados, mas é irritante. / 0: Eu espero aqui no escuro.
  - ⚠ A fala 'Os humanos ficam trancados, mas é irritante.' é um pouco vaga: não fica claro se o irritante é a chuva ou os humanos trancados.
  - ⚠ A fala 'Eu espero aqui no escuro.' não conecta diretamente com a resposta anterior, deixando o fecho um pouco solto.
- nota 4: 0: Chuva de novo, que droga. / 1: Os humanos ficam trancados, mas é irritante. / 0: Depois a caça recomeça.
  - ⚠ A fala 'Os humanos ficam trancados, mas é irritante.' é um pouco vaga: não fica claro se a irritação é com a chuva ou com os humanos trancados.
- nota 4: 0: A água me deixa de mau humor. / 1: Os humanos ficam trancados, mas é irritante. / 0: Depois a caça recomeça.
  - ⚠ A fala 'Os humanos ficam trancados, mas é irritante.' é um pouco vaga: não fica claro se o irritante é a chuva ou os humanos trancados.
  - ⚠ A fala 'Depois a caça recomeça.' é um fecho aceitável, mas poderia ser mais natural se conectasse melhor com a irritação mencionada.
- nota 3: 0: Chuva de novo, que droga. / 1: Eu só quero que passe. / 0: Eu espero aqui no escuro.
  - ⚠ Fala 0 'Eu espero aqui no escuro' não fecha a conversa de forma clara, soa como um pensamento solto.
  - ⚠ Fala 1 'Eu só quero que passe' é vaga e não responde diretamente à reclamação sobre a chuva.

### sol (4.00)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é de dia; o céu está limpo_
- nota 3: 0: Acordei de bom humor com esse sol. / 1: Também acho. / 0: Pena que a noite chega logo.
  - ⚠ A resposta 'Também acho.' não combina com a fala anterior, que expressa um estado pessoal ('Acordei de bom humor'), não uma opinião.
  - ⚠ O fecho 'Pena que a noite chega logo.' muda o tom da conversa de forma abrupta, sem conexão clara com o bom humor inicial.
- nota 3: 0: O céu está limpo, nem uma nuvem. / 1: Nem me fale. / 0: Pena que a noite chega logo.
  - ⚠ A fala 'Nem me fale.' soa como reclamação, mas não há contexto negativo anterior; 'O céu está limpo, nem uma nuvem.' é neutro/positivo.
  - ⚠ A fala 'Pena que a noite chega logo.' introduz um tom melancólico que não é desenvolvido; a conversa termina abruptamente.
- nota 3: 0: Dia perfeito para ficar à toa. / 1: Nem me fale. / 0: Pena que a noite chega logo.
  - ⚠ 'Nem me fale' é resposta de quem concorda com uma queixa, mas a fala 0 foi positiva ('dia perfeito'), então a resposta não combina
  - ⚠ o fecho 'Pena que a noite chega logo' contradiz o tom calmo e positivo da abertura sem transição
- nota 4: 0: O céu está limpo, nem uma nuvem. / 1: Pois é. / 0: Hoje está tudo no lugar.
  - ⚠ A resposta 'Pois é.' é muito seca e não acrescenta nada, mas ainda é natural
  - ⚠ O fecho 'Hoje está tudo no lugar.' é vago e não retoma bem o céu limpo, soando um pouco solto
- nota 4: 0: Que dia bonito hoje. / 1: Aproveita, que o tempo muda rápido. / 0: Hoje está tudo no lugar.
  - ⚠ O fecho 'Hoje está tudo no lugar' é um pouco vago e não responde diretamente ao aviso sobre o tempo mudar

### vila_comerciante (4.00)  _dois aldeões; é de dia_
- nota 0: 0: O comerciante de lhamas vende coisas raras. / 1: As lhamas dele cospem em quem se aproxima. / 0: Cada visita rende uma boa história.
  - ⚠ avaliador falhou
- nota 0: 0: O comerciante de lhamas vende coisas raras. / 1: Ele nunca fica mais de um dia. / 0: Cada visita rende uma boa história.
  - ⚠ avaliador falhou
- nota 0: 0: Comerciante que aparece do nada traz boas histórias. / 1: As lhamas dele cospem em quem se aproxima. / 0: Quem sabe ele volte.
  - ⚠ avaliador falhou
- nota 0: 0: Comerciante viajante é sempre uma surpresa. / 1: As lhamas dele cospem em quem se aproxima. / 0: Cada visita rende uma boa história.
  - ⚠ avaliador falhou
- nota 0: 0: Comerciante viajante é sempre uma surpresa. / 1: Ele nunca fica mais de um dia. / 0: Cada visita rende uma boa história.
  - ⚠ avaliador falhou

### vila_gato (4.00)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 0: 0: Gato na vila é bom para afastar creeper. / 1: Creeper nem chega perto de um gato. / 0: Gato é bem-vindo em qualquer casa.
  - ⚠ avaliador falhou
- nota 4: 0: Um gato dormindo na porta dá sorte. / 1: Eu deixo leite para o gato da vila. / 0: Cada um com o seu trabalho.
  - ⚠ O fecho 'Cada um com o seu trabalho' não conecta bem com a fala anterior sobre deixar leite para o gato
- nota 4: 0: Um gato dormindo na porta dá sorte. / 1: Creeper nem chega perto de um gato. / 0: Cada um com o seu trabalho.
  - ⚠ A fala 'Cada um com o seu trabalho.' não fecha claramente a conversa sobre gatos e sorte.
- nota 4: 0: Gato na vila é bom para afastar creeper. / 1: Gato quieto é gato em guarda. / 0: Gato é bem-vindo em qualquer casa.
  - ⚠ 'Gato quieto é gato em guarda' soa um pouco forçado como provérbio, mas é passável
- nota 4: 0: Dizem que os gatos protegem a vila dos creepers. / 1: Gato quieto é gato em guarda. / 0: Cada um com o seu trabalho.
  - ⚠ 'Gato quieto é gato em guarda' soa um pouco forçado como provérbio, mas passa

### zumbi_esqueleto (4.00)  _um zumbi e um esqueleto; uma situação qualquer do dia a dia_
- nota 4: 0: Você só sabe atirar de longe. / 1: De perto você só arrasta o pé. / 0: Grrr... vamos caçar juntos.
  - ⚠ A fala 'Grrr... vamos caçar juntos.' soa amigável demais para um zumbi, que normalmente é hostil e não coopera com esqueletos.
- nota 4: 0: Você só sabe atirar de longe. / 1: De perto você só arrasta o pé. / 0: Hmm... tá bom.
  - ⚠ A fala 'Hmm... tá bom.' soa um pouco vaga e não fecha a conversa de forma clara, mas é aceitável para um zumbi.
- nota 4: 0: Dá para parar de me acertar com flecha? / 1: De perto você só arrasta o pé. / 0: Hmm... tá bom.
  - ⚠ A fala do esqueleto 'De perto você só arrasta o pé.' é um pouco vaga, mas faz sentido como provocação.
  - ⚠ O fecho 'Hmm... tá bom.' é aceitável, mas poderia ser mais reativo à provocação.
- nota 4: 0: Seus ossos fazem barulho demais. / 1: Foi sem querer. Quase. / 0: Hmm... tá bom.
  - ⚠ A fala 'Foi sem querer. Quase.' é ambígua e pode soar estranha para um esqueleto, que normalmente não se desculpa.
  - ⚠ O fecho 'Hmm... tá bom.' é muito passivo para um zumbi, que costuma ser mais agressivo ou persistente.
- nota 4: 0: Seus ossos fazem barulho demais. / 1: De perto você só arrasta o pé. / 0: Grrr... vamos caçar juntos.
  - ⚠ O fecho 'vamos caçar juntos' é um pouco amigável demais para zumbi e esqueleto, que costumam ser hostis entre si, mas ainda passa como cooperação de mobs hostis

### armeiro (4.12)  _villager:armorer e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: A armadura sai melhor com o fogo forte. / 1: Deve ser pesado trabalhar com tanto metal. / 0: O fogo da forja não pode apagar.
  - ⚠ A fala 'O fogo da forja não pode apagar.' não fecha claramente a conversa, soa mais como continuação do que fecho.
- nota 4: 0: Ferro bem forjado é meio caminho andado. / 1: Deve ser pesado trabalhar com tanto metal. / 0: Metal bom vira proteção boa.
  - ⚠ A fala 'Deve ser pesado trabalhar com tanto metal.' soa mais como um comentário de observador do que uma resposta direta ao ferreiro, mas ainda é plausível para um aldeão.
  - ⚠ A última fala 'Metal bom vira proteção boa.' é um fecho aceitável, porém um pouco genérico; poderia ser mais específica ao contexto da conversa.
- nota 4: 0: Cada peça de armadura conta uma história. / 1: Quem usa uma peça sua fica mais seguro. / 0: Metal bom vira proteção boa.
  - ⚠ A fala 'Metal bom vira proteção boa.' soa um pouco genérica e não fecha a conversa de forma natural, parecendo um provérbio solto.
- nota 4: 0: A armadura sai melhor com o fogo forte. / 1: O barulho da forja é música. / 0: Metal bom vira proteção boa.
  - ⚠ A fala 1 'O barulho da forja é música' é um pouco poética demais para um aldeão, mas ainda passável
  - ⚠ O fecho 'Metal bom vira proteção boa' é genérico e não responde diretamente à fala 1, enfraquecendo o encadeamento
- nota 4: 0: A armadura sai melhor com o fogo forte. / 1: Deve ser pesado trabalhar com tanto metal. / 0: Metal bom vira proteção boa.
  - ⚠ A fala 'A armadura sai melhor com o fogo forte.' soa um pouco técnica demais para um aldeão comum, mas é aceitável para um armeiro.
  - ⚠ A resposta 'Deve ser pesado trabalhar com tanto metal.' é um pouco genérica e não se conecta diretamente com a fala anterior sobre fogo forte.

### bicho_abelha (4.12)  _dois animais da fazenda; é de dia; o céu está limpo_
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: Elas só querem as flores. / 0: Melhor deixar elas em paz.
  - ⚠ A fala 'Elas só querem as flores.' soa um pouco seca e não desenvolve a conversa, mas ainda é plausível para animais da fazenda.
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: O zumbido até acalma. / 0: Que continuem trabalhando.
  - ⚠ A fala 'Que continuem trabalhando' soa um pouco formal para animais da fazenda, mas é aceitável.
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: O zumbido até acalma. / 0: Melhor deixar elas em paz.
  - ⚠ Fala 0: 'O zumbido das abelhas me faz companhia.' - 'companhia' é um conceito um pouco abstrato para animais de fazenda, mas aceitável.
  - ⚠ Fala 1: 'O zumbido até acalma.' - 'acalma' pode ser estranho para um animal, mas não quebra a imersão.
- nota 4: 0: O zumbido das abelhas me faz companhia. / 1: Elas só querem as flores. / 0: Que continuem trabalhando.
  - ⚠ Fala 1 'Elas só querem as flores.' soa levemente desdenhosa, mas ainda plausível para um animal de fazenda.
  - ⚠ Fala 0 'Que continuem trabalhando.' é um pouco formal para uma conversa casual entre animais.
- nota 4: 0: Tem uma abelha zumbindo perto de mim. / 1: O zumbido até acalma. / 0: Melhor deixar elas em paz.
  - ⚠ 'O zumbido até acalma' é um pouco reflexivo demais para um animal, mas ainda passável

### bicho_agua (4.12)  _dois animais da fazenda; é de dia_
- nota 4: 0: Beber água limpa é um prazer. / 1: Água boa é metade do dia bom. / 0: Depois a gente vai juntos.
  - ⚠ Fala 0 'Depois a gente vai juntos' é vaga e não fecha claramente a conversa sobre água.
- nota 4: 0: Beber água limpa é um prazer. / 1: Eu vou beber depois. / 0: Que a água nunca falte.
  - ⚠ A fala 'Beber água limpa é um prazer.' soa um pouco filosófica para animais de fazenda, mas é aceitável.
  - ⚠ A resposta 'Eu vou beber depois.' é curta e natural, mas poderia ser mais específica para a situação.
- nota 4: 0: Beber água limpa é um prazer. / 1: Eu vou beber depois. / 0: Depois a gente vai juntos.
  - ⚠ A fala 'Beber água limpa é um prazer.' soa um pouco filosófica para animais de fazenda, mas é aceitável.
  - ⚠ A resposta 'Eu vou beber depois.' é curta e natural, mas não desenvolve muito a conversa.
- nota 4: 0: A sede aperta quando o sol esquenta. / 1: Sede passa rápido com água fresca. / 0: Depois a gente vai juntos.
  - ⚠ Fala 0: 'A sede aperta quando o sol esquenta.' soa um pouco poética para animais de fazenda, mas ainda plausível.
  - ⚠ Fala 1: 'Sede passa rápido com água fresca.' é uma resposta genérica que não avança muito a conversa.

### bicho_armadura (4.12)  _dois animais da fazenda; o jogador veste armadura_
- nota 4: 0: O que será aquilo que o humano está vestindo? / 1: Deve fazer barulho para andar. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Deve fazer barulho para andar.' é uma suposição que não se conecta diretamente com a pergunta sobre o que é a armadura, mas ainda é plausível para um animal curioso.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' é um fecho razoável, mas poderia ser mais natural se referisse ao barulho ou à proteção.
- nota 4: 0: O humano está todo coberto de metal. / 1: Eu não vestiria isso. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Eu não vestiria isso.' é um pouco vaga e não especifica por que o animal não vestiria, mas ainda é plausível.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' é uma conclusão razoável, mas poderia ser mais conectada à resposta anterior.
- nota 4: 0: O humano está todo coberto de metal. / 1: Será que protege de lobo? / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Será que protege de lobo?' soa um pouco específica demais para um animal de fazenda, mas ainda plausível.
- nota 4: 0: O que será aquilo que o humano está vestindo? / 1: Será que protege de lobo? / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Será que protege de lobo?' soa um pouco estranha, pois lobos não são uma ameaça típica para animais de fazenda; seria mais natural citar um predador comum como raposa ou zumbi.
- nota 4: 0: O humano veste uma armadura de ferro. Brilha até de longe. / 1: Deve fazer barulho para andar. / 0: Pelo visto ele sabe se cuidar.
  - ⚠ A fala 'Pelo visto ele sabe se cuidar.' soa um pouco reflexiva demais para um animal de fazenda, mas ainda é aceitável.

### bicho_barulho (4.12)  _dois animais da fazenda; é noite_
- nota 4: 0: Ouviu aquele barulho lá longe? / 1: Deve ser o vento. / 0: Se vier, a gente foge junto.
  - ⚠ A fala 'Se vier, a gente foge junto.' é um pouco vaga sobre o que 'vier', mas ainda faz sentido no contexto de medo noturno.
- nota 4: 0: Escutei uns passos no escuro. / 1: Deve ser o vento. / 0: Vou ficar de olho.
  - ⚠ Fala 1 'Deve ser o vento' é genérica e não reflete uma criatura específica da fazenda, mas é aceitável para animais.
- nota 4: 0: Escutei uns passos no escuro. / 1: Deve ser o vento. / 0: Se vier, a gente foge junto.
  - ⚠ Fala 0 'Se vier, a gente foge junto.' é um pouco vaga sobre o que 'vier' se refere, mas ainda compreensível no contexto.
- nota 4: 0: Tem alguma coisa se mexendo ali. / 1: Deve ser o vento. / 0: Vou ficar de olho.
  - ⚠ Fala 0 'Tem alguma coisa se mexendo ali.' é genérica e não específica de animais da fazenda, mas aceitável.
  - ⚠ Fala 1 'Deve ser o vento.' é plausível, mas poderia ser mais característica de um animal específico.

### bicho_barulho_estranho (4.12)  _dois animais da fazenda; é noite_
- nota 4: 0: Ouvi um gemido estranho lá longe. / 1: Parece coisa de zumbi. / 0: Eu fico atento.
  - ⚠ A fala 'Parece coisa de zumbi.' soa um pouco específica demais para animais de fazenda, mas é aceitável no contexto do jogo.
- nota 4: 0: Escutei alguma coisa arrastando os pés. / 1: Eu me encolho quando ouço isso. / 0: Eu fico atento.
  - ⚠ Fala 1 'Eu me encolho quando ouço isso' é um pouco vaga e não especifica o que a criatura faz, mas ainda é plausível para um animal assustado.
- nota 4: 0: Ouvi um gemido estranho lá longe. / 1: Melhor ficar longe da cerca. / 0: Eu fico atento.
  - ⚠ Fala 1: 'Melhor ficar longe da cerca.' não especifica por que a cerca é perigosa, mas é plausível para animais de fazenda à noite.
  - ⚠ Fala 0 (fecho): 'Eu fico atento.' é um pouco vago, mas aceitável como encerramento.
- nota 4: 0: Tem algo gemendo no escuro. / 1: Parece coisa de zumbi. / 0: Eu fico atento.
  - ⚠ 'Eu fico atento' soa um pouco vago como fecho, mas funciona
- nota 4: 0: Escutei alguma coisa arrastando os pés. / 1: Parece coisa de zumbi. / 0: Eu fico atento.
  - ⚠ Fala 0 'Eu fico atento' é um fecho um pouco vago, mas aceitável para animais da fazenda.

### bicho_item (4.12)  _dois animais da fazenda; o jogador segura um item; NÃO: quem abre GOSTA do que o jogador segura_
- nota 4: 0: O humano está com trigo. Não é de comer, né? / 1: Não parece comida. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Cada um com o seu gosto.' soa um pouco filosófica para animais de fazenda, mas ainda é aceitável.
- nota 4: 0: Olha só, trigo na mão de o humano. O que será isso? / 1: Eu prefiro capim. / 0: Por mim, pode ficar com ele.
  - ⚠ A fala 'Olha só, trigo na mão de o humano. O que será isso?' soa um pouco artificial com 'de o humano' em vez de 'do humano'.
  - ⚠ A resposta 'Eu prefiro capim.' é plausível para um animal de fazenda, mas não se conecta diretamente com a pergunta sobre o que o humano fará com o trigo.
- nota 4: 0: O humano está com trigo. Não é de comer, né? / 1: Isso não me interessa. / 0: Cada um com o seu gosto.
  - ⚠ A fala 'Isso não me interessa.' soa um pouco seca e poderia ser mais natural para um animal de fazenda, mas ainda é aceitável.
- nota 4: 0: Aquela pessoa carrega trigo. Cheiro estranho. / 1: Gente carrega cada coisa esquisita. / 0: Cada um com o seu gosto.
  - ⚠ Fala 0: 'Cheiro estranho' é vago e não combina com trigo, que é alimento comum para animais de fazenda.
  - ⚠ Fala 1: 'Gente carrega cada coisa esquisita' soa genérico e não reflete a perspectiva de um animal de fazenda sobre trigo.
- nota 3: 0: O humano está com trigo. Não é de comer, né? / 1: Isso não me interessa. / 0: Por mim, pode ficar com ele.
  - ⚠ A fala 1 'Isso não me interessa' é seca e quebra o tom de bicho curioso da abertura
  - ⚠ A fala 0 'Não é de comer, né?' contradiz a premissa de que quem abre GOSTA do item, soando confusa

### bicho_noite_lua (4.12)  _dois animais da fazenda; é noite; o céu está limpo_
- nota 4: 0: A noite está clara. / 1: Fica mais fácil de enxergar o perigo. / 0: Fica por perto.
  - ⚠ Fala 1: 'Fica mais fácil de enxergar o perigo.' soa um pouco genérica para animais da fazenda, mas ainda plausível.
  - ⚠ Fala 0 (fecho): 'Fica por perto.' é um pouco vago, mas aceitável como conselho entre animais.
- nota 4: 0: A lua está grande hoje. / 1: A luz da lua acalma. / 0: Fica por perto.
  - ⚠ A fala 'Fica por perto.' é um pouco vaga e não fecha claramente a conversa sobre a lua.
- nota 4: 0: Dá para ver tudo com essa luz. / 1: Fica mais fácil de enxergar o perigo. / 0: Que a noite passe tranquila.
  - ⚠ Fala 0 'Dá para ver tudo com essa luz.' é um pouco vaga, mas aceitável para animais noturnos.
  - ⚠ Fala 1 'Fica mais fácil de enxergar o perigo.' soa levemente genérica, mas plausível.
- nota 4: 0: Dá para ver tudo com essa luz. / 1: Eu gosto do silêncio da noite. / 0: Fica por perto.
  - ⚠ A fala 'Dá para ver tudo com essa luz.' é um pouco vaga, pois não especifica a fonte de luz (lua, estrelas), mas ainda faz sentido para animais noturnos.
  - ⚠ A fala 'Fica por perto.' pode soar um pouco abrupta como fecho, mas é aceitável para animais de fazenda que buscam companhia.
- nota 4: 0: Dá para ver tudo com essa luz. / 1: A luz da lua acalma. / 0: Fica por perto.
  - ⚠ A fala 'Fica por perto.' não fecha claramente a conversa, soa como um pedido solto.

### chuva (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está chovendo_
- nota 4: 0: Quando chove assim, dá vontade de ficar sem se mexer. / 1: É, o céu está bem carregado. / 0: Verdade. Vamos ver quanto tempo dura.
  - ⚠ A fala 'Quando chove assim, dá vontade de ficar sem se mexer.' é um pouco filosófica para criaturas simples como animais de fazenda ou aldeões, que normalmente não expressam sentimentos abstratos.
- nota 4: 0: Chuva boa essa, vai regar tudo. / 1: É, o céu está bem carregado. / 0: Bom, fazer o quê.
  - ⚠ A fala 'Bom, fazer o quê.' soa um pouco vaga e não fecha a conversa de forma natural, podendo ser mais específica para a situação de chuva.
- nota 3: 0: Olha só, começou a chover. / 1: Também acho. / 0: Que dure só o suficiente.
  - ⚠ A resposta 'Também acho' não combina com a fala anterior, que é uma observação sobre a chuva, não uma opinião
  - ⚠ O fecho 'Que dure só o suficiente' é vago e não fecha bem a conversa iniciada
- nota 3: 0: Olha só, começou a chover. / 1: Nem me fale. / 0: Verdade. Vamos ver quanto tempo dura.
  - ⚠ Fala 1 'Nem me fale.' soa deslocada para criaturas calmas em chuva, sem contexto de incômodo.
  - ⚠ Fala 0 final 'Verdade. Vamos ver quanto tempo dura.' é vaga e não fecha a conversa de forma natural.

### clerigo (4.12)  _villager:cleric e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dizem que meu laboratório cheira estranho. / 1: Se alguém adoecer, você dá um jeito. / 0: No fim, sempre funciona.
  - ⚠ 'laboratório' soa um pouco moderno para um aldeão cleric, mas é passável
  - ⚠ o fecho 'No fim, sempre funciona' é vago e não fecha bem a conversa iniciada sobre o cheiro
- nota 4: 0: Dizem que meu laboratório cheira estranho. / 1: Eu prefiro não provar nada daí. / 0: No fim, sempre funciona.
  - ⚠ 'meu laboratório' soa um pouco moderno demais para um aldeão cleric, que normalmente fala de altar ou poções
  - ⚠ o fecho 'No fim, sempre funciona' não responde bem ao 'prefiro não provar', muda de assunto abruptamente
- nota 4: 0: As poções de hoje ficaram boas. / 1: Se alguém adoecer, você dá um jeito. / 0: No fim, sempre funciona.
  - ⚠ A fala 'Se alguém adoecer, você dá um jeito.' soa um pouco vaga e não responde diretamente à qualidade das poções, mas é aceitável para aldeões.
  - ⚠ A fala 'No fim, sempre funciona.' é um fecho um pouco genérico, mas plausível.
- nota 4: 0: As poções de hoje ficaram boas. / 1: Cheira mesmo, mas a gente se acostuma. / 0: No fim, sempre funciona.
  - ⚠ A fala 'Cheira mesmo, mas a gente se acostuma.' soa um pouco vaga, pois não especifica o que cheira, mas é aceitável no contexto de poções.
- nota 4: 0: As poções de hoje ficaram boas. / 1: Cheira mesmo, mas a gente se acostuma. / 0: Poção boa não precisa de cheiro bom.
  - ⚠ A fala 'Cheira mesmo, mas a gente se acostuma.' soa um pouco estranha para um aldeão, pois aldeões não costumam comentar sobre cheiro de poções de forma tão casual.
  - ⚠ A fala 'Poção boa não precisa de cheiro bom.' é um pouco filosófica demais para um aldeão clérigo, que normalmente fala de forma mais prática.

### curiosidade_fundo (4.12)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: O que será que tem lá embaixo, nas cavernas? / 1: Prefiro o lado de cima. / 0: Melhor deixar o fundo em paz.
  - ⚠ A fala 'Prefiro o lado de cima.' é um pouco vaga, mas aceitável para um aldeão.
  - ⚠ A conversa é curta e não desenvolve muito, mas fecha de forma coerente.
- nota 4: 0: O que será que tem lá embaixo, nas cavernas? / 1: Prefiro o lado de cima. / 0: Que ninguém desça sem tocha.
  - ⚠ A fala 1 'Prefiro o lado de cima' é um pouco vaga como resposta à pergunta sobre cavernas, mas funciona
- nota 4: 0: Já ouviu os sons que vêm do chão à noite? / 1: Quem desce muito nunca mais volta o mesmo. / 0: Melhor deixar o fundo em paz.
  - ⚠ A fala 'Quem desce muito nunca mais volta o mesmo.' é um pouco vaga e filosófica para um aldeão comum, mas ainda aceitável.
- nota 4: 0: Dizem que tem brilho de diamante bem fundo. / 1: Escuridão e coisa ruim, dizem. / 0: Que ninguém desça sem tocha.
  - ⚠ A fala 'Escuridão e coisa ruim, dizem.' é um pouco vaga, mas aceitável para aldeões.
  - ⚠ A conversa parece um aviso sobre mineração, o que é plausível para aldeões, mas poderia ser mais natural.
- nota 3: 0: Dizem que tem brilho de diamante bem fundo. / 1: Também acho. / 0: Melhor deixar o fundo em paz.
  - ⚠ Fala 0: 'Dizem que tem brilho de diamante bem fundo.' soa vaga e sem contexto para uma conversa cotidiana de aldeões.
  - ⚠ Fala 1: 'Também acho.' não responde diretamente ao que foi dito, pois a primeira fala não expressa opinião, apenas relata um boato.

### curiosidade_portal (4.12)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: Falaram de uma ilha lá no Fim. / 1: Também acho. / 0: Vai saber o que é verdade.
  - ⚠ A fala 'Também acho.' não responde diretamente à primeira fala, que é uma afirmação sobre uma ilha no Fim, não uma opinião.
  - ⚠ A fala 'Vai saber o que é verdade.' parece desconectada, pois não há contexto sobre dúvida ou veracidade na conversa.
- nota 4: 0: Falaram de uma ilha lá no Fim. / 1: Nem me fale. / 0: Vai saber o que é verdade.
  - ⚠ A fala 'Nem me fale.' é um pouco vaga, mas aceitável como resposta de desinteresse.
  - ⚠ A fala 'Vai saber o que é verdade.' fecha a conversa de forma um pouco abrupta, mas plausível.
- nota 3: 0: Falaram de uma ilha lá no Fim. / 1: É verdade. / 0: Vai saber o que é verdade.
  - ⚠ A fala 1 'É verdade.' é vaga e não responde de fato ao boato sobre a ilha no Fim
  - ⚠ O fecho 'Vai saber o que é verdade.' é filosofante demais para um aldeão e não fecha bem a conversa
- nota 4: 0: Já viu um portal roxo? / 1: Prefiro nem chegar perto. / 0: Vai saber o que é verdade.
  - ⚠ A fala 'Vai saber o que é verdade.' soa um pouco vaga e não fecha claramente a conversa sobre o portal roxo.

### enderman_olhar (4.12)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Não olhe nos olhos. Ele nos vê. / 1: Eu também odeio a chuva. / 0: Vamos para outro lugar.
  - ⚠ A fala 'Eu também odeio a chuva.' não responde diretamente à fala anterior 'Não olhe nos olhos. Ele nos vê.', mas é plausível como uma associação de desconfortos.
  - ⚠ A fala 'Vamos para outro lugar.' fecha a conversa de forma um pouco abrupta, mas é aceitável.
- nota 4: 0: A água. Mantenha-se longe da água. / 1: Eu sinto o olhar dele. / 0: Melhor sumir antes que ele olhe.
  - ⚠ Fala 1 'Eu sinto o olhar dele' é ambígua: 'dele' pode se referir ao humano ou ao outro enderman, mas no contexto de endermen, 'olhar' geralmente se refere ao jogador, o que faz sentido.
  - ⚠ Fala 0 final 'Melhor sumir antes que ele olhe' repete a ideia de evitar o olhar, mas não fecha claramente a conversa; poderia ser mais conclusiva.
- nota 4: 0: Mais um humano. Que fique longe dos meus blocos. / 1: Eu também odeio a chuva. / 0: Melhor sumir antes que ele olhe.
  - ⚠ A fala 'Eu também odeio a chuva.' não responde diretamente à fala anterior sobre humanos e blocos, mas ainda é plausível para endermen.
  - ⚠ A fala 'Melhor sumir antes que ele olhe.' fecha a conversa de forma coerente, mas a transição da chuva para o humano é um pouco abrupta.
- nota 4: 0: A água. Mantenha-se longe da água. / 1: Eu também odeio a chuva. / 0: Vamos para outro lugar.
  - ⚠ A resposta 'Eu também odeia a chuva' desvia do aviso sobre água; endermans temem água, não exatamente chuva, mas é passável
- nota 2: 0: Não olhe nos olhos. Ele nos vê. / 1: Eu também odeio a chuva. / 0: Melhor sumir antes que ele olhe.
  - ⚠ A resposta 'Eu também odeio a chuva' não combina com o que foi dito sobre olhar nos olhos
  - ⚠ O fecho 'Melhor sumir antes que ele olhe' ignora a fala sobre a chuva, conversa desconexa

### esqueleto_flechas (4.12)  _um esqueleto e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Cada flecha que erra é uma vergonha. / 1: Pega algumas do chão. / 0: Vou acertar da próxima.
  - ⚠ A fala 'Pega algumas do chão.' é um pouco vaga e não responde diretamente à vergonha expressa, mas ainda faz sentido como conselho prático.
- nota 4: 0: Uma boa flecha precisa de pena e osso. / 1: Eu nunca erro duas vezes. / 0: Mais uma tentativa.
  - ⚠ A fala 'Eu nunca erro duas vezes' soa como um clichê de filme, não como algo que um esqueleto diria naturalmente.
  - ⚠ O fecho 'Mais uma tentativa' é vago e não encerra claramente a conversa.
- nota 3: 0: Uma boa flecha precisa de pena e osso. / 1: Eu nunca erro duas vezes. / 0: Vou acertar da próxima.
  - ⚠ A fala 1 'Eu nunca erro duas vezes' não responde à fala 0 sobre flecha precisar de pena e osso
  - ⚠ A fala 0 de fecho 'Vou acertar da próxima' não fecha a conversa, parece aleatória em relação ao início
- nota 4: 0: Minhas flechas acabam rápido. / 1: Eu nunca erro duas vezes. / 0: Vou acertar da próxima.
  - ⚠ A fala 'Eu nunca erro duas vezes' soa mais como um bordão de herói do que algo que um esqueleto diria, mas ainda é aceitável.
  - ⚠ A resposta 'Vou acertar da próxima' não fecha totalmente a conversa, pois deixa em aberto se a próxima flecha será certeira ou não.
- nota 4: 0: Minhas flechas acabam rápido. / 1: Eu nunca erro duas vezes. / 0: Mais uma tentativa.
  - ⚠ A resposta 'Eu nunca erro duas vezes' não responde bem à queixa sobre flechas acabarem rápido
  - ⚠ O fecho 'Mais uma tentativa' é um pouco solto e não amarra a conversa

### jogador_nome_conta (4.12)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre sabe o nome do jogador_
- nota 4: 0: O nome desse humano é Bia, ele me contou. / 1: Bia? Não sabia, vou guardar. / 0: Nome ajuda a lembrar de quem é.
  - ⚠ 'ele me contou' soa estranho para uma criatura que talvez não converse com humanos, mas é aceitável no mundo do jogo
  - ⚠ o fecho 'Nome ajuda a lembrar de quem é' é um pouco reflexivo demais para um animal, embora caiba para aldeão
- nota 4: 0: Sabe o nome daquele humano? É Bia. / 1: Agora posso chamar pelo nome. / 0: Quando ele voltar, eu chamo pelo nome.
  - ⚠ Fala 1: 'Agora posso chamar pelo nome' soa um pouco vago; poderia ser mais natural como 'Agora posso chamá-lo pelo nome'.
  - ⚠ Fala 0 (fecho): 'Quando ele voltar, eu chamo pelo nome' repete 'pelo nome' de forma levemente redundante.
- nota 4: 0: Sabe o nome daquele humano? É Bia. / 1: Então é Bia. Obrigado por contar. / 0: Quando ele voltar, eu chamo pelo nome.
  - ⚠ Fala 0: 'Quando ele voltar, eu chamo pelo nome.' usa 'ele' para se referir a Bia, mas o nome é feminino; deveria ser 'ela'.
- nota 4: 0: Aquele humano me disse que se chama Bia. / 1: Então é Bia. Obrigado por contar. / 0: Nome ajuda a lembrar de quem é.
  - ⚠ A fala 'Nome ajuda a lembrar de quem é.' soa um pouco artificial para criaturas calmas, mas é aceitável.
- nota 4: 0: O nome desse humano é Bia, ele me contou. / 1: Então é Bia. Obrigado por contar. / 0: Nome ajuda a lembrar de quem é.
  - ⚠ Fala 0: 'ele me contou' soa estranho para criaturas calmas como aldeões ou animais, que normalmente não têm conversas tão diretas com humanos.
  - ⚠ Fala 1: 'Obrigado por contar' é um pouco formal demais para uma conversa casual entre criaturas da mesma espécie.

### medo_lobo (4.12)  _dois animais da fazenda; é noite_
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Lobo não gosta de rebanho junto. / 0: Se vier, a gente corre.
  - ⚠ A fala 'Lobo não gosta de rebanho junto.' é um pouco vaga e não responde diretamente à pergunta sobre ter ouvido um uivo.
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Chega pertinho de mim, que é mais seguro. / 0: Vamos ficar de olho.
  - ⚠ A fala 'Chega pertinho de mim, que é mais seguro.' soa um pouco estranha para animais de fazenda, que normalmente não se aproximam por segurança, mas é aceitável.
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Chega pertinho de mim, que é mais seguro. / 0: Se vier, a gente corre.
  - ⚠ A fala 'Chega pertinho de mim, que é mais seguro.' soa um pouco estranha para animais de fazenda, pois não é típico que busquem segurança em proximidade física, mas é aceitável.
- nota 4: 0: Escutei um rosnado lá longe. / 1: Lobo não gosta de rebanho junto. / 0: Se vier, a gente corre.
  - ⚠ A fala 'Lobo não gosta de rebanho junto.' soa um pouco genérica, mas é plausível para animais de fazenda.
- nota 4: 0: Já ouviu um uivo de lobo por perto? / 1: Me arrepio só de lembrar. / 0: Se vier, a gente corre.
  - ⚠ Fala 0: 'Se vier, a gente corre.' é um fecho fraco, pois não responde diretamente ao medo expresso na fala 1 e soa genérico.

### zumbi_jogador (4.12)  _um zumbi e outra criatura da mesma espécie; o jogador segura um item_
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Tira dele... tira... / 0: Grrr...
  - ⚠ A fala 'Tira dele... tira...' é um pouco vaga, mas aceitável para zumbis.
  - ⚠ O fecho 'Grrr...' é curto e fecha bem, mas poderia ser mais reativo à fala anterior.
- nota 4: 0: Aquele humano tem uma espada de ferro. Grrr. / 1: Tira dele... tira... / 0: Grrr...
  - ⚠ O fecho 'Grrr...' é genérico e não fecha de fato a conversa, mas é aceitável para zumbis
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Não importa. Carne. / 0: Grrr...
  - ⚠ A fala 'Não importa. Carne.' é um pouco vaga, mas condiz com a obsessão de zumbis por carne.
  - ⚠ O fecho 'Grrr...' é curto e natural, mas poderia ser mais reativo à resposta.
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Cuidado... pode doer. / 0: Grrr...
  - ⚠ A fala 'Cuidado... pode doer.' é um pouco vaga e não parece uma resposta natural de um zumbi, que normalmente seria mais agressivo ou instintivo.
  - ⚠ O fecho 'Grrr...' é aceitável, mas poderia ser mais conectado à conversa, como um rosnado de concordância ou alerta.
- nota 4: 0: Uma espada de ferro... o humano segura uma espada de ferro. / 1: Cuidado... pode doer. / 0: Fome...
  - ⚠ A fala 1 'Cuidado... pode doer' soa um pouco genérica, mas ainda cabe a um zumbi
  - ⚠ O fecho 'Fome...' é temático, porém não fecha bem a conversa iniciada sobre a espada

### zumbi_porta (4.12)  _um zumbi e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Grrr... bater na porta cansa. / 1: Grrr... paciência abre qualquer madeira. / 0: Grrr...
  - ⚠ 'paciência abre qualquer madeira' é abstrato demais para um zumbi, que não filosofa
  - ⚠ o fecho 'Grrr...' não fecha a conversa, só repete o som
- nota 4: 0: Grrr... aquela porta de madeira é dura. / 1: Grrr... paciência abre qualquer madeira. / 0: Grrr... insiste.
  - ⚠ A fala 'paciência abre qualquer madeira' soa filosófica demais para um zumbi, que normalmente não expressa conceitos abstratos como paciência.
- nota 3: 0: Grrr... aquela porta de madeira é dura. / 1: Grrr... o cheiro de carne vem de dentro. / 0: Grrr... insiste.
  - ⚠ O fecho 'Grrr... insiste.' é vago e não fecha bem a conversa
  - ⚠ A fala 1 ('o cheiro de carne vem de dentro') não responde diretamente à fala 0 sobre a porta ser dura
- nota 4: 0: Grrr... aquela porta de madeira é dura. / 1: Grrr... paciência abre qualquer madeira. / 0: Grrr...
  - ⚠ A fala 'paciência abre qualquer madeira' soa filosófica demais para um zumbi, que normalmente não expressa paciência ou estratégia.
- nota 4: 0: Grrr... bater na porta cansa. / 1: Grrr... o cheiro de carne vem de dentro. / 0: Grrr...
  - ⚠ O fecho 'Grrr...' é vago demais, não fecha de fato a conversa iniciada sobre bater na porta e o cheiro de carne

### bruxa_cogumelo (4.25)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Cada ingrediente tem a sua hora. / 1: Meu caldeirão está sempre fervendo. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à fala anterior sobre ingredientes, mas ainda é plausível para bruxas.
- nota 4: 0: Pântano bom é o que tem cogumelo à vontade. / 1: Meu caldeirão está sempre fervendo. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à primeira fala sobre cogumelos, mas ainda é plausível como comentário de bruxa.
  - ⚠ A fala final 'Já sei qual testar primeiro.' conecta-se vagamente, mas poderia ser mais clara sobre o que será testado.
- nota 4: 0: Pântano bom é o que tem cogumelo à vontade. / 1: Poção ruim vira lição. / 0: Já sei qual testar primeiro.
  - ⚠ A resposta 'Poção ruim vira lição' é um pouco aforística demais para uma bruxa em conversa casual, soa mais como provérbio que fala natural
- nota 4: 0: Pântano bom é o que tem cogumelo à vontade. / 1: Meu caldeirão está sempre fervendo. / 0: Hehe, a receita é segredo.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à primeira fala sobre cogumelos, mas ainda é plausível para bruxas.
  - ⚠ A fala 'Hehe, a receita é segredo.' fecha a conversa de forma um pouco abrupta, mas aceitável.
- nota 4: 0: O cogumelo de hoje deu uma poção ótima. / 1: Meu caldeirão está sempre fervendo. / 0: Já sei qual testar primeiro.
  - ⚠ A fala 'Meu caldeirão está sempre fervendo.' não responde diretamente à poção mencionada, mas ainda é plausível como comentário de bruxa.

### creeper_silencio (4.25)  _um creeper e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Ssss... eu sou só um sussurro. / 1: Ssss... o chiado é o único aviso. / 0: Ssss...
  - ⚠ A fala 0 'eu sou só um sussurro' é um pouco poética demais para um creeper, que costuma ser mais ameaçador e direto
  - ⚠ O fecho 'Ssss...' é curto demais e não fecha de fato a conversa, deixando-a sem conclusão
- nota 3: 0: Ssss... paciência antes da explosão. / 1: Ssss... quem escuta tarde, escuta demais. / 0: Ssss...
  - ⚠ A fala 'Ssss... quem escuta tarde, escuta demais.' é um provérbio humano que não combina com o mundo de um creeper.
  - ⚠ O fecho 'Ssss...' é vago e não conclui a conversa de forma satisfatória.
- nota 3: 0: Ssss... eu sou só um sussurro. / 1: Ssss... quem escuta tarde, escuta demais. / 0: Ssss...
  - ⚠ A fala 'quem escuta tarde, escuta demais' soa como um provérbio humano, não combina com o vocabulário típico de um creeper.
  - ⚠ O fecho 'Ssss...' é muito vago e não conclui a conversa de forma clara.
- nota 4: 0: Ssss... paciência antes da explosão. / 1: Ssss... o chiado é o único aviso. / 0: Ssss...
  - ⚠ O fecho 'Ssss...' é só um som, não fecha de fato a conversa, mas é aceitável para creeper

### flecheiro (4.25)  _villager:fletcher e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Fiz flechas novas esta manhã. / 1: Precisão é uma virtude. / 0: Mira firme e coração calmo.
  - ⚠ 'Precisão é uma virtude' soa um pouco aforístico demais para um aldeão comum, mas passável
- nota 4: 0: Pena de galinha faz flecha voar reto. / 1: Precisão é uma virtude. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Precisão é uma virtude' soa filosófica demais para um aldeão comum, que normalmente fala de forma mais simples e prática.
  - ⚠ O fecho 'Cada flecha tem seu destino' é um pouco abstrato para o contexto, mas ainda aceitável.
- nota 4: 0: Pena de galinha faz flecha voar reto. / 1: Precisão é uma virtude. / 0: Mira firme e coração calmo.
  - ⚠ 'Precisão é uma virtude' soa um pouco aforístico demais para um aldeão, mas passável
- nota 4: 0: Uma boa flecha precisa de equilíbrio. / 1: A vila fica mais segura com boas flechas. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Cada flecha tem seu destino' soa filosófica demais para um aldeão comum, que normalmente fala de forma simples e prática.
- nota 4: 0: Fiz flechas novas esta manhã. / 1: Precisão é uma virtude. / 0: Cada flecha tem seu destino.
  - ⚠ A fala 'Precisão é uma virtude' soa filosófica demais para um aldeão comum, que tende a falar de forma mais simples e prática.

### jogador_monstros_visto (4.25)  _dois monstros hostis; uma situação qualquer do dia a dia_
- nota 4: 0: Humano à vista. / 1: Silêncio, chega mais perto. / 0: Eu avisei.
  - ⚠ A fala 'Silêncio, chega mais perto.' é um pouco ambígua: pode ser interpretada como ordem para o outro monstro se aproximar, mas o contexto sugere que é sobre o humano se aproximar; falta clareza.
- nota 4: 0: Tem um humano ali. / 1: Silêncio, chega mais perto. / 0: Eu avisei.
  - ⚠ A fala 'Silêncio, chega mais perto.' é um pouco ambígua: 'chega mais perto' pode ser interpretado como ordem para o outro monstro se aproximar, mas o contexto sugere que é sobre se aproximar do humano
- nota 4: 0: Aquele humano não está nos vendo. / 1: Cuidado com o que ele carrega. / 0: Agora não. Espera o momento certo.
  - ⚠ Fala 1: 'Cuidado com o que ele carrega.' é vaga e não especifica o perigo, mas ainda faz sentido para monstros hostis.
  - ⚠ Fala 0 (fecho): 'Agora não. Espera o momento certo.' é um pouco genérica, mas plausível para uma emboscada.
- nota 4: 0: Humano à vista. / 1: Cuidado com o que ele carrega. / 0: Eu avisei.
  - ⚠ 'Eu avisei' soa um pouco desconectado — o outro monstro não ignorou o aviso, então o fecho não fecha bem a troca
- nota 4: 0: Aquele humano não está nos vendo. / 1: Eu chego pela esquerda. / 0: Agora não. Espera o momento certo.
  - ⚠ A fala 1 'Eu chego pela esquerda' é um pouco tática demais para um monstro genérico, mas ainda plausível em emboscada

### jogador_passando (4.25)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Vi o humano passando agora há pouco. / 1: Eu fico de olho nele. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para uma conversa curta entre criaturas, mas ainda é aceitável.
- nota 4: 0: O humano anda por aí de novo. / 1: Ele passa sempre por aqui. / 0: Vamos ver o que ele faz.
  - ⚠ A fala 'Vamos ver o que ele faz.' soa um pouco vaga e não fecha a conversa de forma conclusiva, mas é aceitável.
- nota 4: 0: Vi o humano passando agora há pouco. / 1: Eu fico de olho nele. / 0: Vamos ver o que ele faz.
  - ⚠ A fala 'Eu fico de olho nele.' é um pouco vaga e não responde diretamente ao comentário sobre o humano ter passado, mas ainda é plausível.
  - ⚠ A fala 'Vamos ver o que ele faz.' soa mais como uma sugestão de ação do que um fecho natural, mas ainda fecha a conversa de forma aceitável.
- nota 4: 0: Vi o humano passando agora há pouco. / 1: Ele passa sempre por aqui. / 0: Que siga o caminho dele.
  - ⚠ A fala 'Que siga o caminho dele.' soa um pouco formal para criaturas calmas, mas ainda aceitável.

### jogador_troca (4.25)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre já fez uma troca justa com o jogador (fato verificado)_
- nota 4: 0: O humano fez uma troca justa comigo. / 1: Isso é raro hoje em dia. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' não responde diretamente à fala anterior 'Isso é raro hoje em dia.' e parece desconectada.
- nota 3: 0: Negociei com o humano outro dia, correu tudo bem. / 1: Isso é raro hoje em dia. / 0: Dá para confiar.
  - ⚠ 'Negociei com o humano' soa formal demais para um aldeão/animal calmo; 'troquei' seria mais natural
  - ⚠ 'Isso é raro hoje em dia' é genérico e não reage concretamente à troca justa mencionada
- nota 4: 0: Negociei com o humano outro dia, correu tudo bem. / 1: Paga direito? / 0: Paga, sim.
  - ⚠ 'Paga direito?' soa um pouco seco/curto demais como resposta, mas é natural em fala
- nota 4: 0: O humano fez uma troca justa comigo. / 1: Bom saber, eu também troco com quem é honesto. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' parece desconectada da conversa anterior, que era sobre trocas justas e honestidade, não sobre pagamento.
- nota 4: 0: A última troca com o humano foi tranquila. / 1: Bom saber, eu também troco com quem é honesto. / 0: Paga, sim.
  - ⚠ A fala 'Paga, sim.' parece desconectada da conversa anterior sobre trocas honestas, soando como um fecho abrupto.

### lobo (4.25)  _um lobo e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Fiquei de guarda a manhã toda. / 1: Meu nariz nunca erra. / 0: Auuu, fico de olho nos meus.
  - ⚠ A fala 'Meu nariz nunca erra.' não responde diretamente à primeira fala sobre ficar de guarda, mas ainda é plausível para lobos.
  - ⚠ A fala 'Auuu, fico de olho nos meus.' é um fecho aceitável, mas poderia ser mais conectada à resposta anterior.
- nota 4: 0: Cheirei um osso enterrado ali perto. / 1: Quem é da matilha, eu protejo. / 0: Auuu, fico de olho nos meus.
  - ⚠ A fala 'Quem é da matilha, eu protejo.' não responde diretamente à primeira fala sobre o osso, mas ainda é plausível como um comentário de lealdade.
  - ⚠ A fala 'Auuu, fico de olho nos meus.' é um fecho aceitável, mas poderia ser mais conectada ao osso ou à proteção.
- nota 4: 0: Ouvi um uivo lá longe. / 1: Quem é da matilha, eu protejo. / 0: Auuu, fico de olho nos meus.
  - ⚠ A fala 'Quem é da matilha, eu protejo.' soa um pouco formal e filosófica para um lobo em conversa casual.
  - ⚠ A resposta 'Auuu, fico de olho nos meus.' não conecta diretamente com a fala anterior sobre proteção, deixando o fecho um pouco solto.
- nota 4: 0: Cheirei um osso enterrado ali perto. / 1: Meu nariz nunca erra. / 0: Auuu, fico de olho nos meus.
  - ⚠ O fecho 'fico de olho nos meus' é um pouco vago — 'nos meus' o quê? ossos? filhotes? soa truncado
- nota 4: 0: Fiquei de guarda a manhã toda. / 1: Meu nariz nunca erra. / 0: Vamos patrulhar juntos.
  - ⚠ A resposta 'Meu nariz nunca erra' não responde diretamente ao fato de ter ficado de guarda, mas é aceitável como bravata de lobo

### monstros_ferido (4.25)  _dois monstros hostis; o jogador está ferido_
- nota 4: 0: Cheiro de sangue por perto. / 1: Eu fico por perto. / 0: Sem pressa.
  - ⚠ A fala 'Eu fico por perto.' é vaga e não responde diretamente ao cheiro de sangue, mas ainda é plausível para monstros hostis.
- nota 3: 0: O humano está ferido. / 1: Eu fico por perto. / 0: Sem pressa.
  - ⚠ Fala 1 'Eu fico por perto.' é vaga e não combina com a natureza hostil dos monstros, que normalmente atacariam um jogador ferido.
  - ⚠ Fala 0 'Sem pressa.' soa ambígua e não fecha claramente a conversa, deixando a intenção dos monstros incerta.
- nota 3: 0: O humano está ferido. / 1: Eu fico por perto. / 0: Deixa ele vir.
  - ⚠ 'Eu fico por perto' e 'Deixa ele vir' soam passivos demais para monstros hostis com jogador ferido
  - ⚠ o fecho 'Deixa ele vir' não fecha bem a conversa, parece que fica no ar
- nota 4: 0: O humano está ferido. / 1: Ele não vai longe. / 0: Deixa ele vir.
  - ⚠ A fala 'Deixa ele vir.' soa um pouco ambígua, mas ainda plausível para monstros hostis.

### pastor (4.25)  _villager:shepherd e dois aldeões; é de dia_
- nota 4: 0: Lã não falta nesta estação. / 1: Cuidar de rebanho dá trabalho. / 0: No fim, elas voltam sempre.
  - ⚠ A fala 'No fim, elas voltam sempre.' é um pouco vaga, mas aceitável para um pastor.
- nota 3: 0: Lã não falta nesta estação. / 1: Quando precisar de ajuda, chama. / 0: No fim, elas voltam sempre.
  - ⚠ A fala 'Quando precisar de ajuda, chama.' não responde diretamente à fala anterior sobre lã.
  - ⚠ A fala 'No fim, elas voltam sempre.' é vaga e não fecha claramente a conversa.
- nota 4: 0: Lã não falta nesta estação. / 1: Elas são teimosas mesmo. / 0: No fim, elas voltam sempre.
  - ⚠ A fala 'Elas são teimosas mesmo.' é um pouco vaga, mas pode se referir às ovelhas, o que faz sentido para um pastor.

### vila_pilhadores (4.33)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: Pilhador é a pior coisa que existe. / 1: O golem não deixa ninguém passar. / 0: A vila é forte quando está unida.
  - ⚠ A fala 'O golem não deixa ninguém passar.' não responde diretamente à fala anterior sobre pilhadores, parecendo desconexa.
  - ⚠ A fala final 'A vila é forte quando está unida.' soa como um clichê e não fecha naturalmente a conversa iniciada sobre pilhadores.
- nota 0: 0: Pilhador é a pior coisa que existe. / 1: Eu fecho as portas mais cedo por via das dúvidas. / 0: Melhor estar sempre preparado.
  - ⚠ avaliador falhou
- nota 0: 0: Dizem que pilhadores atacam vilas inteiras. / 1: Prefiro nem pensar nisso. / 0: Melhor estar sempre preparado.
  - ⚠ avaliador falhou
- nota 4: 0: A ideia de pilhadores me tira o sono. / 1: O golem não deixa ninguém passar. / 0: Melhor estar sempre preparado.
  - ⚠ A fala 'O golem não deixa ninguém passar' não responde diretamente à preocupação com pilhadores, mas ainda é plausível como comentário sobre segurança.

### aranha_presa (4.38)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... hoje vou tecer uma teia grande. / 1: Sss... a teia faz o serviço sozinha. / 0: Sss... quase.
  - ⚠ A fala 'a teia faz o serviço sozinha' é um pouco vaga e pode soar estranha para aranhas, que normalmente não falam de forma tão abstrata.
- nota 4: 0: Sss... hoje vou tecer uma teia grande. / 1: Sss... espere ele chegar mais perto. / 0: Sss... quase.
  - ⚠ A fala 1 ('espere ele chegar mais perto') introduz um 'ele' que não foi mencionado na abertura, quebra um pouco a coesão
  - ⚠ O fecho 'quase' é curto demais e não fecha claramente a conversa, fica ambíguo
- nota 4: 0: Sss... o que se mexe vira jantar. / 1: Sss... paciência é tudo. / 0: Sss... silêncio agora.
  - ⚠ 'paciência é tudo' soa um pouco filosófico para uma aranha, mas ainda cabe como instinto de caça
- nota 4: 0: Sss... hoje vou tecer uma teia grande. / 1: Sss... a teia faz o serviço sozinha. / 0: Sss... silêncio agora.
  - ⚠ A fala 'Sss... silêncio agora.' soa um pouco abrupta e não fecha a conversa de forma natural, pois não responde diretamente à fala anterior.
- nota 4: 0: Sss... o que se mexe vira jantar. / 1: Sss... a teia faz o serviço sozinha. / 0: Sss... quase.
  - ⚠ A fala 'Sss... quase.' é vaga e não fecha claramente a conversa, deixando o sentido ambíguo.

### aranha_teia (4.38)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Sss... as paredes são minhas. / 1: Sss... eu sinto as vibrações. / 0: Sss...
  - ⚠ O fecho 'Sss...' não fecha a conversa, é só um som solto
  - ⚠ A fala 1 'eu sinto as vibrações' não responde diretamente à afirmação de posse das paredes
- nota 4: 0: Sss... as paredes são minhas. / 1: Sss... a noite é nossa. / 0: Sss... paciência.
  - ⚠ Fala 0 'Sss... as paredes são minhas.' é um pouco vaga para uma situação qualquer do dia a dia, mas aceitável para aranhas.
  - ⚠ Fala 1 'Sss... a noite é nossa.' soa mais como um lema do que uma resposta direta à fala anterior.
- nota 4: 0: Sss... as paredes são minhas. / 1: Sss... deixa chegar mais perto. / 0: Sss...
  - ⚠ A fala 'Sss... as paredes são minhas.' é um pouco vaga para uma situação qualquer do dia a dia, mas ainda faz sentido para aranhas territoriais.
  - ⚠ A resposta 'Sss... deixa chegar mais perto.' sugere uma emboscada, o que é plausível, mas o fecho 'Sss...' é muito curto e não fecha claramente a conversa.
- nota 4: 0: Sss... tem gente quente por perto. / 1: Sss... a noite é nossa. / 0: Sss... paciência.
  - ⚠ A fala 'Sss... paciência.' não fecha claramente a conversa, soando um pouco vaga.

### bicho_hora_comer (4.38)  _dois animais da fazenda; é de dia_
- nota 4: 0: Acho que já está na hora de comer. / 1: O meu também está reclamando. / 0: Guarda um lugar para mim.
  - ⚠ Fala 1: 'O meu também está reclamando' é vaga; não fica claro que se refere ao estômago, soando um pouco estranha para animais de fazenda.
- nota 4: 0: Acho que já está na hora de comer. / 1: Hora de comer é a melhor hora. / 0: Guarda um lugar para mim.
  - ⚠ 'Guarda um lugar para mim' soa um pouco humano demais para animais que comem de cocho, mas é passável
- nota 4: 0: O estômago avisa a hora certa. / 1: Quem chega primeiro come melhor. / 0: Guarda um lugar para mim.
  - ⚠ Fala 0 'O estômago avisa a hora certa.' é um pouco filosófica para animais de fazenda, mas aceitável.
  - ⚠ Fala 1 'Quem chega primeiro come melhor.' soa competitiva, mas plausível entre animais.
- nota 4: 0: O estômago avisa a hora certa. / 1: O meu também está reclamando. / 0: Guarda um lugar para mim.
  - ⚠ Fala 0 'Guarda um lugar para mim' é um pouco vaga, mas aceitável para animais indo comer.

### bicho_jogador_conhecido (4.38)  _dois animais da fazenda; quem abre já conhece o jogador_
- nota 4: 0: O cheiro do humano me é familiar. / 1: Eu também me lembro dele. / 0: Vamos ver o que ele quer hoje.
  - ⚠ Fala 0: 'O cheiro do humano me é familiar.' soa um pouco formal para animais da fazenda, mas é aceitável.
  - ⚠ Fala 1: 'Eu também me lembro dele.' é vaga, mas funciona como resposta.
- nota 4: 0: Esse humano eu já conheço. / 1: Eu também me lembro dele. / 0: Boa gente.
  - ⚠ Fala 0 'Boa gente.' soa ambígua e pouco natural como fecho; poderia ser 'É gente boa.'
- nota 4: 0: Esse humano eu já conheço. / 1: Ele parece de boa índole. / 0: Boa gente.
  - ⚠ Fala 1 'Ele parece de boa índole' soa formal demais para animais de fazenda em conversa casual.
- nota 4: 0: Esse humano eu já conheço. / 1: Ele parece de boa índole. / 0: Vamos ver o que ele quer hoje.
  - ⚠ Fala 1: 'Ele parece de boa índole' soa formal demais para animais de fazenda em conversa casual.
- nota 4: 0: O cheiro do humano me é familiar. / 1: Ele parece de boa índole. / 0: Boa gente.
  - ⚠ 'Ele parece de boa índole' soa um pouco formal/filosófico para um animal, mas é passável

### bicho_sombra (4.38)  _dois animais da fazenda; é de dia; o céu está limpo_
- nota 3: 0: Achei uma sombra boa. / 1: Nem me fale. / 0: Fica à vontade.
  - ⚠ 'Nem me fale' não responde bem a 'Achei uma sombra boa' — soa como reclamação desconexa
  - ⚠ o fecho 'Fica à vontade' não fecha a conversa, já que a segunda criatura não pediu nada
- nota 3: 0: Tem sombra de sobra aqui. / 1: É verdade. / 0: Fica à vontade.
  - ⚠ Fala 0 'Tem sombra de sobra aqui.' é vaga e não especifica qual animal fala, mas é plausível para animais de fazenda.
  - ⚠ Fala 1 'É verdade.' é uma resposta muito genérica e não acrescenta nada à conversa.

### ceu_estrelas (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite; o céu está limpo_
- nota 4: 0: A lua está bonita hoje. / 1: Cada uma parece uma luzinha. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' não fecha claramente a conversa sobre a lua, soando um pouco desconexa.
- nota 4: 0: Dá para ver as estrelas hoje. / 1: Cada uma parece uma luzinha. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' não fecha a conversa de forma natural; parece um aviso sem contexto claro.
- nota 4: 0: A lua está bonita hoje. / 1: A noite fica menos assustadora assim. / 0: Mas fica por perto.
  - ⚠ A fala 'Mas fica por perto.' é um pouco vaga e não fecha claramente a conversa, podendo soar estranha para criaturas calmas.
- nota 3: 0: A lua está bonita hoje. / 1: Nunca vi tantas juntas. / 0: Mas fica por perto.
  - ⚠ A fala 'Nunca vi tantas juntas.' é ambígua e não se conecta claramente com a lua, parecendo referir-se a algo não mencionado.
  - ⚠ A fala 'Mas fica por perto.' soa como um aviso de perigo, mas a situação é calma e noturna, sem ameaça aparente.

### colheita (4.38)  _dois aldeões; é de dia_
- nota 4: 0: Como anda a sua plantação de trigo? / 1: Troquei um pouco com um viajante outro dia. / 0: A terra daqui é generosa.
  - ⚠ A resposta 'Troquei um pouco com um viajante outro dia' não responde diretamente à pergunta sobre a plantação de trigo, mas ainda é plausível para aldeões.
- nota 4: 0: Hoje só pensei em pão. / 1: Com cuidado assim, nunca falta comida. / 0: Se sobrar, a gente troca.
  - ⚠ A resposta 'Com cuidado assim' não retoma bem o 'pensei em pão' — soa um pouco solta como réplica
- nota 3: 0: Colhi abóbora a manhã inteira. / 1: Também acho. / 0: Se sobrar, a gente troca.
  - ⚠ 'Também acho' não responde bem a 'Colhi abóbora a manhã inteira' — falta concordância lógica
  - ⚠ O fecho 'Se sobrar, a gente troca' não fecha a conversa, parece abrir um novo assunto
- nota 4: 0: Hoje só pensei em batata. / 1: É verdade. / 0: A terra daqui é generosa.
  - ⚠ A resposta 'É verdade.' é muito vaga e não desenvolve a conversa, mas ainda é plausível para aldeões.

### creeper_gato (4.38)  _um creeper e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Ssss... aquele miado me arrepia. / 1: Ssss... eles me olham e eu me esvazio. / 0: Ssss... fica longe deles.
  - ⚠ A fala 1 'eles me olham e eu me esvazio' é um pouco confusa: 'me esvazio' não deixa claro se é medo ou o prenúncio de explosão, que seria mais natural para um creeper
- nota 3: 0: Ssss... aquele miado me arrepia. / 1: Ssss... eles me olham e eu me esvazio. / 0: Ssss...
  - ⚠ A fala 1 ('eles me olham e eu me esvazio') é confusa e não conecta bem com o miado da fala 0
  - ⚠ O fecho 'Ssss...' é só um som, não fecha a conversa de fato
- nota 4: 0: Ssss... gato é inimigo declarado. / 1: Ssss... eles me olham e eu me esvazio. / 0: Ssss...
  - ⚠ A fala 'Ssss... eles me olham e eu me esvazio.' é um pouco ambígua, mas pode ser interpretada como o medo de explodir ao ver um gato, o que faz sentido para um creeper.
  - ⚠ O fecho 'Ssss...' é muito curto e não fecha claramente a conversa, mas é aceitável para a natureza sibilante dos creepers.

### enderman_bloco (4.38)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Gosto de levar os blocos que me agradam. / 1: É só um capricho nosso. / 0: Ninguém precisa saber.
  - ⚠ A fala 'É só um capricho nosso' soa um pouco vaga e não responde diretamente à primeira fala, mas ainda é plausível para endermans.
  - ⚠ A fala 'Ninguém precisa saber' fecha a conversa de forma um pouco abrupta, mas é aceitável.
- nota 4: 0: Cada bloco que carrego é um tesouro. / 1: Ninguém entende o valor de um bloco. / 0: Cada um com o seu tesouro.
  - ⚠ A fala 'Cada bloco que carrego é um tesouro' é um pouco filosófica demais para um enderman, que normalmente emite sons curtos e não fala sobre valores.
  - ⚠ A resposta 'Ninguém entende o valor de um bloco' soa mais como um lamento humano do que algo que um enderman diria.
- nota 3: 0: Cada bloco que carrego é um tesouro. / 1: Ninguém entende o valor de um bloco. / 0: Ninguém precisa saber.
  - ⚠ Endermans não carregam blocos como 'tesouro' nem filosofam sobre valor — soa mais como ganancioso genérico
  - ⚠ A fala 1 é vaga e não responde concretamente ao 'tesouro' dito

### esqueleto_creeper (4.38)  _um esqueleto e um creeper; uma situação qualquer do dia a dia_
- nota 4: 0: Fica longe da minha flecha, hein? / 1: Ssss... eu chego perto, você mira de longe. / 0: Então vamos.
  - ⚠ O fecho 'Então vamos.' é um pouco vago e não fecha bem a tensão da ameaça inicial
  - ⚠ A resposta do creeper 'eu chego perto, você mira de longe' é meio confusa como réplica à ameaça
- nota 4: 0: Fica longe da minha flecha, hein? / 1: Ssss... eu chego perto, você mira de longe. / 0: Combinado.
  - ⚠ O fecho 'Combinado.' é um pouco seco e não reage ao 'Ssss' ameaçador do creeper, mas ainda fecha a conversa de forma aceitável
- nota 4: 0: Fica longe da minha flecha, hein? / 1: Ssss... só não me acerta. / 0: Então vamos.
  - ⚠ A fala 'Então vamos.' é vaga e não fecha claramente a conversa, deixando a interação sem um desfecho natural.
- nota 4: 0: Você explode e eu atiro. Dá um bom time. / 1: Ssss... só não me acerta. / 0: Então vamos.
  - ⚠ A fala do creeper 'Ssss... só não me acerta.' é um pouco longa para o padrão de creepers, que costumam ser mais curtos e sibilantes.

### esqueleto_sombra (4.38)  _um esqueleto e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Fico sempre perto de uma sombra. / 1: À noite a mira é melhor. / 0: Falta pouco para a minha hora.
  - ⚠ A fala 'Falta pouco para a minha hora' é ambígua e pode soar estranha para um esqueleto, que não tem um conceito claro de 'hora' além do ciclo dia/noite.
- nota 4: 0: Fico sempre perto de uma sombra. / 1: Dia é bom para ficar parado. / 0: Quando escurecer, eu atiro.
  - ⚠ A fala 'Dia é bom para ficar parado.' soa um pouco vaga, mas ainda faz sentido para esqueletos que evitam o sol.
  - ⚠ A fala 'Quando escurecer, eu atiro.' é coerente, mas poderia ser mais natural como 'Quando escurecer, eu atiro.' (repetição desnecessária).
- nota 3: 0: De dia eu me escondo. / 1: Quem se queima não acerta nada. / 0: Falta pouco para a minha hora.
  - ⚠ 'Quem se queima não acerta nada' é um provérbio confuso e não responde bem ao esconder-se de dia
  - ⚠ o fecho 'Falta pouco para a minha hora' é vago e não fecha a conversa de forma clara
- nota 4: 0: O sol arruína os meus ossos. / 1: Dia é bom para ficar parado. / 0: Quando escurecer, eu atiro.
  - ⚠ 'Dia é bom para ficar parado' é um pouco vago para um esqueleto, mas passável

### fome_bicho (4.38)  _dois animais da fazenda; é de dia_
- nota 4: 0: Já passou da hora de comer. / 1: Vou procurar uma touceira de grama. / 0: Vamos esperar mais um pouco.
  - ⚠ A fala 'Vamos esperar mais um pouco' não fecha a conversa de forma conclusiva, deixando a interação sem um desfecho claro.
- nota 4: 0: Fico de olho para ver se aparece comida. / 1: O cheiro de feno me deixa com mais fome. / 0: Quem chegar primeiro na comida, come.
  - ⚠ A fala 'O cheiro de feno me deixa com mais fome.' é um pouco estranha, pois feno é o alimento típico de animais de fazenda, então sentir fome ao cheirá-lo é plausível, mas a construção 'me deixa com m
  - ⚠ A fala 'Quem chegar primeiro na comida, come.' é um fecho aceitável, mas poderia ser mais natural, como 'Quem chegar primeiro, come.'
- nota 4: 0: Já passou da hora de comer. / 1: O cheiro de feno me deixa com mais fome. / 0: Vamos esperar mais um pouco.
  - ⚠ A fala 'O cheiro de feno me deixa com mais fome' é um pouco estranha para um animal, pois feno é o alimento e o cheiro normalmente estimularia o apetite, mas a frase sugere que o cheiro aumenta a fome
  - ⚠ A fala 'Vamos esperar mais um pouco' não fecha claramente a conversa, pois não há uma conclusão ou ação definida.

### golem_flor (4.38)  _um golem de ferro e dois aldeões; é de dia_
- nota 4: 0: Achei uma papoula perto do caminho e guardei. / 1: Isso alegra a vila toda. / 0: É o meu jeito de agradecer.
  - ⚠ 'Isso alegra a vila toda' é um pouco exagerado para uma papoula, mas aceitável no tom de aldeão
- nota 4: 0: Achei uma papoula perto do caminho e guardei. / 1: Flor combina com você, mesmo sendo de ferro. / 0: Cuidar também é isso.
  - ⚠ A fala 'Flor combina com você, mesmo sendo de ferro.' soa um pouco estranha para um aldeão, que normalmente fala de comércio ou necessidades, mas é aceitável como elogio simples.
  - ⚠ A fala 'Cuidar também é isso.' é um pouco vaga e filosófica para um golem, que tende a ser mais direto e protetor.
- nota 4: 0: Gosto de levar uma flor a quem trata bem os moradores. / 1: Isso alegra a vila toda. / 0: Cuidar também é isso.
  - ⚠ A fala 0 do golem ('Gosto de levar uma flor...') é um pouco longa e reflexiva para um golem, que costuma ser mais direto e protetor
  - ⚠ A fala 1 não deixa claro qual dos dois aldeões responde, mas isso é aceitável
- nota 4: 0: Gosto de levar uma flor a quem trata bem os moradores. / 1: Isso alegra a vila toda. / 0: É o meu jeito de agradecer.
  - ⚠ O golem fala de 'levar uma flor' como se fosse um gesto pessoal, o que é um pouco poético demais para um golem, mas aceitável no contexto do jogo
  - ⚠ A fala 1 ('Isso alegra a vila toda') é genérica e não responde diretamente ao gesto da flor, mas ainda encaixa
- nota 4: 0: Gosto de levar uma flor a quem trata bem os moradores. / 1: Flor combina com você, mesmo sendo de ferro. / 0: Cuidar também é isso.
  - ⚠ A fala 'Flor combina com você, mesmo sendo de ferro.' soa um pouco estranha para um aldeão, pois aldeões não costumam fazer elogios poéticos; mas é aceitável.
  - ⚠ A fala 'Cuidar também é isso.' é um fecho um pouco vago, mas fecha a conversa de forma razoável.

### golem_quer_flor (4.38)  _um golem de ferro e dois aldeões; o jogador segura um item; quem abre GOSTA do que o jogador segura_
- nota 3: 0: O humano está com uma papoula. Eu adoro isso. / 1: Ele nem percebeu que você está olhando. / 0: Uma flor assim alegra qualquer dia.
  - ⚠ A fala 1 ('Ele nem percebeu que você está olhando') não responde ao gosto pela papoula nem combina com o golem, que não fala de olhar/perceber
  - ⚠ O fecho 'Uma flor assim alegra qualquer dia' é genérico e não fecha a conversa iniciada, ignorando a fala 1
- nota 4: 0: O humano está com uma papoula. Eu adoro isso. / 1: Pede com educação, quem sabe ele dá. / 0: Eu cuido da vila, e ele cuida das flores.
  - ⚠ A fala 'Eu cuido da vila, e ele cuida das flores.' soa um pouco filosófica para um golem de ferro, que normalmente tem falas simples e diretas.
- nota 4: 0: O humano está com uma papoula. Eu adoro isso. / 1: Ele nem percebeu que você está olhando. / 0: Eu cuido da vila, e ele cuida das flores.
  - ⚠ A fala 'Eu cuido da vila, e ele cuida das flores.' soa um pouco filosófica para um golem de ferro, que normalmente tem falas simples e protetoras.
- nota 4: 0: O humano está com uma papoula. Eu adoro isso. / 1: Pede com educação, quem sabe ele dá. / 0: Uma flor assim alegra qualquer dia.
  - ⚠ O golem de ferro fala de 'adorar' uma papoula e de alegrar o dia — um pouco sentimental demais para um golem, que costuma ser protetor e direto
  - ⚠ A fala 1 ('Pede com educação, quem sabe ele dá') é de aldeão, mas o 'quem' inclui golem e dois aldeões; a atribuição fica ambígua, já que o golem não pediria flores

### jogador_ferido (4.38)  _dois aldeões; o jogador está ferido_
- nota 4: 0: Olha o estado de o humano, que pena. / 1: Alguém devia oferecer ajuda a ele. / 0: Que se recupere logo.
  - ⚠ A fala 'Que se recupere logo.' soa como um desejo, mas não fecha a conversa de forma natural, pois não responde diretamente à sugestão de oferecer ajuda.
- nota 4: 0: Olha o estado de o humano, que pena. / 1: Uma boa refeição ajuda a se curar. / 0: Tomara que passe depressa.
  - ⚠ 'Olha o estado de o humano' soa truncado; melhor 'Olha o estado do humano'
- nota 4: 0: O humano parece ferido. / 1: Alguém devia oferecer ajuda a ele. / 0: Que se recupere logo.
  - ⚠ A fala 'Alguém devia oferecer ajuda a ele.' soa um pouco passiva para um aldeão, que normalmente ofereceria ajuda diretamente ou comentaria sobre o jogador, mas ainda é plausível.
  - ⚠ O fecho 'Que se recupere logo.' é um pouco abrupto, mas aceitável como encerramento.

### jogador_honesto (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já devolveu a quem abre algo que ele tinha entregado, sem ser pedido (fato verificado)_
- nota 4: 0: O humano me devolveu o que eu tinha entregado, sem eu pedir. / 1: Isso é raro, essa pessoa é honesta. / 0: Fez toda a diferença para mim.
  - ⚠ 'Fez toda a diferença para mim' soa um pouco abstrato/reflexivo demais para um aldeão ou animal simples; algo como 'Isso me ajudou muito' seria mais natural
- nota 4: 0: O humano me devolveu o que eu tinha entregado, sem eu pedir. / 1: Então vale a confiança. / 0: Pois é, eu confio.
  - ⚠ 'Então vale a confiança' soa um pouco abstrato para um aldeão/animal, mas é passável como fala curta de criatura calma
- nota 4: 0: Teve uma vez que o humano me devolveu algo, sem ninguém pedir. / 1: Então vale a confiança. / 0: Pois é, eu confio.
  - ⚠ A fala 'Então vale a confiança.' é um pouco vaga e não responde diretamente ao relato da devolução; poderia ser mais específica, como 'Então ele é de confiança.'
  - ⚠ O fecho 'Pois é, eu confio.' é redundante após a resposta, mas ainda fecha a conversa de forma aceitável.
- nota 4: 0: O humano me devolveu o que eu tinha entregado, sem eu pedir. / 1: Então vale a confiança. / 0: Fez toda a diferença para mim.
  - ⚠ A fala 'Então vale a confiança.' é um pouco vaga e não se conecta claramente com a devolução mencionada.
  - ⚠ A fala 'Fez toda a diferença para mim.' soa um pouco formal para uma conversa curta entre criaturas calmas.
- nota 4: 0: Teve uma vez que o humano me devolveu algo, sem ninguém pedir. / 1: Isso é raro, essa pessoa é honesta. / 0: Pois é, eu confio.
  - ⚠ A fala 'Isso é raro, essa pessoa é honesta.' soa um pouco genérica e poderia ser mais específica ao mundo da criatura, mas ainda é aceitável.

### noite (4.38)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite_
- nota 4: 0: Já ouvi uns rosnados lá longe. / 1: Se ouvir um chiado, corre. / 0: Aguenta firme, o dia já vem.
  - ⚠ A fala 'Se ouvir um chiado, corre.' é um aviso sobre Creeper, mas não fica claro se as criaturas são aldeões ou animais; para animais, 'chiado' pode não fazer sentido.
  - ⚠ A fala 'Aguenta firme, o dia já vem.' soa um pouco filosófica para criaturas simples, mas é aceitável.
- nota 4: 0: Quem está de pé a essa hora? / 1: Fica por perto, é mais seguro. / 0: Aguenta firme, o dia já vem.
  - ⚠ A fala 'Aguenta firme, o dia já vem.' soa um pouco filosófica demais para criaturas simples como animais de fazenda ou aldeões, mas ainda é aceitável.
- nota 4: 0: Quem está de pé a essa hora? / 1: De noite o mundo fica estranho. / 0: Qualquer barulho eu aviso.
  - ⚠ A fala 'Qualquer barulho eu aviso.' não fecha claramente a conversa, soa como uma continuação.
- nota 4: 0: A lua está bonita, mas não confio nessa escuridão. / 1: Se ouvir um chiado, corre. / 0: Qualquer barulho eu aviso.
  - ⚠ A fala 'Se ouvir um chiado, corre.' é um pouco vaga, mas plausível para criaturas calmas à noite.
  - ⚠ A fala 'Qualquer barulho eu aviso.' é um fecho aceitável, mas poderia ser mais natural.
- nota 4: 0: Quem está de pé a essa hora? / 1: Se ouvir um chiado, corre. / 0: Qualquer barulho eu aviso.
  - ⚠ 'Se ouvir um chiado, corre' soa mais como alerta de jogador do que fala de aldeão/animal calmo, mas é plausível como aviso de creeper

### porco (4.38)  _um porco e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Fuço o dia inteiro e nunca me canso. / 1: Oink, cada um com o seu cantinho de lama. / 0: Depois a gente se encontra no barro.
  - ⚠ A fala 'Oink, cada um com o seu cantinho de lama.' soa um pouco desconexa com a anterior, mas ainda aceitável para porcos.
- nota 4: 0: Achei uma raiz gostosa debaixo da terra. / 1: Oink, cada um com o seu cantinho de lama. / 0: Depois a gente se encontra no barro.
  - ⚠ A resposta 'Oink, cada um com o seu cantinho de lama.' não responde diretamente à fala sobre a raiz, mas ainda é coerente com o mundo do porco.
  - ⚠ O fecho 'Depois a gente se encontra no barro.' é natural, mas a transição da raiz para o barro poderia ser mais conectada.
- nota 4: 0: Barro é a melhor parte do dia. / 1: Eu fuço do outro lado, então. / 0: Oink, a vida é boa.
  - ⚠ A fala 'Barro é a melhor parte do dia.' é um pouco abstrata para um porco, mas aceitável.
  - ⚠ A resposta 'Eu fuço do outro lado, então.' é coerente, mas poderia ser mais natural.
- nota 4: 0: Achei uma raiz gostosa debaixo da terra. / 1: Achar comida enterrada é uma arte. / 0: Oink, a vida é boa.
  - ⚠ 'Achar comida enterrada é uma arte' soa um pouco filosófico/abstrato demais para um porco, mas é passável
- nota 4: 0: Achei uma raiz gostosa debaixo da terra. / 1: Oink, cada um com o seu cantinho de lama. / 0: Oink, a vida é boa.
  - ⚠ A resposta 'Oink, cada um com o seu cantinho de lama.' não responde diretamente à fala sobre a raiz, mas ainda é plausível como comentário de porco.
  - ⚠ O fecho 'Oink, a vida é boa.' é um pouco genérico, mas aceitável.

### vaca (4.38)  _uma vaca e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Muuu, o rebanho está todo junto hoje. / 1: Calma é o que a gente tem de melhor. / 0: Quando escurecer, a gente se junta.
  - ⚠ A fala 'Calma é o que a gente tem de melhor.' soa filosófica demais para uma vaca, que tende a expressões simples e ligadas ao pasto ou ao rebanho.
  - ⚠ A fala 'Quando escurecer, a gente se junta.' é um pouco vaga, pois vacas já costumam estar juntas; poderia ser mais concreta, como 'Quando escurecer, a gente fica perto da cerca.'
- nota 4: 0: Muuu, o dia está calmo. / 1: Calma é o que a gente tem de melhor. / 0: Fica por perto, que é mais seguro.
  - ⚠ A fala 'Calma é o que a gente tem de melhor.' soa um pouco filosófica para uma vaca, mas ainda é aceitável.
- nota 4: 0: Muuu, o rebanho está todo junto hoje. / 1: Sem pressa, a vida rende mais. / 0: Fica por perto, que é mais seguro.
  - ⚠ 'a vida rende mais' soa um pouco filosófico para uma vaca, mas aceitável no tom calmo do rebanho
- nota 4: 0: Hoje o pasto está especialmente macio. / 1: Sem pressa, a vida rende mais. / 0: Quando escurecer, a gente se junta.
  - ⚠ A fala 'Sem pressa, a vida rende mais.' soa filosófica demais para uma vaca, que tende a expressões mais simples e concretas.

### acougueiro (4.50)  _villager:butcher e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Meu cutelo está afiado como nunca. / 1: Cada ofício tem a sua importância. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A fala 'Cada ofício tem a sua importância.' soa um pouco genérica e filosófica para um aldeão açougueiro, mas ainda é plausível.
  - ⚠ A última fala 'Passa aqui quando quiser levar um pedaço.' é um convite vago; poderia ser mais específica sobre o que está sendo oferecido.
- nota 4: 0: Cortar carne é um ofício que exige respeito. / 1: Cheiro de carne assando chama todo mundo. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A fala 'Passa aqui quando quiser levar um pedaço.' soa um pouco comercial demais para um aldeão açougueiro, que normalmente troca esmeraldas, mas é aceitável.
- nota 4: 0: Meu cutelo está afiado como nunca. / 1: Sem você, a vila passaria fome. / 0: O fogo do defumador nunca apaga.
  - ⚠ A fala 'Sem você, a vila passaria fome.' soa um pouco formal demais para uma conversa casual entre aldeões, mas ainda é plausível.
  - ⚠ A fala 'O fogo do defumador nunca apaga.' é um pouco poética para um açougueiro, mas aceitável como orgulho do trabalho.
- nota 4: 0: A carne de hoje está bem fresca. / 1: Cada ofício tem a sua importância. / 0: Passa aqui quando quiser levar um pedaço.
  - ⚠ A fala 1 ('Cada ofício tem a sua importância') soa um pouco filosófica/abstrata demais para um aldeão no meio de uma conversa de açougue, embora ainda passe

### aranha_caverna (4.50)  _uma aranha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Sss... a caverna é melhor que a superfície. / 1: Sss... subir é mais fácil que andar. / 0: Sss...
  - ⚠ A fala 'Sss... subir é mais fácil que andar.' é um pouco estranha para aranhas, que sobem paredes naturalmente, mas pode ser interpretada como preferência pessoal.
  - ⚠ O fecho 'Sss...' é muito vago e não conclui claramente a conversa.
- nota 4: 0: Sss... gosto do escuro e das paredes. / 1: Sss... a luz do sol incomoda os olhos. / 0: Sss...
  - ⚠ A fala 'Sss... gosto do escuro e das paredes.' é um pouco vaga para uma conversa, mas aceitável para aranhas.
  - ⚠ A resposta 'Sss... a luz do sol incomoda os olhos.' não responde diretamente à primeira fala, apenas adiciona outra preferência.
- nota 4: 0: Sss... gosto do escuro e das paredes. / 1: Sss... subir é mais fácil que andar. / 0: Sss...
  - ⚠ A fala 'Sss... subir é mais fácil que andar.' é um pouco estranha para uma aranha, pois aranhas não falam sobre preferências de locomoção, mas é aceitável como observação instintiva.
  - ⚠ O fecho 'Sss...' é muito vago e não fecha a conversa de forma clara, mas pode ser interpretado como um som de concordância.

### bibliotecario (4.50)  _villager:librarian e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Quem lê enxerga mais longe. / 1: Eu não entendo as letras, mas gosto de ouvir você. / 0: Ler é uma forma de viajar.
  - ⚠ O fecho 'Ler é uma forma de viajar' é um pouco aforístico/filosófico demais para um aldeão, embora o bibliotecário comporte um tom sentencioso
  - ⚠ A fala 1 'Eu não entendo as letras' soa levemente estranha vinda de um aldeão que convive com bibliotecário, mas é aceitável
- nota 4: 0: Cada livro guarda um segredo. / 1: Eu não entendo as letras, mas gosto de ouvir você. / 0: Ler é uma forma de viajar.
  - ⚠ A fala 'Eu não entendo as letras, mas gosto de ouvir você.' soa um pouco estranha para um aldeão, pois aldeões geralmente não demonstram apreço por ouvir leituras, mas é aceitável.
  - ⚠ A fala 'Ler é uma forma de viajar.' é um pouco filosófica para um aldeão bibliotecário, mas ainda dentro do personagem.
- nota 4: 0: Passei a manhã organizando as estantes. / 1: Um dia você me ensina? / 0: Ler é uma forma de viajar.
  - ⚠ A fala 'Ler é uma forma de viajar.' soa filosófica demais para um aldeão bibliotecário em uma conversa casual, mas ainda é aceitável.
- nota 4: 0: Cada livro guarda um segredo. / 1: Um dia você me ensina? / 0: Ler é uma forma de viajar.
  - ⚠ O fecho 'Ler é uma forma de viajar' é um pouco aforístico demais para um aldeão, mas aceitável para um bibliotecário

### bruxa_pocao (4.50)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: O caldeirão está borbulhando. / 1: Hehe, a minha é ainda melhor. / 0: Hehe, a noite vai ser divertida.
  - ⚠ A fala 'Hehe, a minha é ainda melhor.' é ambígua: não fica claro se 'a minha' se refere a um caldeirão ou a uma poção, o que pode confundir o ouvinte.
  - ⚠ A fala 'Hehe, a noite vai ser divertida.' é um fecho aceitável, mas poderia ser mais conectada à fala anterior para fechar melhor a conversa.
- nota 4: 0: Hehe, tenho uma poção nova para testar. / 1: Hehe, a minha é ainda melhor. / 0: Já sei qual receita usar.
  - ⚠ A fala 'Já sei qual receita usar' não fecha claramente a conversa, deixando a interação sem conclusão.
- nota 4: 0: O caldeirão está borbulhando. / 1: Hehe, a minha é ainda melhor. / 0: Já sei qual receita usar.
  - ⚠ Fala 1 'Hehe, a minha é ainda melhor' é um pouco vaga, mas aceitável para bruxas.
- nota 4: 0: Esse humano parece um bom voluntário. / 1: Mistura com cogumelo, dá um efeito curioso. / 0: Hehe, a noite vai ser divertida.
  - ⚠ A fala 1 responde à ideia de 'voluntário' mas desvia para poção sem ligar explicitamente ao humano, deixando a conexão um pouco solta

### cartografo (4.50)  _villager:cartographer e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Desenhei um mapa novo hoje. / 1: Eu nunca saio da vila, mas gosto de olhar os mapas. / 0: O mapa guarda o que ninguém viu.
  - ⚠ O fecho 'O mapa guarda o que ninguém viu' soa um pouco poético/filosófico demais para um aldeão cartógrafo, mas ainda passa
- nota 4: 0: Mapa bom mostra mais do que estradas. / 1: Eu nunca saio da vila, mas gosto de olhar os mapas. / 0: O mapa guarda o que ninguém viu.
  - ⚠ A fala 0 'Mapa bom mostra mais do que estradas' é um pouco aforística/filosófica para um aldeão cartógrafo, mas aceitável no tom de ofício
  - ⚠ O fecho 'O mapa guarda o que ninguém viu' repete a ideia enigmática da abertura em vez de fechar de forma mais concreta e cotidiana
- nota 4: 0: Todo caminho começa num bom desenho. / 1: O mundo além das colinas deve ser enorme. / 0: Um dia alguém percorre o que eu desenhei.
  - ⚠ A fala 1 ('O mundo além das colinas deve ser enorme') é dita por um aldeão comum, mas soa mais como curiosidade de aventureiro do que de aldeão; passável, porém pouco característica
  - ⚠ O fecho ('Um dia alguém percorre o que eu desenhei') não responde diretamente à fala 1, deixando a resposta um pouco solta
- nota 4: 0: Todo caminho começa num bom desenho. / 1: Deve ser bonito ver o mundo no papel. / 0: Um dia alguém percorre o que eu desenhei.
  - ⚠ A fala 'Todo caminho começa num bom desenho.' soa um pouco filosófica demais para um aldeão cartógrafo, mas ainda é plausível.
  - ⚠ A resposta 'Deve ser bonito ver o mundo no papel.' é um pouco vaga e não avança muito a conversa, mas é aceitável.

### cavalo (4.50)  _um cavalo e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Hoje o campo está livre, só falta espaço. / 1: Eu prefiro trotar e olhar a paisagem. / 0: Relincho de alegria.
  - ⚠ A fala 'Relincho de alegria' é uma descrição de ação, não uma fala natural de diálogo.
- nota 4: 0: Hoje o campo está livre, só falta espaço. / 1: Correr é o que fazemos de melhor. / 0: Relincho de alegria.
  - ⚠ A fala 'Relincho de alegria' é uma descrição de ação, não uma fala natural; poderia ser apenas 'Relincho!' ou algo similar.
- nota 4: 0: Dá vontade de correr até o vento passar por mim. / 1: Correr é o que fazemos de melhor. / 0: Relincho de alegria.
  - ⚠ 'Relincho de alegria' como fala é meio descritivo em vez de diálogo, mas passa como som de cavalo
- nota 4: 0: Dá vontade de correr até o vento passar por mim. / 1: Eu prefiro trotar e olhar a paisagem. / 0: Relincho de alegria.
  - ⚠ 'Relincho de alegria' como fala é meio estranho, soa mais como rubrica do que fala

### curiosidade_creeper (4.50)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 3: 0: Tenho pavor daquele chiado do creeper. / 1: É verdade. / 0: Por isso fico de olho em tudo.
  - ⚠ A resposta 'É verdade.' é vaga e não reage de fato ao medo do creeper
  - ⚠ O fecho 'Por isso fico de olho em tudo.' não fecha bem a conversa, parece uma fala solta
- nota 4: 0: Dizem que creeper tem medo de gato. / 1: Também acho. / 0: Que ele passe longe daqui.
  - ⚠ A fala 'Também acho.' é vaga e não acrescenta muito, mas é aceitável para uma conversa casual.
  - ⚠ A fala 'Que ele passe longe daqui.' soa um pouco abrupta, mas fecha a conversa de forma coerente.
- nota 4: 0: Dizem que creeper tem medo de gato. / 1: Pois é. / 0: Que ele passe longe daqui.
  - ⚠ A resposta 'Pois é.' é um pouco vaga, mas aceitável como fala curta de aldeão

### entardecer (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é fim de tarde_
- nota 4: 0: O sol está se pondo. / 1: Hora de ficar de olho, a noite traz coisa ruim. / 0: Cada dia termina assim.
  - ⚠ A fala 'Cada dia termina assim.' soa um pouco vaga e não fecha a conversa de forma natural, podendo ser mais específica para a situação.
- nota 3: 0: A tarde acabou rápido hoje. / 1: Eu gosto dessa cor no céu. / 0: É verdade, vamos com cuidado.
  - ⚠ O fecho 'vamos com cuidado' não conecta com a fala anterior sobre a cor do céu
  - ⚠ A resposta 'Eu gosto dessa cor no céu' é genérica e não reage ao 'acabou rápido'

### esqueleto_armadura (4.50)  _um esqueleto e outra criatura da mesma espécie; o jogador veste armadura_
- nota 4: 0: O humano veste uma armadura de ferro. Vai ser difícil acertar. / 1: Armadura nenhuma é perfeita. / 0: Vamos tentar mesmo assim.
  - ⚠ 'Armadura nenhuma é perfeita' soa um pouco filosófico/abstrato para um esqueleto, mas é passável como provocação
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Mire na cabeça. / 0: Vamos tentar mesmo assim.
  - ⚠ A fala 'Mire na cabeça.' é um pouco vaga, mas plausível para esqueletos que atacam com arco e flecha.
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Flecha encontra brecha. / 0: Paciência é a nossa arma.
  - ⚠ 'Paciência é a nossa arma' soa um pouco filosófico para esqueletos, mas ainda cabe como estratégia de emboscada
- nota 4: 0: Aquele humano está de uma armadura de ferro. / 1: Armadura nenhuma é perfeita. / 0: Paciência é a nossa arma.
  - ⚠ A fala 'Paciência é a nossa arma' soa filosófica demais para um esqueleto, que normalmente é hostil e direto.

### jogador_bateu (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já machucou quem abre (fato verificado)_
- nota 4: 0: Eu me lembro bem de quando o humano me bateu. / 1: Quem bate uma vez pode bater de novo. / 0: Já aprendi a lição.
  - ⚠ A fala 'Já aprendi a lição.' pode soar ambígua, pois não fica claro se a criatura aprendeu a evitar o humano ou a aceitar a violência, o que pode confundir o tom da conversa.
- nota 4: 0: O humano me machucou uma vez. Não esqueci. / 1: Então fica de olho. / 0: Já aprendi a lição.
  - ⚠ A fala 'Já aprendi a lição.' pode soar ambígua, pois não fica claro se a lição é evitar o humano ou aceitar a dor, mas ainda é plausível.

### jogador_chuva (4.50)  _dois aldeões; está chovendo_
- nota 4: 0: Olha o humano debaixo dessa chuva toda. / 1: Deve estar com frio. / 0: Se vier até aqui, eu deixo ficar.
  - ⚠ 'Deve estar com frio' é um pouco genérico, mas aceitável para aldeão
  - ⚠ O fecho 'eu deixo ficar' é simpático demais para aldeões, que costumam ser mais fechados com estranhos
- nota 4: 0: O humano está na chuva, nem parece se importar. / 1: Alguém devia oferecer um abrigo. / 0: Ao menos a chuva lava a poeira.
  - ⚠ A fala 'Alguém devia oferecer um abrigo.' soa um pouco vaga e não é uma resposta direta à observação anterior, mas ainda é plausível para aldeões.

### jogador_nome_ambos (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; quem abre sabe o nome do jogador_
- nota 4: 0: Bia voltou! Que bom ver. / 1: Também gosto de ver Bia. / 0: Vou dar um oi.
  - ⚠ A fala 1 'Também gosto de ver Bia' é um pouco redundante e fraca como resposta, mas aceitável
  - ⚠ O fecho 'Vou dar um oi' não fecha muito bem a conversa, soa como início de ação em vez de encerramento
- nota 3: 0: Olha quem está aí, Bia. / 1: Também gosto de ver Bia. / 0: Vou dar um oi.
  - ⚠ A fala 'Também gosto de ver Bia.' soa estranha como resposta a 'Olha quem está aí, Bia.'; não é uma reação natural.
  - ⚠ O fecho 'Vou dar um oi.' não encerra a conversa de forma coesa, pois a segunda criatura não responde a essa intenção.

### jogador_presente (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já deu um presente a quem abre (fato verificado)_
- nota 4: 0: Sabia que o humano já me presenteou? / 1: Poucos fazem isso. / 0: Nunca esqueci.
  - ⚠ A fala 'Nunca esqueci.' soa um pouco estranha para uma criatura calma, pois implica memória de longo prazo e gratidão duradoura, o que pode não combinar com animais simples como vacas ou ovelhas.
- nota 4: 0: Sabia que o humano já me presenteou? / 1: Pelo visto é gente boa. / 0: Nunca esqueci.
  - ⚠ 'Nunca esqueci.' é um fecho um pouco vago — não retoma claramente o presente nem a bondade do humano, soa solto
- nota 4: 0: Sabia que o humano já me presenteou? / 1: Pelo visto é gente boa. / 0: Foi um dia especial.
  - ⚠ A fala 'Foi um dia especial.' é um pouco vaga e não fecha claramente a conversa, mas é aceitável.
- nota 4: 0: O humano me deu um presente outro dia. Fiquei com o coração quentinho. / 1: Poucos fazem isso. / 0: Nunca esqueci.
  - ⚠ A fala 'Fiquei com o coração quentinho' soa um pouco sentimental demais para criaturas calmas como aldeões ou animais de fazenda, que tendem a expressões mais simples.
  - ⚠ A resposta 'Poucos fazem isso.' é um pouco vaga e poderia ser mais específica ao presente ou à ação do humano.

### monstros_item (4.50)  _dois monstros hostis; o jogador segura um item_
- nota 4: 0: O humano segura uma espada de ferro. / 1: Se ele usar, vai doer. / 0: Agora não.
  - ⚠ A fala 'Agora não.' é um fecho muito abrupto e não responde diretamente à fala anterior, deixando a conversa sem conclusão clara.
- nota 4: 0: O humano carrega uma espada de ferro. Cuidado. / 1: Se ele usar, vai doer. / 0: Agora não.
  - ⚠ A fala 'Agora não.' é ambígua e não fecha claramente a conversa.
- nota 4: 0: Aquele humano tem uma espada de ferro na mão. / 1: Eu vou pela esquerda. / 0: Agora não.
  - ⚠ O fecho 'Agora não.' é um pouco vago e não fecha claramente a conversa iniciada pela fala 1
- nota 4: 0: O humano carrega uma espada de ferro. Cuidado. / 1: Eu vou pela esquerda. / 0: Agora não.
  - ⚠ O fecho 'Agora não.' é um pouco vago e não fecha claramente a conversa iniciada sobre a espada

### noite_frio (4.50)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; é noite_
- nota 4: 0: A noite está fria. / 1: Fica pertinho de mim que esquenta. / 0: Ainda bem que o dia volta.
  - ⚠ A fala 'Fica pertinho de mim que esquenta' soa um pouco íntima para criaturas da mesma espécie, mas é aceitável em contexto de frio.
- nota 4: 0: O vento da noite gela até os ossos. / 1: Fica pertinho de mim que esquenta. / 0: Amanhã o sol esquenta de novo.
  - ⚠ A fala 'Fica pertinho de mim que esquenta' soa um pouco íntima demais para criaturas calmas como vacas ou aldeões, mas ainda é plausível.
  - ⚠ A fala 'Amanhã o sol esquenta de novo' é um fecho aceitável, mas poderia ser mais natural se referisse ao frio da noite diretamente.

### pasto (4.50)  _dois animais da fazenda; é de dia_
- nota 4: 0: O pasto hoje está macio. / 1: É verdade. / 0: Aqui a gente está seguro.
  - ⚠ A resposta 'É verdade.' é muito seca e genérica, não acrescenta nada ao que foi dito
  - ⚠ O fecho 'Aqui a gente está seguro.' muda de assunto sem gancho com a fala anterior sobre o pasto
- nota 4: 0: Viu aquela touceira de grama ali? / 1: Dá para viver só disso. / 0: A vida é simples, e isso me basta.
  - ⚠ A fala 'Dá para viver só disso.' soa um pouco filosófica para animais de fazenda, mas ainda é plausível.
  - ⚠ A fala 'A vida é simples, e isso me basta.' é um pouco reflexiva demais para o contexto, mas aceitável.
- nota 4: 0: Passei a manhã pastando, que paz. / 1: Pois é. / 0: Aqui a gente está seguro.
  - ⚠ A fala 'Pois é.' é muito vaga e não acrescenta nada à conversa, soando um pouco artificial para animais de fazenda.
- nota 4: 0: Esse capim está uma delícia. / 1: Nem me fale. / 0: A vida é simples, e isso me basta.
  - ⚠ A fala 'A vida é simples, e isso me basta' soa filosófica demais para um animal de fazenda, que normalmente não reflete sobre a vida.

### pescador (4.50)  _villager:fisherman e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: A isca certa muda tudo. / 1: Peixe assado é um banquete. / 0: Quem pesca aprende a esperar.
  - ⚠ A fala 1 ('Peixe assado é um banquete') responde pouco à fala 0 sobre isca; muda de assunto em vez de reagir
  - ⚠ O fecho 'Quem pesca aprende a esperar' é um pouco aforístico/filosófico demais para um aldeão pescador
- nota 4: 0: A isca certa muda tudo. / 1: A vila come melhor por sua causa. / 0: Amanhã volto cedo ao rio.
  - ⚠ A fala 'A vila come melhor por sua causa.' soa um pouco formal demais para uma conversa casual entre aldeões, mas ainda é plausível.
- nota 4: 0: A isca certa muda tudo. / 1: Eu nunca tive paciência para pescar. / 0: Amanhã volto cedo ao rio.
  - ⚠ A fala 'Eu nunca tive paciência para pescar.' é genérica e não especifica qual dos dois aldeões responde, mas isso não é um problema grave.
  - ⚠ A fala 'Amanhã volto cedo ao rio.' não fecha claramente a conversa, pois não responde diretamente à fala anterior.
- nota 4: 0: Peixe fresco é meu orgulho. / 1: Peixe assado é um banquete. / 0: Quem pesca aprende a esperar.
  - ⚠ A fala 'Peixe assado é um banquete.' soa genérica demais para um aldeão pescador, que normalmente fala de trocas ou do seu ofício.
  - ⚠ O fecho 'Quem pesca aprende a esperar.' é um pouco filosófico para um aldeão comum, mas ainda aceitável.

### zumbi_carne (4.50)  _um zumbi e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: A noite é boa. A fome também. / 1: Vamos... devagar... / 0: Quase... quase...
  - ⚠ O fecho 'Quase... quase...' é vago e não fecha claramente a conversa
  - ⚠ A resposta 'Vamos... devagar...' não conecta bem com 'A noite é boa. A fome também.'
- nota 4: 0: Grrr... tem gente por perto. / 1: Vamos... devagar... / 0: Hmmm...
  - ⚠ Fala 1 'Vamos... devagar...' soa mais cautelosa do que o esperado para zumbis, que normalmente são agressivos e diretos, mas ainda é plausível em contexto de caça.
- nota 4: 0: Grrr... tem gente por perto. / 1: Grrrr... / 0: Quase... quase...
  - ⚠ A fala 'Quase... quase...' é vaga e não fecha claramente a conversa, deixando o sentido ambíguo.
- nota 4: 0: Grrr... tem gente por perto. / 1: Carne... carne... / 0: Hmmm...
  - ⚠ A fala 'Carne... carne...' é um pouco vaga, mas aceitável para zumbis.
  - ⚠ O fecho 'Hmmm...' é curto e não encerra claramente a conversa, mas é plausível.

### bicho_quer_comida (4.62)  _dois animais da fazenda; o jogador segura um item; quem abre GOSTA do que o jogador segura_
- nota 4: 0: Olha só, trigo na mão de o humano. Será que é para mim? / 1: Eu também queria. / 0: Quem sabe ele se compadece.
  - ⚠ Fala 1 'Eu também queria.' é um pouco vaga, mas aceitável para um animal.
  - ⚠ Fala 0 'Quem sabe ele se compadece.' soa levemente formal para uma fala curta de animal, mas ainda natural.
- nota 4: 0: O humano está com trigo. Queria um pouco também. / 1: Ele nem olhou para nós, que pena. / 0: Eu espero aqui, bem quieto.
  - ⚠ A fala 1 'Ele nem olhou para nós, que pena.' não responde diretamente ao desejo expresso na fala 0, mas ainda é plausível como comentário.
  - ⚠ A fala 0 final 'Eu espero aqui, bem quieto.' não fecha claramente a conversa, pois não há reação à fala 1.
- nota 4: 0: Trigo! É o meu favorito. Será que ele divide? / 1: Se ele der, divide comigo? / 0: Quem sabe ele se compadece.
  - ⚠ 'Quem sabe ele se compadece' soa um pouco formal/filosófico para um animal
  - ⚠ as duas primeiras falas são quase a mesma pergunta, o fecho não avança muito a conversa

### bruxa_pocao2 (4.62)  _uma bruxa e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Uma poção nova sempre me anima. / 1: A minha acerta de longe. / 0: Hehe, a prática leva à perfeição.
  - ⚠ Fala 1 'A minha acerta de longe' é um pouco vaga, mas aceitável para bruxas.
  - ⚠ Fala 0 'Hehe, a prática leva à perfeição' soa levemente clichê, mas fecha bem.
- nota 4: 0: Hehe, acertei a mistura certa. / 1: Eu prefiro as venenosas. / 0: Hehe, a prática leva à perfeição.
  - ⚠ A fala 'Eu prefiro as venenosas' é um pouco vaga, mas aceitável para bruxas.
  - ⚠ A resposta 'Hehe, a prática leva à perfeição' não se conecta diretamente com a preferência por venenosas, mas fecha de forma genérica.
- nota 4: 0: Hehe, acertei a mistura certa. / 1: Quero ver o efeito nos humanos. / 0: Hehe, depois a gente compara.
  - ⚠ A fala 1 ('Quero ver o efeito nos humanos') é um pouco longa e explicativa para o tom curto e malicioso das bruxas
  - ⚠ O fecho 'depois a gente compara' é levemente vago; 'compara os resultados' soaria mais natural

### curtidor (4.62)  _villager:leatherworker e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Bota de couro dura uma vida. / 1: Esse ofício é mais difícil do que parece. / 0: Cada peça sai única.
  - ⚠ A fala 'Bota de couro dura uma vida.' soa um pouco estranha para um aldeão coureiro, pois ele normalmente falaria de forma mais simples ou com termos de troca, mas é aceitável.
  - ⚠ A resposta 'Esse ofício é mais difícil do que parece.' é genérica e poderia ser dita por qualquer aldeão, não específica do coureiro.
- nota 4: 0: O couro de hoje está macio. / 1: Esse ofício é mais difícil do que parece. / 0: Cada peça sai única.
  - ⚠ A fala 'Esse ofício é mais difícil do que parece.' soa um pouco genérica e não responde diretamente ao comentário sobre o couro macio.
  - ⚠ O fecho 'Cada peça sai única.' é um pouco vago e não encerra claramente a conversa.

### ferreiro_armas (4.62)  _villager:weaponsmith e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Hoje o machado ficou perfeito. / 1: Isso é arte, não só ofício. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'Isso é arte, não só ofício.' soa um pouco filosófica demais para um aldeão comum, mas ainda aceitável.
  - ⚠ O fecho 'Mais um dia, mais uma lâmina.' é um pouco genérico e não responde diretamente à fala anterior.
- nota 4: 0: Hoje o machado ficou perfeito. / 1: Espero que nunca precisem usar. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'Mais um dia, mais uma lâmina.' soa um pouco filosófica demais para um aldeão armeiro, mas ainda é aceitável.
- nota 4: 0: Hoje o machado ficou perfeito. / 1: A vila dorme melhor com ferro bom por perto. / 0: Mais um dia, mais uma lâmina.
  - ⚠ A fala 'A vila dorme melhor com ferro bom por perto.' soa um pouco poética demais para um aldeão comum, mas ainda aceitável.

### galinha (4.62)  _uma galinha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Botei um ovo e já cacarejei para todo mundo. / 1: Có có, ciscar é a melhor parte. / 0: Có có, a vida é boa.
  - ⚠ A resposta 'Có có, ciscar é a melhor parte' não responde diretamente ao ovo posto, muda de assunto de forma um pouco abrupta
  - ⚠ O fecho 'Có có, a vida é boa' é genérico e não amarra bem com a fala anterior sobre ciscar
- nota 4: 0: Botei um ovo e já cacarejei para todo mundo. / 1: Có có, ciscar é a melhor parte. / 0: Então vou ciscar mais um pouco.
  - ⚠ A resposta 'Có có, ciscar é a melhor parte.' não responde diretamente à fala sobre botar ovo e cacarejar, mas ainda é plausível para galinhas.
  - ⚠ O fecho 'Então vou ciscar mais um pouco.' é coerente, mas a transição de assunto poderia ser mais natural.
- nota 4: 0: Có có! Achei umas sementes no chão. / 1: Có, eu fico de olho no céu, por via das dúvidas. / 0: Có có, a vida é boa.
  - ⚠ O fecho 'a vida é boa' é um pouco filosófico para uma galinha, mas aceitável no tom leve

### gato (4.62)  _um gato e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 3: 0: Hoje eu quase não saí do lugar. / 1: Eu também prefiro ficar parado. / 0: Ninguém me acorda hoje.
  - ⚠ Fala 0: 'Hoje eu quase não saí do lugar.' é vaga e não combina com a situação 'uma situação qualquer do dia a dia'.
  - ⚠ Fala 1: 'Eu também prefiro ficar parado.' não responde diretamente à fala anterior, apenas concorda de forma genérica.
- nota 4: 0: Dormi no sol a tarde toda. / 1: Eu também prefiro ficar parado. / 0: Ninguém me acorda hoje.
  - ⚠ A fala 'Eu também prefiro ficar parado' não responde diretamente ao ato de dormir no sol, apenas concorda vagamente.
  - ⚠ O fecho 'Ninguém me acorda hoje' não encerra claramente a conversa, soa como um novo tópico.

### golem_ronda (4.62)  _um golem de ferro e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: Dei a volta na vila e está tudo calmo. / 1: Sem você, eu não teria coragem de sair. / 0: Fico de pé até amanhecer.
  - ⚠ A fala 'Sem você, eu não teria coragem de sair.' soa mais como algo que um aldeão diria, mas não está claro qual dos dois aldeões fala, e a resposta do golem 'Fico de pé até amanhecer.' não responde d
- nota 4: 0: A noite foi tranquila na vila. / 1: Sem você, eu não teria coragem de sair. / 0: Fico de pé até amanhecer.
  - ⚠ A fala 1 ('Sem você, eu não teria coragem de sair') soa um pouco dramática para um aldeão em conversa cotidiana, mas é passável
- nota 4: 0: A noite foi tranquila na vila. / 1: A vila é segura por sua causa. / 0: Fico de pé até amanhecer.
  - ⚠ A fala 'A vila é segura por sua causa.' soa um pouco formal demais para um aldeão, que normalmente fala de forma mais simples e direta.
  - ⚠ A fala 'Fico de pé até amanhecer.' é um pouco ambígua, pois golems não dormem, então 'ficar de pé' pode soar estranho, embora aceitável.

### jogador_acalmou (4.62)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já acalmou quem abre quando estava com medo (fato verificado)_
- nota 4: 0: Quando eu estava com medo, o humano apareceu e me ajudou a respirar. / 1: Gente assim aquece o coração. / 0: Não esqueci essa gentileza.
  - ⚠ A fala 'Gente assim aquece o coração.' soa um pouco filosófica para criaturas simples como animais de fazenda ou aldeões, mas é aceitável.
- nota 4: 0: Quando eu estava com medo, o humano apareceu e me ajudou a respirar. / 1: Que bom que existe quem faz isso. / 0: Fez bem, de verdade.
  - ⚠ 'me ajudou a respirar' soa um pouco abstrato para um aldeão/animal, mas é aceitável no tom calmo
  - ⚠ o fecho 'Fez bem, de verdade' é um pouco vago e não acrescenta muito à resposta anterior

### jogador_fome (4.62)  _dois aldeões; o jogador está com fome_
- nota 4: 0: O humano está com cara de fome. / 1: Comida resolve metade dos problemas. / 0: Se ele pedir, eu dou um jeito.
  - ⚠ 'Comida resolve metade dos problemas' soa um pouco filosófico/genérico demais para um aldeão
  - ⚠ 'dou um jeito' é vago; aldeões costumam falar de trocas ou pão
- nota 4: 0: O humano está com cara de fome. / 1: Dava para oferecer um pouco de pão. / 0: Que ache o que comer.
  - ⚠ O fecho 'Que ache o que comer' soa um pouco seco/indiferente para um aldeão, mas é aceitável
- nota 4: 0: Acho que o humano não come há um tempo. / 1: Comida resolve metade dos problemas. / 0: Se ele pedir, eu dou um jeito.
  - ⚠ A fala 'Comida resolve metade dos problemas.' soa um pouco filosófica demais para um aldeão comum, mas ainda é plausível.

### jogador_traiu (4.62)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; o jogador já quebrou um acordo com quem abre (fato verificado)_
- nota 4: 0: Fizemos um acordo, e o humano acabou com ele. / 1: Palavra quebrada é difícil de perdoar. / 0: Quem sabe um dia melhore.
  - ⚠ 'Quem sabe um dia melhore' é um pouco vago como fecho, mas aceitável
- nota 3: 0: O humano quebrou a nossa palavra. Eu me lembro. / 1: Então não dá para confiar tanto. / 0: Pois é, dói.
  - ⚠ 'quebrou a nossa palavra' está errado: quem quebra a palavra é quem prometeu, não o humano; deveria ser 'quebrou a palavra dele' ou 'quebrou o acordo'
  - ⚠ 'Eu me lembro' soa redundante e pouco natural em fala curta de aldeão/animal

### trovoada (4.62)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; há tempestade_
- nota 4: 0: Que tempestade feia. / 1: Fica longe de árvore alta, dizem que atrai raio. / 0: Vamos aguentar juntos.
  - ⚠ A fala 'Fica longe de árvore alta, dizem que atrai raio.' soa mais como conselho humano do que algo que um aldeão ou animal diria naturalmente.
- nota 4: 0: Esse temporal está de dar medo. / 1: Fica longe de árvore alta, dizem que atrai raio. / 0: Chega mais perto, é mais seguro.
  - ⚠ A fala 'Chega mais perto, é mais seguro.' pode ser ambígua: se estão ao ar livre durante tempestade, aproximar-se de outra criatura não necessariamente aumenta a segurança, mas é aceitável como consel
- nota 4: 0: Que tempestade feia. / 1: Raio assim faz a gente querer ficar junto. / 0: Vamos aguentar juntos.
  - ⚠ A fala 'Raio assim faz a gente querer ficar junto' soa um pouco romântica demais para criaturas calmas como aldeões ou animais de fazenda, mas ainda é plausível em contexto de medo de tempestade.

### vila_armadura (4.62)  _dois aldeões; o jogador veste armadura_
- nota 4: 0: Olha só, o humano está de uma armadura de ferro. / 1: Dá até medo de chegar perto. / 0: Eu só queria saber onde fez.
  - ⚠ A fala 'Eu só queria saber onde fez.' soa um pouco deslocada, pois aldeões não costumam se interessar por fabricação de armaduras, mas é aceitável como curiosidade.
- nota 4: 0: Olha só, o humano está de uma armadura de ferro. / 1: Deve ter custado caro. / 0: Eu só queria saber onde fez.
  - ⚠ A fala 'Deve ter custado caro.' é plausível para um aldeão, mas 'Eu só queria saber onde fez.' soa um pouco deslocada, pois aldeões não costumam se interessar por fabricação de armaduras.
- nota 4: 0: Reparou na roupa de o humano? É uma armadura de ferro. / 1: Dá até medo de chegar perto. / 0: Eu só queria saber onde fez.
  - ⚠ O fecho 'Eu só queria saber onde fez' é um pouco truncado e não fecha bem a conversa, soa como fala solta

### zumbi_armadura (4.62)  _um zumbi e outra criatura da mesma espécie; o jogador veste armadura_
- nota 4: 0: Metal... uma armadura de ferro... Grrr. / 1: Duro... mas a fome é maior. / 0: Hmmm...
  - ⚠ A fala 'Duro... mas a fome é maior.' é um pouco filosófica demais para um zumbi, que normalmente só grunhe e quer comer.
  - ⚠ O fecho 'Hmmm...' é vago e não encerra claramente a conversa.
- nota 4: 0: O humano veste uma armadura de ferro. Duro de morder. / 1: Eu mordo de qualquer jeito. / 0: Hmmm...
  - ⚠ A fala 'Hmmm...' é muito vaga e não fecha a conversa de forma clara.
- nota 4: 0: O humano veste uma armadura de ferro. Duro de morder. / 1: Grrr... duro de morder. / 0: Hmmm...
  - ⚠ O fecho 'Hmmm...' é vago, mas aceitável para um zumbi

### afazeres (4.75)  _dois aldeões; é de dia_
- nota 3: 0: Hoje ainda preciso arrumar a casa. / 1: Trabalho de vila nunca acaba. / 0: Valeu, ajuda é sempre bem-vinda.
  - ⚠ A fala 'Valeu, ajuda é sempre bem-vinda.' não responde diretamente à fala anterior 'Trabalho de vila nunca acaba.' e soa como se o aldeão estivesse agradecendo por uma oferta de ajuda que não foi feit

### amanhecer (4.75)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está amanhecendo_
- nota 4: 0: O dia está nascendo, olha ali. / 1: Que alívio, nem dormi direito. / 0: Vamos ver o que o dia traz.
  - ⚠ A fala 'Que alívio, nem dormi direito.' sugere que a criatura passou a noite em claro, mas não há contexto na situação de amanhecer que justifique esse alívio, soando um pouco deslocada para criaturas
- nota 4: 0: Finalmente amanheceu. / 1: O sol sempre chega, é só esperar. / 0: Bom dia, então.
  - ⚠ 'O sol sempre chega, é só esperar' soa um pouco filosófico para um aldeão/animal, mas ainda passável

### bicho_cheiro (4.75)  _dois animais da fazenda; é de dia_
- nota 4: 0: O vento trouxe cheiro de chuva. / 1: Eu também senti, vem de longe. / 0: Vou seguir o cheiro depois.
  - ⚠ A fala 'Vou seguir o cheiro depois.' é um pouco vaga e não fecha claramente a conversa, mas é aceitável.
- nota 4: 0: O vento trouxe cheiro de chuva. / 1: O nariz da gente não engana. / 0: Vou seguir o cheiro depois.
  - ⚠ A fala 'O nariz da gente não engana' soa um pouco estranha para animais, pois 'da gente' é uma expressão mais humana, mas ainda aceitável.
  - ⚠ A fala 'Vou seguir o cheiro depois' é um pouco vaga e não fecha totalmente a conversa, mas é plausível.

### camas (4.75)  _dois aldeões; é noite_
- nota 3: 0: Aquela cama perto da porta é minha, hein. / 1: Eu também, mal me aguento em pé. / 0: Até amanhã.
  - ⚠ A resposta 'Eu também, mal me aguento em pé.' não responde diretamente à fala sobre a cama, soa como se estivesse concordando com cansaço, mas não com a posse da cama.
  - ⚠ O fecho 'Até amanhã.' é aceitável, mas a conversa parece truncada; falta uma transição mais natural entre a disputa pela cama e a despedida.

### creeper_chiado (4.75)  _um creeper e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Ssss... silêncio. / 1: Ssss... eu também ouvi. / 0: Ssss... paciência.
  - ⚠ O fecho 'Ssss... paciência.' é um pouco vago e não fecha claramente o que 'ouviram'
  - ⚠ A resposta 'eu também ouvi' pressupõe algo audível que nunca é nomeado, deixando a conversa um pouco solta
- nota 4: 0: Ssss... silêncio. / 1: Ssss... cuidado com os gatos. / 0: Ssss...
  - ⚠ O fecho 'Ssss...' é muito vago, mas aceitável para um creeper

### enderman_agua (4.75)  _um enderman e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Eu fico longe de qualquer poça. / 1: Eu me teletransporto quando ela cai. / 0: Eu sumo antes que me molhe.
  - ⚠ A fala 1 ('quando ela cai') é um pouco vaga — 'ela' não tem referente claro; poderia ser 'quando a chuva cai'
  - ⚠ A fala 0 de fecho ('antes que me molhe') repete a ideia da fala 0 de abertura, deixando o fecho pouco acrescentador

### esqueleto_mira (4.75)  _um esqueleto e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Silêncio. Estou mirando. / 1: Não erra desta vez. / 0: Já estou com a flecha encaixada.
  - ⚠ A fala 1 'Não erra desta vez' soa mais como um comandante corrigindo um subordinado do que como um igual da mesma espécie; um esqueleto falando com outro esqueleto poderia ser mais simétrico ou compet
- nota 4: 0: Ossos quietos, flechas prontas. / 1: Não erra desta vez. / 0: Já estou com a flecha encaixada.
  - ⚠ A fala 'Não erra desta vez.' soa como uma ordem ou provocação, mas não fica claro se é uma resposta direta à fala anterior.
  - ⚠ A fala 'Já estou com a flecha encaixada.' é um fecho aceitável, mas poderia ser mais natural se conectasse melhor com a resposta anterior.

### ferreiro (4.75)  _villager:toolsmith e dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: O fogo da forja nunca me deixa com frio. / 1: A vila agradece o seu trabalho. / 0: Metal bom pede paciência.
  - ⚠ A fala 'A vila agradece o seu trabalho.' soa um pouco formal demais para uma conversa casual entre aldeões, mas ainda é plausível.
- nota 4: 0: Uma boa picareta muda tudo. / 1: A vila agradece o seu trabalho. / 0: Passa lá depois, tenho coisa nova.
  - ⚠ A fala 'Passa lá depois, tenho coisa nova.' soa um pouco vaga, mas é aceitável para um ferreiro.

### golem_guarda (4.75)  _dois aldeões e um golem de ferro; uma situação qualquer do dia a dia_
- nota 4: 0: Você nunca dorme, né? / 1: Enquanto eu estiver aqui, ninguém passa. / 0: Por isso a vila ainda existe.
  - ⚠ A fala 1 ('ninguém passa') responde à pergunta sobre dormir de forma um pouco deslocada — soa mais como resposta a uma ameaça do que à observação sobre nunca dormir
- nota 4: 0: A vila fica mais tranquila com você aqui. / 1: Dormir não é comigo, eu fico de pé. / 0: Qualquer coisa, grito por você.
  - ⚠ A fala 'Dormir não é comigo, eu fico de pé.' soa um pouco estranha para um golem de ferro, pois golems não dormem, mas a resposta é coerente com a situação de proteção.
  - ⚠ A fala 'Qualquer coisa, grito por você.' é um pouco vaga, mas aceitável.

### jogador_item (4.75)  _dois aldeões; o jogador segura um item_
- nota 4: 0: Aquela pessoa carrega esmeraldas. Deve valer algo. / 1: Eu também gostaria de ter esmeraldas. / 0: Cada um carrega o que precisa.
  - ⚠ A fala 'Cada um carrega o que precisa.' soa um pouco filosófica para um aldeão, mas ainda é aceitável.
- nota 4: 0: Olha só, o humano anda com esmeraldas na mão. / 1: Parece útil, isso. / 0: Vou perguntar, quem sabe.
  - ⚠ O fecho 'Vou perguntar, quem sabe' fica um pouco vago e não fecha bem a conversa

### monstros_dia (4.75)  _dois monstros hostis; é de dia; o céu está limpo_
- nota 4: 0: Odeio o dia. / 1: Procura uma sombra. / 0: Falta pouco para escurecer.
  - ⚠ 'Falta pouco para escurecer' dito de dia soa impreciso, mas aceitável para monstros que evitam o sol
- nota 4: 0: Dia é hora de se esconder. / 1: Procura uma sombra. / 0: Falta pouco para escurecer.
  - ⚠ 'Falta pouco para escurecer' dito de dia com céu limpo soa impreciso, mas aceitável para monstros que temem o sol

### monstros_lua (4.75)  _dois monstros hostis; é noite_
- nota 4: 0: A lua está cheia hoje. / 1: Os humanos dormem e a gente trabalha. / 0: Vamos começar.
  - ⚠ A fala 'Os humanos dormem e a gente trabalha' soa um pouco filosófica para monstros hostis, mas ainda é plausível.

### ovelha (4.75)  _uma ovelha e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Passei o dia mordiscando grama. / 1: Depois da tosa a gente sente um friozinho. / 0: A gente se junta quando escurecer.
  - ⚠ A fala 'Depois da tosa a gente sente um friozinho.' não responde diretamente à fala anterior sobre mordiscar grama, mas ainda é plausível como comentário relacionado ao cotidiano de ovelhas.
  - ⚠ A fala 'A gente se junta quando escurecer.' fecha a conversa de forma um pouco abrupta, mas é aceitável como comportamento natural de ovelhas.
- nota 4: 0: Passei o dia mordiscando grama. / 1: Mééé, lã crescida aquece no frio. / 0: A gente se junta quando escurecer.
  - ⚠ A fala 'Mééé, lã crescida aquece no frio.' soa um pouco desconexa da anterior, pois não responde diretamente ao ato de mordiscar grama.

### vila_fome (4.75)  _dois aldeões; o jogador está com fome_
- nota 4: 0: Acho que o humano não come há um tempo. / 1: A vila sempre tem o que comer. / 0: Comida é o que não falta por aqui.
  - ⚠ A fala 1 'A vila sempre tem o que comer' responde pouco ao comentário sobre o humano estar com fome; soa como mudança de assunto
  - ⚠ O fecho 'Comida é o que não falta por aqui' repete a ideia da fala 1 sem fechar de fato a conversa sobre o humano
- nota 4: 0: O humano está com cara de fome. / 1: A vila sempre tem o que comer. / 0: Comida é o que não falta por aqui.
  - ⚠ A fala 1 'A vila sempre tem o que comer' é um pouco genérica e não responde diretamente à observação sobre a fome do humano
  - ⚠ O fecho 'Comida é o que não falta por aqui' repete a ideia da fala 1 sem acrescentar nada, soando redundante

### vila_porta_noite (4.75)  _dois aldeões; é noite_
- nota 4: 0: Eu confiro a porta antes de dormir. / 1: Zumbi quebra porta de madeira, sabia? / 0: Amanhã tudo estará no lugar.
  - ⚠ A fala 'Amanhã tudo estará no lugar' não responde diretamente à preocupação sobre zumbis quebrarem portas, deixando o fecho um pouco vago.

### warden_sculk (4.75)  _um Warden e outra criatura da mesma espécie; uma situação qualquer do dia a dia_
- nota 4: 0: Cada passo faz o chão vibrar. / 1: Quem corre faz mais barulho. / 0: Quieto, alguém se aproxima.
  - ⚠ A fala 'Quem corre faz mais barulho.' soa genérica e não específica do Warden, que é cego e depende de vibrações, mas ainda é aceitável.
  - ⚠ A última fala 'Quieto, alguém se aproxima.' é um pouco abrupta como fecho, mas funciona no contexto.
- nota 4: 0: Cada passo faz o chão vibrar. / 1: O silêncio é o meu aliado. / 0: O sculk nunca se engana.
  - ⚠ A fala 'O silêncio é o meu aliado.' soa um pouco filosófica demais para um Warden, que é uma criatura instintiva e agressiva.
  - ⚠ A resposta 'O sculk nunca se engana.' não responde diretamente à fala anterior, mas ainda faz sentido no contexto.

### zumbi_sol (4.75)  _um zumbi e outra criatura da mesma espécie; é de dia_
- nota 4: 0: Grrr... preciso de sombra. / 1: Grrr... a sombra é a única amiga. / 0: Grrr... paciência.
  - ⚠ Fala 1: 'a sombra é a única amiga' soa filosófica demais para um zumbi, que normalmente não expressa sentimentos complexos.

### bicho_lama (4.88)  _dois animais da fazenda; uma situação qualquer do dia a dia_
- nota 4: 0: Lama macia faz bem para os cascos. / 1: Eu me deito nela e fico à vontade. / 0: Amanhã a lama ainda estará lá.
  - ⚠ A fala 'Amanhã a lama ainda estará lá.' soa um pouco desconexa como fecho, pois não responde diretamente à fala anterior sobre deitar na lama.

### bicho_vento (4.88)  _dois animais da fazenda; é de dia_
- nota 4: 0: Hoje venta bastante. / 1: O vento esfria o calor. / 0: Vento bom é vento fraco.
  - ⚠ A fala 'Vento bom é vento fraco' soa um pouco filosófica demais para animais de fazenda, mas ainda é aceitável.

### fofoca_vila (4.88)  _dois aldeões; é de dia_
- nota 4: 0: Alguém viu o que se passa perto do rio? / 1: Aqui na vila as notícias correm rápido. / 0: Vou ficar de olho.
  - ⚠ A fala 1 'as notícias correm rápido' é um pouco genérica e não responde diretamente à pergunta sobre o rio
  - ⚠ O fecho 'Vou ficar de olho' é aceitável, mas não fecha muito a conversa

### jogador_noite (4.88)  _dois aldeões; é noite_
- nota 4: 0: Olha lá, o humano caminhando no escuro. / 1: Eu não sairia de casa agora. / 0: Que a noite seja gentil com essa pessoa.
  - ⚠ 'Que a noite seja gentil com essa pessoa' soa um pouco solene/literário demais para um aldeão falando com outro

### madrugada (4.88)  _duas criaturas calmas (aldeões ou animais da fazenda) e outra criatura da mesma espécie; está amanhecendo_
- nota 4: 0: Acordei cedo hoje. / 1: O frio da madrugada passa logo. / 0: Que ele seja tranquilo.
  - ⚠ A fala 'Que ele seja tranquilo.' é um pouco vaga, mas pode se referir ao dia, o que é aceitável.

### monstros_noite (4.88)  _dois monstros hostis; é noite_
- nota 4: 0: Sinto cheiro de humano por perto. / 1: Vamos juntos, então. / 0: Que a noite comece.
  - ⚠ A fala 'Que a noite comece' soa um pouco teatral para um monstro hostil, mas ainda aceitável.

### vila_pao (4.88)  _dois aldeões; é de dia_
- nota 4: 0: Falta pão quando a colheita é fraca. / 1: Eu guardo um pouco para o dia seguinte. / 0: O melhor perfume é o do forno.
  - ⚠ A fala 'O melhor perfume é o do forno.' soa um pouco poética demais para um aldeão, mas ainda é plausível.

### vila_sino (4.88)  _dois aldeões; uma situação qualquer do dia a dia_
- nota 4: 0: O sino da vila é o som que mais me assusta. / 1: Tomara que seja sempre só um aviso. / 0: O golem fica de olho em tudo.
  - ⚠ A fala 'O golem fica de olho em tudo.' não fecha claramente a conversa sobre o sino, soando como um comentário solto.

### vila_tempestade (4.88)  _dois aldeões; há tempestade_
- nota 4: 0: A tempestade assusta até o golem. / 1: Eu acendo uma tocha e espero passar. / 0: A vila aguenta qualquer tempo.
  - ⚠ Fala 1: 'Eu acendo uma tocha e espero passar.' soa um pouco estranho, pois aldeões não costumam acender tochas; isso é mais ação de jogador.
  - ⚠ Fala 0 (fecho): 'A vila aguenta qualquer tempo.' é um pouco genérica e não responde diretamente à fala anterior sobre acender tocha.
